export type Cat = { id: string; name: string; hint: string; icon: string };
export const CATS: Cat[] = [
  { id: 'cement', name: 'Cement', hint: 'OPC, PPC, PSC', icon: 'bag' },
  { id: 'bricks', name: 'Bricks & Blocks', hint: 'Clay, fly ash, AAC', icon: 'brick' },
  { id: 'sand', name: 'Sand & Aggregates', hint: 'M-sand, 20mm, 40mm', icon: 'pile' },
  { id: 'plumbing', name: 'Plumbing', hint: 'CPVC, PVC, fittings', icon: 'pipe' },
  { id: 'electrical', name: 'Electricals', hint: 'Wires, switches, MCBs', icon: 'bolt' },
  { id: 'paint', name: 'Paints', hint: 'Emulsion, primer, putty', icon: 'bucket' },
  { id: 'waterproof', name: 'Waterproofing', hint: 'Terrace, bathroom, damp', icon: 'drop' },
  { id: 'tiles', name: 'Tiles', hint: 'Floor and wall', icon: 'tile' },
  { id: 'wood', name: 'Plywood & Boards', hint: 'BWP, HDHMR, laminates', icon: 'board' },
  { id: 'tools', name: 'Tools & Safety', hint: 'Drills, helmets, gloves', icon: 'tool' },
];
export type Product = { id: string; cat: string; name: string; brand: string; spec: string; unit: string; price: number; mrp: number; step: number; bulkAt?: number; bulkOff?: number; tag?: string };
const P = (id: string, cat: string, brand: string, name: string, spec: string, unit: string, price: number, mrp: number, step = 1, bulkAt?: number, bulkOff?: number, tag?: string): Product => ({ id, cat, brand, name, spec, unit, price, mrp, step, bulkAt, bulkOff, tag });
export const PRODUCTS: Product[] = [
  P('c1', 'cement', 'UltraTech', 'UltraTech PPC Cement', '50 kg bag, Portland Pozzolana, general construction', 'bag', 385, 420, 1, 100, 12, 'Best seller'),
  P('c2', 'cement', 'ACC', 'ACC Gold Water Shield PPC', '50 kg bag, water-repellent, slabs and plaster', 'bag', 395, 430, 1, 100, 12),
  P('c3', 'cement', 'Ambuja', 'Ambuja Plus Cement', '50 kg bag, PPC, good for plaster and brickwork', 'bag', 390, 425, 1, 100, 10),
  P('c4', 'cement', 'Dalmia', 'Dalmia DSP Cement', '50 kg bag, PSC, low heat, RCC and foundations', 'bag', 380, 415, 1, 100, 10),
  P('c5', 'cement', 'UltraTech', 'UltraTech OPC 53 Grade', '50 kg bag, high early strength, columns and beams', 'bag', 425, 455, 1, 100, 12),
  P('b1', 'bricks', 'Local kiln', 'Red clay bricks, first class', '9 x 4 x 3 in, minimum order 1,000 pcs', 'pc', 9, 11, 500, 5000, 5),
  P('b2', 'bricks', 'Local plant', 'Fly ash bricks', '9 x 4 x 3 in, uniform size, minimum order 1,000 pcs', 'pc', 7, 8.5, 500, 5000, 5),
  P('b3', 'bricks', 'Aerocon', 'AAC blocks, 600 x 200 x 200 mm', 'Lightweight, thermal insulation, per block', 'pc', 62, 72, 20, 400, 4, 'Fast moving'),
  P('b4', 'bricks', 'Local plant', 'Solid concrete blocks, 6 in', '400 x 150 x 200 mm, load-bearing walls', 'pc', 38, 45, 50, 500, 3),
  P('g1', 'sand', 'Quarry direct', 'M-sand (manufactured sand)', 'Washed, plastering and concrete, per tonne', 'tonne', 1250, 1500, 1, 20, 80),
  P('g2', 'sand', 'Quarry direct', 'River sand, screened', 'Fine grade, per tonne', 'tonne', 1900, 2200, 1, 20, 100),
  P('g3', 'sand', 'Quarry direct', 'Aggregate 20 mm', 'Crushed stone, RCC work, per tonne', 'tonne', 950, 1150, 1, 20, 60),
  P('g4', 'sand', 'Quarry direct', 'Aggregate 40 mm', 'Crushed stone, foundations, per tonne', 'tonne', 900, 1100, 1, 20, 60),
  P('p1', 'plumbing', 'Astral', 'Astral CPVC pipe, 1 in', 'SDR 11, 3 m length, hot and cold water', 'pc', 640, 760, 1, 20, 6),
  P('p2', 'plumbing', 'Supreme', 'Supreme PVC pipe, 4 in', 'Drainage, 6 kg/cm2, 3 m length', 'pc', 820, 960, 1, 20, 6),
  P('p3', 'plumbing', 'Prince', 'Prince UPVC elbow and tee kit', 'Pack of 20 assorted fittings', 'pack', 480, 600, 1),
  P('p4', 'plumbing', 'Sintex', 'Sintex water tank, 1000 L', '3-layer, UV stabilised', 'pc', 7800, 9200, 1, undefined, undefined, 'Free unloading'),
  P('e1', 'electrical', 'Polycab', 'Polycab FR copper wire, 1.5 sq mm', '90 m coil, house wiring', 'coil', 1950, 2300, 1, 10, 5),
  P('e2', 'electrical', 'Havells', 'Havells FR copper wire, 2.5 sq mm', '90 m coil, sockets and AC points', 'coil', 3100, 3600, 1, 10, 5),
  P('e3', 'electrical', 'Anchor', 'Anchor Roma modular switch set', '6A, pack of 10 switches with plates', 'pack', 1150, 1500, 1),
  P('e4', 'electrical', 'Legrand', 'Legrand 32A DP MCB', 'C-curve, for main and AC circuits', 'pc', 520, 640, 1, 10, 6),
  P('t1', 'paint', 'Asian Paints', 'Asian Paints Tractor Emulsion, 20 L', 'Interior wall emulsion, white', 'bucket', 4150, 4800, 1, 5, 3),
  P('t2', 'paint', 'Berger', 'Berger Easy Clean Emulsion, 20 L', 'Washable interior emulsion', 'bucket', 6400, 7400, 1, 5, 3),
  P('t3', 'paint', 'Birla White', 'Birla White wall putty, 40 kg', 'Cement-based, smooth finish', 'bag', 1050, 1250, 1, 20, 5),
  P('t4', 'paint', 'Asian Paints', 'Asian Paints exterior primer, 20 L', 'Water-based, for new walls', 'bucket', 3300, 3900, 1, 5, 3),
  P('l1', 'tiles', 'Kajaria', 'Kajaria vitrified floor tile, 600 x 600', 'Glossy, 4 tiles per box (1.44 sq m)', 'box', 780, 980, 1, 50, 4),
  P('l2', 'tiles', 'Somany', 'Somany ceramic wall tile, 300 x 450', 'Glossy, 8 tiles per box (1.08 sq m)', 'box', 540, 690, 1, 50, 4),
  P('l3', 'tiles', 'Nitco', 'Nitco anti-skid bathroom tile, 300 x 300', 'Matt, 11 tiles per box (1 sq m)', 'box', 410, 520, 1, 50, 3),
  P('w1', 'wood', 'Greenply', 'Greenply BWP plywood, 19 mm', '8 x 4 ft, boiling waterproof', 'sheet', 3250, 3900, 1, 20, 4),
  P('w2', 'wood', 'Century', 'Century Sainik MR plywood, 18 mm', '8 x 4 ft, moisture resistant', 'sheet', 2350, 2800, 1, 20, 4),
  P('w3', 'wood', 'Action Tesa', 'Action Tesa HDHMR board, 18 mm', '8 x 4 ft, plain', 'sheet', 1850, 2300, 1, 20, 4),
  P('m1', 'waterproof', 'Pidilite', 'Dr. Fixit Pidiproof LW+, 5 L', 'Integral waterproofing admixture for concrete and mortar', 'can', 760, 840, 1, 10, 25, 'Best seller'),
  P('m2', 'waterproof', 'Pidilite', 'Dr. Fixit Roofseal Acrylic Coating, 10 L', 'Elastomeric terrace and roof coating, seamless', 'can', 3150, 3550, 1, 5, 80, 'Top rated'),
  P('m3', 'waterproof', 'Asian Paints', 'SmartCare Damp Proof, 4 kg', 'Two-pack coat for damp interior walls', 'kit', 1380, 1550),
  P('m4', 'waterproof', 'Sika', 'Sika Latex, 5 L', 'SBR bonding agent and waterproofing additive', 'can', 780, 880, 1, 10, 20),
  P('m5', 'waterproof', 'Fosroc', 'Fosroc Brushbond, 20 kg', 'Flexible cementitious coating, bathrooms and sunken slabs', 'kit', 2250, 2480, 1, 5, 60),
  P('m6', 'waterproof', 'Site grade', 'Torch-on bitumen membrane, 3 mm, 10 m roll', 'APP modified, terraces and basements', 'roll', 3600, 4100),
  P('m7', 'waterproof', 'Sika', 'Sikaflex PU sealant, 300 ml', 'Joint and crack sealing, weatherproof', 'cartridge', 420, 480, 1, 12, 15),
  P('x1', 'tools', 'Bosch', 'Bosch GSB 500 RE impact drill', '500 W, 10 mm chuck, 1 year warranty', 'pc', 2850, 3400, 1),
  P('x2', 'tools', 'Stanley', 'Stanley claw hammer, 450 g', 'Fibreglass handle', 'pc', 540, 690, 1),
  P('x3', 'tools', 'Karam', 'Karam safety helmet', 'ISI marked, ratchet adjust', 'pc', 190, 260, 1, 20, 15),
  P('x4', 'tools', 'Taparia', 'Taparia 52-piece toolkit', 'Spanners, pliers, screwdrivers, bag', 'kit', 1650, 2100, 1),
];
export type Supplier = { id: string; name: string; area: string; rating: number; reviews: number; eta: number; km: number; mult: number; credit: boolean; phone?: string; email?: string; address?: string; pin?: string; noCatalog?: boolean };
export const SUPPLIERS: Supplier[] = [
  { id: 'kz', name: 'Kwenzo', area: 'Hyderabad', rating: 0, reviews: 0, eta: 0, km: 0, mult: 1.0, credit: false, noCatalog: true },
];
export const supplierFor = (pid: string): Supplier[] => {
  const n = pid.charCodeAt(0) + Number(pid.slice(1));
  const L0 = SUPPLIERS.filter(x => !x.noCatalog); const L = L0.length ? L0 : SUPPLIERS;
  return [0, 1, 2].map(i => L[(n + i * 2) % L.length]);
};
export const priceAt = (p: Product, s: Supplier) => { const v = p.price * s.mult; return v < 100 ? Math.round(v * 2) / 2 : Math.round(v); };
export const inr = (n: number) => '₹' + n.toLocaleString('en-IN', { maximumFractionDigits: 2 });
export type Status = 'placed' | 'accepted' | 'packed' | 'dispatched' | 'delivered' | 'cancelled';
export type Order = { id: string; at: number; name: string; phone: string; addr: string; pin: string; city: string; slot: string; pay: string; total: number; sid: string; lines: { pid: string; qty: number; up: number }[]; status: Status; vehicle?: string; mine?: boolean; cust?: string; pDisp?: string; pPick?: string; pDel?: string };
export type Settings = { commission: number; freeAbove: number; fee: number };
export type Ob = { step: number; stage: 'progress' | 'review' | 'changes' | 'live'; note?: string; biz: { type: string; addr: string; pin: string; gst: string; years: string }; docs: Record<string, string>; cats: string[]; items: Record<string, number>; svc: { radius: string; from: string; to: string; minOrder: string; days: string[] }; bank: { holder: string; acc: string; ifsc: string; upi: string; cycle: string }; agree: boolean[]; submittedAt?: number };
export type App_ = { id: string; shop: string; owner: string; city: string; phone?: string; gst?: string; status: 'pending' | 'approved' | 'rejected' | 'changes' | 'draft'; ob?: Ob; v?: any; user?: string; pass?: string };
export const newOb = (gst = ''): Ob => ({ step: 0, stage: 'progress', biz: { type: 'Retail dealer', addr: '', pin: '', gst, years: '' }, docs: {}, cats: [], items: {}, svc: { radius: '10', from: '08:00', to: '19:00', minOrder: '2000', days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] }, bank: { holder: '', acc: '', ifsc: '', upi: '', cycle: 'Weekly' }, agree: [false, false, false] });
export const DEFAULT_SETTINGS: Settings = { commission: 6, freeAbove: 5000, fee: 149 };
export const VEHICLES = [
  { id: 'TS 09 AB 4821', type: 'Tata Ace mini truck', cap: '750 kg', driver: 'Ramesh K.' },
  { id: 'TS 05 MK 2210', type: 'Mahindra Bolero pickup', cap: '1.2 tonne', driver: 'Suresh N.' },
  { id: 'TS 02 HJ 7714', type: 'Eicher 14 ft truck', cap: '4 tonne', driver: 'Imran S.' },
  { id: 'TS 04 TN 0932', type: 'Tipper (sand and aggregates)', cap: '10 tonne', driver: 'Manjunath B.' },
  { id: 'TS 09 CD 3306', type: 'Tata 407 truck', cap: '2.5 tonne', driver: 'Venkatesh R.' },
];
const H = 3600000;
export const seedOrders = (): Order[] => [];
export const seedApps = (): App_[] => [];

export const SERVICEABLE_PINS = ['500073','500082','500034','500033','500038','500045','500016','500018','500004','500028','500001','500003','500009','500020','500029','500008','500081','500011','500037','500032','500084','500072','500085','500049','500075','500007','500039','500076','500047','500062','501218','500006','500012','500022','500025','500031','500041','500042','500044','500057','500061','500063','500080','500095','500096','500105','500110','500023','500024','500064','500065','500066','500046','500111','500104','500056','500058','500030','500091','500107','500100'];
export const isServiceable = (pin: string) => SERVICEABLE_PINS.includes(pin);
export const COMING_SOON = "We're not there yet, but we're coming soon!";
