import iK5X6X from './photos/sku/K5X6X.jpg';
import i0 from './photos/ph.jpg';
import i1 from './photos/ph.jpg';
import i2 from './photos/ph.jpg';
import i3 from './photos/ph.jpg';
import i4 from './photos/ph.jpg';
import i5 from './photos/ph.jpg';
import i6 from './photos/ph.jpg';
import i7 from './photos/ph.jpg';
import i8 from './photos/ph.jpg';
import i9 from './photos/ph.jpg';
import i10 from './photos/ph.jpg';
import i11 from './photos/ph.jpg';
import i12 from './photos/ph.jpg';
import i13 from './photos/ph.jpg';
import i14 from './photos/ph.jpg';
import i15 from './photos/ph.jpg';
import i16 from './photos/ph.jpg';
import i17 from './photos/ph.jpg';
import i18 from './photos/ph.jpg';
import i19 from './photos/ph.jpg';
import i20 from './photos/ph.jpg';
import i21 from './photos/ph.jpg';
import i22 from './photos/ph.jpg';
import i23 from './photos/ph.jpg';
import i24 from './photos/ph.jpg';
import i25 from './photos/ph.jpg';
import i26 from './photos/ph.jpg';
import i27 from './photos/ph.jpg';
import i28 from './photos/ph.jpg';
import i29 from './photos/ph.jpg';
import i30 from './photos/ph.jpg';
import i31 from './photos/ph.jpg';
import i32 from './photos/ph.jpg';
import i33 from './photos/ph.jpg';
import i34 from './photos/ph.jpg';
import i35 from './photos/ph.jpg';
import i36 from './photos/ph.jpg';
import i37 from './photos/ph.jpg';
import i38 from './photos/ph.jpg';
import i39 from './photos/ph.jpg';
import i40 from './photos/ph.jpg';
import i41 from './photos/ph.jpg';
import i42 from './photos/ph.jpg';
import i43 from './photos/ph.jpg';
import i44 from './photos/ph.jpg';
import i45 from './photos/ph.jpg';
import i46 from './photos/ph.jpg';
import i47 from './photos/ph.jpg';
import i48 from './photos/ph.jpg';
import i49 from './photos/ph.jpg';
import i50 from './photos/ph.jpg';
import i51 from './photos/ph.jpg';
import i52 from './photos/ph.jpg';
import i53 from './photos/ph.jpg';
import i54 from './photos/ph.jpg';
import i55 from './photos/ph.jpg';
import i56 from './photos/ph.jpg';
import i57 from './photos/ph.jpg';
import i58 from './photos/ph.jpg';
import i59 from './photos/ph.jpg';
import i60 from './photos/ph.jpg';
import i61 from './photos/ph.jpg';
import i62 from './photos/ph.jpg';
import i63 from './photos/ph.jpg';
import i64 from './photos/ph.jpg';
import i65 from './photos/ph.jpg';
import i66 from './photos/ph.jpg';
import i67 from './photos/ph.jpg';
import i68 from './photos/ph.jpg';
import i69 from './photos/ph.jpg';
import i70 from './photos/ph.jpg';
import i71 from './photos/ph.jpg';
import i72 from './photos/ph.jpg';
import i73 from './photos/ph.jpg';
import i74 from './photos/ph.jpg';
import i75 from './photos/ph.jpg';
import i76 from './photos/ph.jpg';
import i77 from './photos/ph.jpg';
import i78 from './photos/ph.jpg';
import i79 from './photos/ph.jpg';
import i80 from './photos/ph.jpg';
import i81 from './photos/ph.jpg';
import i82 from './photos/ph.jpg';
import i83 from './photos/ph.jpg';
import i84 from './photos/ph.jpg';
import i85 from './photos/ph.jpg';
import i86 from './photos/ph.jpg';
import i87 from './photos/ph.jpg';
import i88 from './photos/ph.jpg';
import i89 from './photos/ph.jpg';
import i90 from './photos/ph.jpg';
import i91 from './photos/ph.jpg';
import i92 from './photos/ph.jpg';
import i93 from './photos/ph.jpg';
import i94 from './photos/ph.jpg';
import i95 from './photos/ph.jpg';
import i96 from './photos/ph.jpg';
import i97 from './photos/ph.jpg';
import i98 from './photos/ph.jpg';
import i99 from './photos/ph.jpg';
import i100 from './photos/ph.jpg';
import i101 from './photos/ph.jpg';
import i102 from './photos/ph.jpg';
import i103 from './photos/ph.jpg';
import i104 from './photos/ph.jpg';
import i105 from './photos/ph.jpg';
import i106 from './photos/ph.jpg';
import i107 from './photos/ph.jpg';
import i108 from './photos/ph.jpg';
import i109 from './photos/ph.jpg';
import i110 from './photos/ph.jpg';
import i111 from './photos/ph.jpg';
import i112 from './photos/ph.jpg';
import i113 from './photos/ph.jpg';
import i114 from './photos/ph.jpg';
import i115 from './photos/ph.jpg';
import i116 from './photos/ph.jpg';
import i117 from './photos/ph.jpg';
import i118 from './photos/ph.jpg';
import i119 from './photos/ph.jpg';
import i120 from './photos/ph.jpg';
import i121 from './photos/ph.jpg';
import i122 from './photos/ph.jpg';
import i123 from './photos/ph.jpg';
import i124 from './photos/ph.jpg';
import i125 from './photos/ph.jpg';
import i126 from './photos/ph.jpg';
import i127 from './photos/ph.jpg';
import i128 from './photos/ph.jpg';
import i129 from './photos/ph.jpg';
import i130 from './photos/ph.jpg';
import i131 from './photos/ph.jpg';
import i132 from './photos/ph.jpg';
import i133 from './photos/ph.jpg';
import i134 from './photos/ph.jpg';
import i135 from './photos/ph.jpg';
import i136 from './photos/ph.jpg';
import i137 from './photos/ph.jpg';
import i138 from './photos/ph.jpg';
import i139 from './photos/ph.jpg';
import i140 from './photos/ph.jpg';
import i141 from './photos/ph.jpg';
import i142 from './photos/ph.jpg';
import i143 from './photos/ph.jpg';
import i144 from './photos/ph.jpg';
import i145 from './photos/ph.jpg';
import i146 from './photos/ph.jpg';
import i147 from './photos/ph.jpg';
import i148 from './photos/ph.jpg';
import i149 from './photos/ph.jpg';
import i150 from './photos/ph.jpg';
import i151 from './photos/ph.jpg';
import i152 from './photos/ph.jpg';
import i153 from './photos/ph.jpg';
import i154 from './photos/ph.jpg';
import i155 from './photos/ph.jpg';
import i156 from './photos/ph.jpg';
import i157 from './photos/ph.jpg';
import i158 from './photos/ph.jpg';
import i159 from './photos/ph.jpg';
import i160 from './photos/ph.jpg';
import i161 from './photos/ph.jpg';
import i162 from './photos/ph.jpg';
import i163 from './photos/ph.jpg';
import i164 from './photos/ph.jpg';
import i165 from './photos/ph.jpg';
import i166 from './photos/ph.jpg';
import i167 from './photos/ph.jpg';
import i168 from './photos/ph.jpg';
import i169 from './photos/ph.jpg';
import i170 from './photos/ph.jpg';
import i171 from './photos/ph.jpg';
import i172 from './photos/ph.jpg';
import i173 from './photos/ph.jpg';
import i174 from './photos/ph.jpg';
import i175 from './photos/ph.jpg';
import i176 from './photos/ph.jpg';
import i177 from './photos/ph.jpg';
import i178 from './photos/ph.jpg';
import i179 from './photos/ph.jpg';
import i180 from './photos/ph.jpg';
import i181 from './photos/ph.jpg';
import i182 from './photos/ph.jpg';
import i183 from './photos/ph.jpg';
import i184 from './photos/ph.jpg';
import i185 from './photos/ph.jpg';
import i186 from './photos/ph.jpg';
import i187 from './photos/ph.jpg';
import i188 from './photos/ph.jpg';
import i189 from './photos/ph.jpg';
import i190 from './photos/ph.jpg';
import i191 from './photos/ph.jpg';
import i192 from './photos/ph.jpg';
import i193 from './photos/ph.jpg';
import i194 from './photos/ph.jpg';
import i195 from './photos/ph.jpg';
import i196 from './photos/ph.jpg';
import i197 from './photos/ph.jpg';
import i198 from './photos/ph.jpg';
import i199 from './photos/ph.jpg';
import i200 from './photos/ph.jpg';
import i201 from './photos/ph.jpg';
import i202 from './photos/ph.jpg';
import i203 from './photos/ph.jpg';
import i204 from './photos/ph.jpg';
import i205 from './photos/ph.jpg';
import i206 from './photos/ph.jpg';
import i207 from './photos/ph.jpg';
import i208 from './photos/ph.jpg';
import i209 from './photos/ph.jpg';
import i210 from './photos/ph.jpg';
import i211 from './photos/ph.jpg';
import i212 from './photos/ph.jpg';
import i213 from './photos/ph.jpg';
import i214 from './photos/ph.jpg';
import i215 from './photos/ph.jpg';
import i216 from './photos/ph.jpg';
import i217 from './photos/ph.jpg';
import i218 from './photos/ph.jpg';
import i219 from './photos/ph.jpg';
import i220 from './photos/ph.jpg';
import i221 from './photos/ph.jpg';
import i222 from './photos/ph.jpg';
import i223 from './photos/ph.jpg';
import i224 from './photos/ph.jpg';
import i225 from './photos/ph.jpg';
import i226 from './photos/ph.jpg';
import i227 from './photos/ph.jpg';
import i228 from './photos/ph.jpg';
import i229 from './photos/ph.jpg';
import i230 from './photos/ph.jpg';
import i231 from './photos/ph.jpg';
import i232 from './photos/ph.jpg';
import i233 from './photos/ph.jpg';
import i234 from './photos/ph.jpg';
import i235 from './photos/ph.jpg';
import i236 from './photos/ph.jpg';
import i237 from './photos/ph.jpg';
import i238 from './photos/sku/BQ2U7.jpg';
import i239 from './photos/ph.jpg';
import i240 from './photos/ph.jpg';
import i241 from './photos/ph.jpg';
import i242 from './photos/ph.jpg';
import i243 from './photos/ph.jpg';
import i244 from './photos/ph.jpg';
import i245 from './photos/ph.jpg';
import i246 from './photos/ph.jpg';
import i247 from './photos/ph.jpg';
import i248 from './photos/ph.jpg';
import i249 from './photos/ph.jpg';
import i250 from './photos/ph.jpg';
import i251 from './photos/ph.jpg';
import i252 from './photos/ph.jpg';
import i253 from './photos/ph.jpg';
import i254 from './photos/ph.jpg';
import i255 from './photos/ph.jpg';
import i256 from './photos/ph.jpg';
import i257 from './photos/ph.jpg';
import i258 from './photos/ph.jpg';
import i259 from './photos/ph.jpg';
import i260 from './photos/ph.jpg';
import i261 from './photos/ph.jpg';
import i262 from './photos/ph.jpg';
import i263 from './photos/ph.jpg';
import i264 from './photos/ph.jpg';
import i265 from './photos/ph.jpg';
import i266 from './photos/ph.jpg';
import i267 from './photos/ph.jpg';
import i268 from './photos/ph.jpg';
import i269 from './photos/ph.jpg';
import i270 from './photos/ph.jpg';
import i271 from './photos/ph.jpg';
import i272 from './photos/ph.jpg';
import i273 from './photos/ph.jpg';
import i274 from './photos/ph.jpg';
import i275 from './photos/ph.jpg';
import i276 from './photos/ph.jpg';
import i277 from './photos/ph.jpg';
import i278 from './photos/ph.jpg';
import i279 from './photos/ph.jpg';
import i280 from './photos/ph.jpg';
import i281 from './photos/ph.jpg';
import i282 from './photos/ph.jpg';
import i283 from './photos/ph.jpg';
import i284 from './photos/ph.jpg';
import i285 from './photos/ph.jpg';
import i286 from './photos/ph.jpg';
import i287 from './photos/ph.jpg';
import i288 from './photos/ph.jpg';
import i289 from './photos/ph.jpg';
import i290 from './photos/ph.jpg';
import i291 from './photos/ph.jpg';
import i292 from './photos/ph.jpg';
import i293 from './photos/ph.jpg';
import i294 from './photos/ph.jpg';
import i295 from './photos/ph.jpg';
import i296 from './photos/ph.jpg';
import i297 from './photos/ph.jpg';
import i298 from './photos/ph.jpg';
import i299 from './photos/ph.jpg';
import i300 from './photos/ph.jpg';
import i301 from './photos/ph.jpg';
import i302 from './photos/ph.jpg';
import i303 from './photos/ph.jpg';
import i304 from './photos/ph.jpg';
import i305 from './photos/ph.jpg';
import i306 from './photos/ph.jpg';
import i307 from './photos/ph.jpg';
import i308 from './photos/ph.jpg';
import i309 from './photos/ph.jpg';
import i310 from './photos/ph.jpg';
import i311 from './photos/ph.jpg';
import i312 from './photos/ph.jpg';
import i313 from './photos/ph.jpg';
import i314 from './photos/ph.jpg';
import i315 from './photos/ph.jpg';
import i316 from './photos/ph.jpg';
import i317 from './photos/ph.jpg';
import i318 from './photos/ph.jpg';
import i319 from './photos/ph.jpg';
import i320 from './photos/ph.jpg';
import i321 from './photos/ph.jpg';
import i322 from './photos/ph.jpg';
import i323 from './photos/ph.jpg';
import i324 from './photos/ph.jpg';
import i325 from './photos/ph.jpg';
import i326 from './photos/ph.jpg';
import i327 from './photos/ph.jpg';
import i328 from './photos/ph.jpg';
import i329 from './photos/ph.jpg';
import i330 from './photos/ph.jpg';
import i331 from './photos/ph.jpg';
import i332 from './photos/ph.jpg';
import i333 from './photos/ph.jpg';
import i334 from './photos/ph.jpg';
import i335 from './photos/ph.jpg';
import i336 from './photos/ph.jpg';
import i337 from './photos/ph.jpg';
import i338 from './photos/ph.jpg';
import i339 from './photos/ph.jpg';
import i340 from './photos/ph.jpg';
import i341 from './photos/ph.jpg';
import i342 from './photos/ph.jpg';
import i343 from './photos/ph.jpg';
import i344 from './photos/ph.jpg';
import i345 from './photos/ph.jpg';
import i346 from './photos/ph.jpg';
import i347 from './photos/ph.jpg';
import i348 from './photos/ph.jpg';
import i349 from './photos/ph.jpg';
import i350 from './photos/ph.jpg';
import i351 from './photos/ph.jpg';
import i352 from './photos/ph.jpg';
import i353 from './photos/ph.jpg';
import i354 from './photos/ph.jpg';
import i355 from './photos/ph.jpg';
import i356 from './photos/ph.jpg';
import i357 from './photos/ph.jpg';
import i358 from './photos/ph.jpg';
import i359 from './photos/ph.jpg';
import i360 from './photos/ph.jpg';
import i361 from './photos/ph.jpg';
import i362 from './photos/ph.jpg';
import i363 from './photos/ph.jpg';
import i364 from './photos/ph.jpg';
import i365 from './photos/ph.jpg';
import i366 from './photos/ph.jpg';
import i367 from './photos/ph.jpg';
import i368 from './photos/ph.jpg';
import i369 from './photos/ph.jpg';
import i370 from './photos/ph.jpg';
import i371 from './photos/ph.jpg';
import i372 from './photos/ph.jpg';
import i373 from './photos/ph.jpg';
import i374 from './photos/ph.jpg';
import i375 from './photos/ph.jpg';
import i376 from './photos/ph.jpg';
import i377 from './photos/ph.jpg';
import i378 from './photos/ph.jpg';
import i379 from './photos/ph.jpg';
import i380 from './photos/ph.jpg';
import i381 from './photos/ph.jpg';
import i382 from './photos/ph.jpg';
import i383 from './photos/ph.jpg';
import i384 from './photos/ph.jpg';
import i385 from './photos/ph.jpg';
import i386 from './photos/ph.jpg';
import i387 from './photos/ph.jpg';
import i388 from './photos/ph.jpg';
import i389 from './photos/ph.jpg';
import i390 from './photos/ph.jpg';
import i391 from './photos/ph.jpg';
import i392 from './photos/ph.jpg';
import i393 from './photos/ph.jpg';
import i394 from './photos/ph.jpg';
import i395 from './photos/ph.jpg';
import i396 from './photos/ph.jpg';
import i397 from './photos/ph.jpg';
import i398 from './photos/ph.jpg';
import i399 from './photos/ph.jpg';
import i400 from './photos/ph.jpg';
import i401 from './photos/ph.jpg';
import i402 from './photos/ph.jpg';
import i403 from './photos/ph.jpg';
import i404 from './photos/ph.jpg';
import i405 from './photos/ph.jpg';
import i406 from './photos/ph.jpg';
import i407 from './photos/ph.jpg';
import i408 from './photos/ph.jpg';
import i409 from './photos/ph.jpg';
import i410 from './photos/ph.jpg';
import i411 from './photos/ph.jpg';
import i412 from './photos/ph.jpg';
import i413 from './photos/ph.jpg';
import i414 from './photos/ph.jpg';
import i415 from './photos/ph.jpg';
import i416 from './photos/ph.jpg';
import i417 from './photos/ph.jpg';
import i418 from './photos/ph.jpg';
import i419 from './photos/ph.jpg';
import i420 from './photos/ph.jpg';
import i421 from './photos/ph.jpg';
import i422 from './photos/ph.jpg';
import i423 from './photos/ph.jpg';
import i424 from './photos/ph.jpg';
import i425 from './photos/ph.jpg';
import i426 from './photos/ph.jpg';
import i427 from './photos/ph.jpg';
import i428 from './photos/ph.jpg';
import i429 from './photos/ph.jpg';
import i430 from './photos/ph.jpg';
import i431 from './photos/ph.jpg';
import i432 from './photos/ph.jpg';
import i433 from './photos/ph.jpg';
import i434 from './photos/ph.jpg';
import i435 from './photos/ph.jpg';
import i436 from './photos/ph.jpg';
import i437 from './photos/ph.jpg';
import i438 from './photos/ph.jpg';
import i439 from './photos/ph.jpg';
import i440 from './photos/ph.jpg';
import i441 from './photos/ph.jpg';
import i442 from './photos/ph.jpg';
import i443 from './photos/ph.jpg';
import i444 from './photos/ph.jpg';
import i445 from './photos/ph.jpg';
import i446 from './photos/ph.jpg';
import i447 from './photos/ph.jpg';
import i448 from './photos/ph.jpg';
import i449 from './photos/ph.jpg';
import i450 from './photos/ph.jpg';
import i451 from './photos/ph.jpg';
import i452 from './photos/ph.jpg';
import i453 from './photos/sku/MM74F.jpg';
import i454 from './photos/ph.jpg';
import i455 from './photos/ph.jpg';
import i456 from './photos/ph.jpg';
import i457 from './photos/ph.jpg';
import i458 from './photos/ph.jpg';
import i459 from './photos/ph.jpg';
import i460 from './photos/ph.jpg';
import i461 from './photos/ph.jpg';
import i462 from './photos/ph.jpg';
import i463 from './photos/ph.jpg';
import i464 from './photos/ph.jpg';
import i465 from './photos/ph.jpg';
import i466 from './photos/ph.jpg';
import i467 from './photos/ph.jpg';
import i468 from './photos/ph.jpg';
import i469 from './photos/ph.jpg';
import i470 from './photos/ph.jpg';
import i471 from './photos/ph.jpg';
import i472 from './photos/ph.jpg';
import i473 from './photos/ph.jpg';
import i474 from './photos/ph.jpg';
import i475 from './photos/ph.jpg';
import i476 from './photos/ph.jpg';
import i477 from './photos/ph.jpg';
import i478 from './photos/ph.jpg';
import i479 from './photos/ph.jpg';
import i480 from './photos/ph.jpg';
import i481 from './photos/ph.jpg';
import i482 from './photos/ph.jpg';
import i483 from './photos/ph.jpg';
import i484 from './photos/ph.jpg';
import i485 from './photos/ph.jpg';
import i486 from './photos/ph.jpg';
import i487 from './photos/ph.jpg';
import i488 from './photos/ph.jpg';
import i489 from './photos/ph.jpg';
import i490 from './photos/ph.jpg';
import i491 from './photos/ph.jpg';
import i492 from './photos/ph.jpg';
import i493 from './photos/ph.jpg';
import i494 from './photos/ph.jpg';
import i495 from './photos/ph.jpg';
import i496 from './photos/ph.jpg';
import i497 from './photos/ph.jpg';
import i498 from './photos/ph.jpg';
import i499 from './photos/ph.jpg';
import i500 from './photos/ph.jpg';
import i501 from './photos/ph.jpg';
import i502 from './photos/ph.jpg';
import i503 from './photos/ph.jpg';
import i504 from './photos/ph.jpg';
import i505 from './photos/ph.jpg';
import i506 from './photos/ph.jpg';
import i507 from './photos/ph.jpg';
import i508 from './photos/ph.jpg';
import i509 from './photos/ph.jpg';
import i510 from './photos/ph.jpg';
import i511 from './photos/ph.jpg';
import i512 from './photos/ph.jpg';
import i513 from './photos/ph.jpg';
import i514 from './photos/ph.jpg';
import i515 from './photos/ph.jpg';
import i516 from './photos/ph.jpg';
import i517 from './photos/ph.jpg';
import i518 from './photos/ph.jpg';
import i519 from './photos/ph.jpg';
import i520 from './photos/ph.jpg';
import i521 from './photos/ph.jpg';
import i522 from './photos/ph.jpg';
import i523 from './photos/ph.jpg';
import i524 from './photos/ph.jpg';
import i525 from './photos/ph.jpg';
import i526 from './photos/ph.jpg';
import i527 from './photos/ph.jpg';
import i528 from './photos/ph.jpg';
import i529 from './photos/ph.jpg';
import i530 from './photos/ph.jpg';
import i531 from './photos/ph.jpg';
import i532 from './photos/ph.jpg';
import i533 from './photos/ph.jpg';
import i534 from './photos/ph.jpg';
import i535 from './photos/ph.jpg';
import i536 from './photos/ph.jpg';
import i537 from './photos/ph.jpg';
import i538 from './photos/ph.jpg';
import i539 from './photos/ph.jpg';
import i540 from './photos/ph.jpg';
import i541 from './photos/ph.jpg';
import i542 from './photos/ph.jpg';
import i543 from './photos/ph.jpg';
import i544 from './photos/ph.jpg';
import i545 from './photos/ph.jpg';
import i546 from './photos/ph.jpg';
import i547 from './photos/ph.jpg';
import i548 from './photos/ph.jpg';
import i549 from './photos/ph.jpg';
import i550 from './photos/ph.jpg';
import i551 from './photos/ph.jpg';
import i552 from './photos/ph.jpg';
import i553 from './photos/ph.jpg';
import i554 from './photos/ph.jpg';
import i555 from './photos/ph.jpg';
import i556 from './photos/ph.jpg';
import i557 from './photos/ph.jpg';
import i558 from './photos/ph.jpg';
import i559 from './photos/ph.jpg';
import i560 from './photos/ph.jpg';
import i561 from './photos/ph.jpg';
import i562 from './photos/ph.jpg';
import i563 from './photos/ph.jpg';
import i564 from './photos/ph.jpg';
import i565 from './photos/ph.jpg';
import i566 from './photos/ph.jpg';
import i567 from './photos/ph.jpg';
import i568 from './photos/ph.jpg';
import i569 from './photos/ph.jpg';
import i570 from './photos/ph.jpg';
import i571 from './photos/ph.jpg';
import i572 from './photos/ph.jpg';
import i573 from './photos/ph.jpg';
import i574 from './photos/sku/T9QCX.jpg';
import i575 from './photos/ph.jpg';
import i576 from './photos/ph.jpg';
import i577 from './photos/ph.jpg';
import i578 from './photos/ph.jpg';
import i579 from './photos/ph.jpg';
import i580 from './photos/ph.jpg';
import i581 from './photos/ph.jpg';
import i582 from './photos/ph.jpg';
import i583 from './photos/ph.jpg';
import i584 from './photos/ph.jpg';
import i585 from './photos/ph.jpg';
import i586 from './photos/ph.jpg';
import i587 from './photos/ph.jpg';
import i588 from './photos/ph.jpg';
import i589 from './photos/ph.jpg';
import i590 from './photos/ph.jpg';
import i591 from './photos/ph.jpg';
import i592 from './photos/ph.jpg';
import i593 from './photos/ph.jpg';
import i594 from './photos/ph.jpg';
import i595 from './photos/ph.jpg';
import i596 from './photos/ph.jpg';
import i597 from './photos/ph.jpg';
import i598 from './photos/ph.jpg';
import i599 from './photos/ph.jpg';
import i600 from './photos/ph.jpg';
import i601 from './photos/ph.jpg';
import i602 from './photos/ph.jpg';
import i603 from './photos/ph.jpg';
import i604 from './photos/ph.jpg';
import i605 from './photos/ph.jpg';
import i606 from './photos/ph.jpg';
import i607 from './photos/ph.jpg';
import i608 from './photos/ph.jpg';
import i609 from './photos/ph.jpg';
import i610 from './photos/ph.jpg';
import i611 from './photos/ph.jpg';
import i612 from './photos/ph.jpg';
import i613 from './photos/ph.jpg';
import i614 from './photos/ph.jpg';
import i615 from './photos/ph.jpg';
import i616 from './photos/ph.jpg';
import i617 from './photos/ph.jpg';
import i618 from './photos/ph.jpg';
import i619 from './photos/ph.jpg';
import i620 from './photos/ph.jpg';
import i621 from './photos/ph.jpg';
import i622 from './photos/ph.jpg';
import i623 from './photos/ph.jpg';
import i624 from './photos/ph.jpg';
import i625 from './photos/ph.jpg';
import i626 from './photos/ph.jpg';
import i627 from './photos/ph.jpg';
import i628 from './photos/ph.jpg';
import i629 from './photos/ph.jpg';
import i630 from './photos/ph.jpg';
import i631 from './photos/ph.jpg';
import i632 from './photos/ph.jpg';
import i633 from './photos/ph.jpg';
import i634 from './photos/ph.jpg';
import i635 from './photos/ph.jpg';
import i636 from './photos/ph.jpg';
import i637 from './photos/ph.jpg';
import i638 from './photos/ph.jpg';
import i639 from './photos/ph.jpg';
import i640 from './photos/ph.jpg';
import i641 from './photos/ph.jpg';
import i642 from './photos/ph.jpg';
import i643 from './photos/ph.jpg';
import i644 from './photos/ph.jpg';
import i645 from './photos/ph.jpg';
import i646 from './photos/ph.jpg';
import i647 from './photos/ph.jpg';
import i648 from './photos/ph.jpg';
import i649 from './photos/ph.jpg';
import i650 from './photos/ph.jpg';
import i651 from './photos/ph.jpg';
import i652 from './photos/ph.jpg';
import i653 from './photos/ph.jpg';
import i654 from './photos/ph.jpg';
import i655 from './photos/ph.jpg';
import i656 from './photos/ph.jpg';
import i657 from './photos/ph.jpg';
import i658 from './photos/ph.jpg';
import i659 from './photos/ph.jpg';
import i660 from './photos/ph.jpg';
import i661 from './photos/ph.jpg';
import i662 from './photos/ph.jpg';
import i663 from './photos/ph.jpg';
import i664 from './photos/ph.jpg';
import i665 from './photos/ph.jpg';
import i666 from './photos/ph.jpg';
import i667 from './photos/ph.jpg';
import i668 from './photos/ph.jpg';
import i669 from './photos/ph.jpg';
import i670 from './photos/ph.jpg';
import i671 from './photos/ph.jpg';
import i672 from './photos/ph.jpg';
import i673 from './photos/ph.jpg';
import i674 from './photos/ph.jpg';
import i675 from './photos/ph.jpg';
import i676 from './photos/ph.jpg';
import i677 from './photos/ph.jpg';
import i678 from './photos/ph.jpg';
import i679 from './photos/ph.jpg';
import i680 from './photos/ph.jpg';
import i681 from './photos/ph.jpg';
import i682 from './photos/ph.jpg';
import i683 from './photos/ph.jpg';
import i684 from './photos/ph.jpg';
import i685 from './photos/ph.jpg';
import i686 from './photos/ph.jpg';
import i687 from './photos/ph.jpg';
import i688 from './photos/ph.jpg';
import i689 from './photos/ph.jpg';
import i690 from './photos/ph.jpg';
import i691 from './photos/ph.jpg';
import i692 from './photos/ph.jpg';
import i693 from './photos/ph.jpg';
import i694 from './photos/ph.jpg';
import i695 from './photos/ph.jpg';
import i696 from './photos/ph.jpg';
import i697 from './photos/ph.jpg';
import i698 from './photos/ph.jpg';
import i699 from './photos/ph.jpg';
import i700 from './photos/ph.jpg';
import i701 from './photos/ph.jpg';
import i702 from './photos/ph.jpg';
import i703 from './photos/ph.jpg';
import i704 from './photos/ph.jpg';
import i705 from './photos/ph.jpg';
import i706 from './photos/ph.jpg';
import i707 from './photos/ph.jpg';
import i708 from './photos/ph.jpg';
import i709 from './photos/ph.jpg';
import i710 from './photos/ph.jpg';
import i711 from './photos/ph.jpg';
import i712 from './photos/ph.jpg';
import i713 from './photos/ph.jpg';
import i714 from './photos/ph.jpg';
import i715 from './photos/ph.jpg';
import i716 from './photos/ph.jpg';
import i717 from './photos/ph.jpg';
import i718 from './photos/ph.jpg';
import i719 from './photos/ph.jpg';
import i720 from './photos/ph.jpg';
import i721 from './photos/ph.jpg';
import i722 from './photos/ph.jpg';
import i723 from './photos/ph.jpg';
import i724 from './photos/ph.jpg';
import i725 from './photos/ph.jpg';
import i726 from './photos/ph.jpg';
import i727 from './photos/ph.jpg';
import i728 from './photos/ph.jpg';
import i729 from './photos/ph.jpg';
import i730 from './photos/ph.jpg';
export const SKU_IMG: Record<string,string> = {
  'K5X6X': iK5X6X,
  '22R5S': i0,
  '236JR': i1,
  '2392G': i2,
  '25SG2': i3,
  '26PH6': i4,
  '27BUF': i5,
  '29ZVW': i6,
  '2H5BM': i7,
  '2HGJM': i8,
  '2K88T': i9,
  '2L7F6': i10,
  '2MEPU': i11,
  '2MY47': i12,
  '2PEWV': i13,
  '2QZCF': i14,
  '2R8CG': i15,
  '2SG3U': i16,
  '2SPMZ': i17,
  '2SQVN': i18,
  '2SX3C': i19,
  '2TKLA': i20,
  '2TUYR': i21,
  '2U6VK': i22,
  '2UXEF': i23,
  '2WX8J': i24,
  '2XFQ9': i25,
  '2ZJN6': i26,
  '32C3R': i27,
  '34P2D': i28,
  '36F3U': i29,
  '3ARHP': i30,
  '3CDSX': i31,
  '3FU76': i32,
  '3GWGW': i33,
  '3K492': i34,
  '3KCNX': i35,
  '3NPNU': i36,
  '3PDUS': i37,
  '3RV2J': i38,
  '3TQ9T': i39,
  '3UA83': i40,
  '3VV8F': i41,
  '3WHUT': i42,
  '3XF76': i43,
  '3YJUJ': i44,
  '446ND': i45,
  '44M35': i46,
  '46LKM': i47,
  '47YBJ': i48,
  '48L98': i49,
  '495AG': i50,
  '4A3KY': i51,
  '4ARE2': i52,
  '4AUUJ': i53,
  '4CKMF': i54,
  '4GV94': i55,
  '4LRMY': i56,
  '4MFST': i57,
  '4MYMU': i58,
  '4NPSJ': i59,
  '4PRKE': i60,
  '4RDB4': i61,
  '4RLA4': i62,
  '4TRD9': i63,
  '4UCR7': i64,
  '4UGRX': i65,
  '4UN55': i66,
  '4VY58': i67,
  '4WLMJ': i68,
  '4WXZB': i69,
  '4X3YX': i70,
  '4X93S': i71,
  '4XL6B': i72,
  '4ZRSS': i73,
  '53MEE': i74,
  '549YM': i75,
  '577AW': i76,
  '593ZA': i77,
  '5AJH4': i78,
  '5BFLJ': i79,
  '5BJF9': i80,
  '5DEKD': i81,
  '5EWBA': i82,
  '5FNB2': i83,
  '5FSYX': i84,
  '5G3KN': i85,
  '5H4ND': i86,
  '5HRN2': i87,
  '5J4US': i88,
  '5LZG4': i89,
  '5N5LT': i90,
  '5NWJ2': i91,
  '5PQ83': i92,
  '5QL8B': i93,
  '5QYV2': i94,
  '5RBAQ': i95,
  '5TPD2': i96,
  '5U9PR': i97,
  '5VCH5': i98,
  '5WFH6': i99,
  '5XN47': i100,
  '5YPV8': i101,
  '64LE6': i102,
  '66X75': i103,
  '683EL': i104,
  '68V7T': i105,
  '69AGB': i106,
  '69XLQ': i107,
  '6C5HT': i108,
  '6E49D': i109,
  '6EVN5': i110,
  '6GNA4': i111,
  '6J4NL': i112,
  '6KCPK': i113,
  '6LFPR': i114,
  '6LV4M': i115,
  '6NCZL': i116,
  '6NLTK': i117,
  '6Q7XV': i118,
  '6TVBS': i119,
  '6TWWW': i120,
  '6WZ8M': i121,
  '6XVJG': i122,
  '6Y62F': i123,
  '7253J': i124,
  '72LYV': i125,
  '73NSX': i126,
  '749J9': i127,
  '74VWU': i128,
  '75LHR': i129,
  '76A2W': i130,
  '77HVD': i131,
  '783YK': i132,
  '787UW': i133,
  '78UU7': i134,
  '7BK6U': i135,
  '7BSBN': i136,
  '7DNGM': i137,
  '7FLTC': i138,
  '7G97R': i139,
  '7HDEX': i140,
  '7KLXF': i141,
  '7NCPM': i142,
  '7NMAB': i143,
  '7Q8UJ': i144,
  '7QPWH': i145,
  '7R6JL': i146,
  '7RAP3': i147,
  '7RNQP': i148,
  '7SFMW': i149,
  '7STZN': i150,
  '7T9SP': i151,
  '7W35Z': i152,
  '7WHVV': i153,
  '7XMH5': i154,
  '7YSQS': i155,
  '7ZVGC': i156,
  '83X4B': i157,
  '8656E': i158,
  '86D5W': i159,
  '88EH8': i160,
  '8CNJT': i161,
  '8D3HZ': i162,
  '8DLET': i163,
  '8EBVJ': i164,
  '8F9H6': i165,
  '8HBV7': i166,
  '8HLS7': i167,
  '8JDWN': i168,
  '8KK4Z': i169,
  '8LRBW': i170,
  '8N9QB': i171,
  '8NSHU': i172,
  '8P78D': i173,
  '8PETJ': i174,
  '8QDK8': i175,
  '8STP6': i176,
  '8T9NS': i177,
  '8VBDF': i178,
  '8VK8D': i179,
  '8YW74': i180,
  '9354Q': i181,
  '93CJR': i182,
  '94LKQ': i183,
  '95KS8': i184,
  '9EZCB': i185,
  '9FPKH': i186,
  '9H645': i187,
  '9H8SC': i188,
  '9KXFQ': i189,
  '9PJ3T': i190,
  '9QVDQ': i191,
  '9R5VC': i192,
  '9V2BV': i193,
  '9Y5E4': i194,
  'A2AD2': i195,
  'A37M8': i196,
  'A3T4V': i197,
  'A5SQ6': i198,
  'A6L85': i199,
  'A827U': i200,
  'AB6SF': i201,
  'AC45G': i202,
  'ACLDT': i203,
  'AEDDC': i204,
  'AEW3Y': i205,
  'AJCEY': i206,
  'AJUSL': i207,
  'AK2QV': i208,
  'ALKSU': i209,
  'ALZ2J': i210,
  'AM425': i211,
  'AMWRA': i212,
  'AP3AH': i213,
  'AQX2R': i214,
  'ARF9J': i215,
  'ATGRU': i216,
  'ATRTX': i217,
  'AU2P8': i218,
  'AVS3K': i219,
  'AW5N5': i220,
  'AW64D': i221,
  'AXUV5': i222,
  'AYKRC': i223,
  'AZL26': i224,
  'B2QNU': i225,
  'B3G3X': i226,
  'B4AML': i227,
  'B4QJ9': i228,
  'B7JW6': i229,
  'B8QRS': i230,
  'B9RAF': i231,
  'B9V37': i232,
  'BCE6W': i233,
  'BE78H': i234,
  'BFQDY': i235,
  'BL4HB': i236,
  'BPVH7': i237,
  'BQ2U7': i238,
  'BQ5GP': i239,
  'BQV7U': i240,
  'BQWZF': i241,
  'BRK7B': i242,
  'BXDXB': i243,
  'BXHN5': i244,
  'BXK85': i245,
  'BXRLQ': i246,
  'C26KJ': i247,
  'C3AVE': i248,
  'C5NLD': i249,
  'C6KBG': i250,
  'C6X8V': i251,
  'C7BU6': i252,
  'C8596': i253,
  'CB2V2': i254,
  'CE98H': i255,
  'CG64T': i256,
  'CL6M4': i257,
  'CL8MJ': i258,
  'CPGDV': i259,
  'CUCBG': i260,
  'CYLDV': i261,
  'CZGZG': i262,
  'CZQAC': i263,
  'D5768': i264,
  'D6HCT': i265,
  'D7ZYV': i266,
  'DB2NW': i267,
  'DD3G8': i268,
  'DDTE5': i269,
  'DFKZN': i270,
  'DFX4F': i271,
  'DJBZW': i272,
  'DJSHS': i273,
  'DK3FN': i274,
  'DLKPD': i275,
  'DP6RK': i276,
  'DQM7A': i277,
  'DQPAG': i278,
  'DZUJR': i279,
  'E2ZPL': i280,
  'E59GG': i281,
  'EB2JT': i282,
  'EBZ7T': i283,
  'ECDXG': i284,
  'EDA37': i285,
  'EEPNC': i286,
  'EEUDY': i287,
  'EM4GA': i288,
  'ENZEK': i289,
  'EPXY2': i290,
  'ER66G': i291,
  'ERNKD': i292,
  'ET9RL': i293,
  'ETNFM': i294,
  'EUFEP': i295,
  'EVTE7': i296,
  'EX7SB': i297,
  'EZ4W4': i298,
  'EZ5DF': i299,
  'EZMK9': i300,
  'F7B8D': i301,
  'FEGXB': i302,
  'FF8RD': i303,
  'FFACV': i304,
  'FFNV6': i305,
  'FHDST': i306,
  'FK23L': i307,
  'FK924': i308,
  'FM8CU': i309,
  'FMPE2': i310,
  'FNEL8': i311,
  'FPJ5V': i312,
  'FPR8P': i313,
  'FS6RU': i314,
  'FSGGD': i315,
  'FV8P5': i316,
  'FW7JV': i317,
  'FXYQQ': i318,
  'FZJE5': i319,
  'G3FJX': i320,
  'G3TUK': i321,
  'G44YV': i322,
  'G4WXZ': i323,
  'G6N6X': i324,
  'GBACW': i325,
  'GCJ26': i326,
  'GECPZ': i327,
  'GFMBD': i328,
  'GLWKC': i329,
  'GMRBU': i330,
  'GQZ4W': i331,
  'GRCR5': i332,
  'GSEYG': i333,
  'GT4NM': i334,
  'GTV8M': i335,
  'GWWG2': i336,
  'GY7RE': i337,
  'GZRSL': i338,
  'H2RBA': i339,
  'H4UBU': i340,
  'H56YJ': i341,
  'H7UPH': i342,
  'H85RB': i343,
  'H9N6S': i344,
  'HA42Y': i345,
  'HB8FZ': i346,
  'HCDUE': i347,
  'HCKSR': i348,
  'HD4GC': i349,
  'HDAQ7': i350,
  'HDBSL': i351,
  'HEMCB': i352,
  'HER83': i353,
  'HF67F': i354,
  'HH5JR': i355,
  'HKUGB': i356,
  'HLXUL': i357,
  'HMDDY': i358,
  'HNSU2': i359,
  'HPCBY': i360,
  'HPGUE': i361,
  'HPU8R': i362,
  'HPW58': i363,
  'HQKM5': i364,
  'HR2NH': i365,
  'HR7MC': i366,
  'HU7ZL': i367,
  'HUAHY': i368,
  'HVS7M': i369,
  'HWZAA': i370,
  'HZFQS': i371,
  'HZPM3': i372,
  'J5BX9': i373,
  'J5DBH': i374,
  'J7ZMU': i375,
  'J852B': i376,
  'J929U': i377,
  'J9WXJ': i378,
  'JBMRH': i379,
  'JC8T8': i380,
  'JCCQV': i381,
  'JCQM3': i382,
  'JGAPC': i383,
  'JJZG8': i384,
  'JKDB4': i385,
  'JN3EV': i386,
  'JN54C': i387,
  'JP9VG': i388,
  'JPA54': i389,
  'JPJPN': i390,
  'JPS9C': i391,
  'JSSCQ': i392,
  'JSYLA': i393,
  'JTPJN': i394,
  'JVLV8': i395,
  'JWU45': i396,
  'JXREL': i397,
  'JZV45': i398,
  'K27DZ': i399,
  'K5DGR': i400,
  'K5RPX': i401,
  'K79S4': i402,
  'K825K': i403,
  'K9RWQ': i404,
  'KBFL9': i405,
  'KDKZW': i406,
  'KH8LV': i407,
  'KHGMN': i408,
  'KJLFW': i409,
  'KJVBA': i410,
  'KNL3V': i411,
  'KS7FM': i412,
  'KXBAH': i413,
  'KZ5ZQ': i414,
  'KZKHR': i415,
  'KZLHG': i416,
  'KZXQZ': i417,
  'KZZT9': i418,
  'L2X9H': i419,
  'L4QLA': i420,
  'L5YD5': i421,
  'L7B5F': i422,
  'L8QZC': i423,
  'L9728': i424,
  'LE3P2': i425,
  'LH6VU': i426,
  'LHTYB': i427,
  'LKQRX': i428,
  'LP5A8': i429,
  'LPHV5': i430,
  'LQBTB': i431,
  'LQZK6': i432,
  'LR4XS': i433,
  'LR66H': i434,
  'LRBYN': i435,
  'LWCHF': i436,
  'LX7CC': i437,
  'LXS4W': i438,
  'LXX83': i439,
  'LZA9V': i440,
  'M2E9U': i441,
  'M2GQK': i442,
  'M2LNL': i443,
  'M5ZT6': i444,
  'MB8PY': i445,
  'METY7': i446,
  'MFR2M': i447,
  'MFXAN': i448,
  'MHD4U': i449,
  'MHHQU': i450,
  'MJPPV': i451,
  'MLGYM': i452,
  'MM74F': i453,
  'MRVM2': i454,
  'MUURA': i455,
  'MVPS6': i456,
  'MWA3C': i457,
  'MXM78': i458,
  'MYEDS': i459,
  'MYKUD': i460,
  'MZFEV': i461,
  'N5AS8': i462,
  'N5T4D': i463,
  'N85L6': i464,
  'N9EKD': i465,
  'NFEBT': i466,
  'NKZVB': i467,
  'NMGVJ': i468,
  'NMN2W': i469,
  'NN22J': i470,
  'NQ68D': i471,
  'NQSPJ': i472,
  'NT4UJ': i473,
  'NTDER': i474,
  'NTLR6': i475,
  'NW632': i476,
  'NWM2F': i477,
  'NZ4ZY': i478,
  'P2AJX': i479,
  'P5MWS': i480,
  'PB6LV': i481,
  'PC29X': i482,
  'PFBAG': i483,
  'PGCMW': i484,
  'PH5N2': i485,
  'PJVB6': i486,
  'PL8CH': i487,
  'PMJ86': i488,
  'PPCFJ': i489,
  'PPZCM': i490,
  'PQ7RC': i491,
  'PR8VR': i492,
  'PRPD5': i493,
  'PT6WC': i494,
  'PUGA2': i495,
  'PV2RT': i496,
  'PWNRG': i497,
  'PXEYU': i498,
  'PZ6YZ': i499,
  'PZC8D': i500,
  'PZVXV': i501,
  'Q2YWE': i502,
  'Q3X5V': i503,
  'Q478K': i504,
  'Q5L6Q': i505,
  'Q7BYQ': i506,
  'Q87VE': i507,
  'QBDBX': i508,
  'QBGZ7': i509,
  'QCE39': i510,
  'QCV5J': i511,
  'QEJZS': i512,
  'QGPAB': i513,
  'QMJFF': i514,
  'QSWUE': i515,
  'QU5KN': i516,
  'QU7DV': i517,
  'QXG3V': i518,
  'QYFVZ': i519,
  'QYJ97': i520,
  'R2QGX': i521,
  'R359': i522,
  'R360': i523,
  'R361': i524,
  'R362': i525,
  'R366': i526,
  'R367': i527,
  'R368': i528,
  'R574J': i529,
  'R5TWD': i530,
  'R5ZXG': i531,
  'R6GGC': i532,
  'R74UF': i533,
  'R83C2': i534,
  'R99LM': i535,
  'R9BDB': i536,
  'R9VK6': i537,
  'RC5CB': i538,
  'RC6JM': i539,
  'RE382': i540,
  'RG69N': i541,
  'RGB6G': i542,
  'RLU3X': i543,
  'RPJMQ': i544,
  'RRD2A': i545,
  'RUQW9': i546,
  'RWYTT': i547,
  'RXCLN': i548,
  'RYGZG': i549,
  'RYSTK': i550,
  'RZF2R': i551,
  'RZVQL': i552,
  'S2377': i553,
  'S3FDJ': i554,
  'S48GA': i555,
  'S52GJ': i556,
  'S755T': i557,
  'SDP73': i558,
  'SFYAV': i559,
  'SJY9N': i560,
  'SL3YQ': i561,
  'SLTPK': i562,
  'SLZJD': i563,
  'SMBTV': i564,
  'SMNBZ': i565,
  'SNV6H': i566,
  'SPPXB': i567,
  'SQW2A': i568,
  'SSQY4': i569,
  'SSSJ3': i570,
  'SXJBK': i571,
  'T75CL': i572,
  'T8DP9': i573,
  'T9QCX': i574,
  'TDSHW': i575,
  'TEL5T': i576,
  'TESTM': i577,
  'TFJ99': i578,
  'THQ36': i579,
  'TJAKJ': i580,
  'TM2MX': i581,
  'TNDSS': i582,
  'TT796': i583,
  'TTCAT': i584,
  'TTEG2': i585,
  'TUU3S': i586,
  'TV29C': i587,
  'TWNSJ': i588,
  'TX7UU': i589,
  'TXQ7R': i590,
  'TXTYV': i591,
  'U4VA8': i592,
  'U54DA': i593,
  'U5YBX': i594,
  'U7C9K': i595,
  'U7TYU': i596,
  'U82X6': i597,
  'U8TYT': i598,
  'U9QEB': i599,
  'UB8ZX': i600,
  'UCPQ4': i601,
  'UDDC9': i602,
  'UDP5P': i603,
  'UEW8R': i604,
  'UFVNK': i605,
  'UHM7K': i606,
  'UL6N7': i607,
  'URPHW': i608,
  'USQMS': i609,
  'UT3FN': i610,
  'UT85B': i611,
  'UVJQ9': i612,
  'UVUQH': i613,
  'UWAT2': i614,
  'UZ6RS': i615,
  'V28H9': i616,
  'V2PTB': i617,
  'V5CQU': i618,
  'V5EFR': i619,
  'V6FSM': i620,
  'V7FCZ': i621,
  'V83G7': i622,
  'VB54W': i623,
  'VCN65': i624,
  'VCW2P': i625,
  'VE85F': i626,
  'VFGR3': i627,
  'VGFM4': i628,
  'VGLHV': i629,
  'VHVW9': i630,
  'VJFK5': i631,
  'VJKP5': i632,
  'VJVV4': i633,
  'VK7N4': i634,
  'VPQJ9': i635,
  'VPU9V': i636,
  'VR8YM': i637,
  'VSE36': i638,
  'VWU9E': i639,
  'VXC77': i640,
  'VZG3X': i641,
  'VZMTL': i642,
  'W444V': i643,
  'W4E65': i644,
  'W544Y': i645,
  'WATCV': i646,
  'WCEAU': i647,
  'WCGY9': i648,
  'WDVKS': i649,
  'WFV8Z': i650,
  'WGXDG': i651,
  'WGZRA': i652,
  'WLGLC': i653,
  'WMC7R': i654,
  'WSRXV': i655,
  'WUQ4H': i656,
  'WX5NC': i657,
  'WXPGX': i658,
  'X3DLZ': i659,
  'X44VK': i660,
  'X5MBR': i661,
  'X66E7': i662,
  'X7LTX': i663,
  'X7P3F': i664,
  'X9K6A': i665,
  'XC7FL': i666,
  'XCN5A': i667,
  'XDMKD': i668,
  'XE9UG': i669,
  'XEWNV': i670,
  'XLLFV': i671,
  'XPH26': i672,
  'XPM9F': i673,
  'XQLUC': i674,
  'XR8PZ': i675,
  'XUUQR': i676,
  'XVVSA': i677,
  'XW3NG': i678,
  'XXXU6': i679,
  'XZ5QR': i680,
  'XZ68U': i681,
  'XZDVV': i682,
  'Y2DXG': i683,
  'Y45BB': i684,
  'Y7G4R': i685,
  'Y7LN6': i686,
  'Y7XL7': i687,
  'Y8QFJ': i688,
  'YAPCH': i689,
  'YCGAE': i690,
  'YCL3S': i691,
  'YCRV2': i692,
  'YE5SE': i693,
  'YL663': i694,
  'YLMNG': i695,
  'YNTBR': i696,
  'YP8ZM': i697,
  'YPZYH': i698,
  'YS2BQ': i699,
  'YSP85': i700,
  'YUHRE': i701,
  'YUL27': i702,
  'YWPQV': i703,
  'YXN5E': i704,
  'YYGTW': i705,
  'Z257Y': i706,
  'Z2G87': i707,
  'Z49HF': i708,
  'Z4YGS': i709,
  'Z7M4T': i710,
  'Z8CK2': i711,
  'Z8EUR': i712,
  'Z8KW2': i713,
  'ZCDZN': i714,
  'ZDATE': i715,
  'ZENAC': i716,
  'ZF8W5': i717,
  'ZFQER': i718,
  'ZFZFS': i719,
  'ZJPHT': i720,
  'ZKX5Y': i721,
  'ZKYRX': i722,
  'ZLMVV': i723,
  'ZNB7D': i724,
  'ZQTME': i725,
  'ZU3QX': i726,
  'ZVJXH': i727,
  'ZVXMR': i728,
  'ZWVL8': i729,
  'ZX5Q9': i730,
};
import g1 from './photos/gal/GMRBU-1.jpg';
import g2 from './photos/gal/GMRBU-2.jpg';
import g3 from './photos/gal/GMRBU-3.jpg';
import g4 from './photos/gal/GMRBU-4.jpg';
import g5 from './photos/gal/GMRBU-5.jpg';
import gk2 from './photos/gal/K5X6X-2.jpg';
export const SKU_GALLERY: Record<string, string[]> = { GMRBU: [g1, g2, g3, g4, g5], K5X6X: [iK5X6X, gk2] };
export const SKU_HIGHLIGHTS: Record<string, { q?: string; a?: string; rows: [string, string][] }> = {
  K5X6X: {
    rows: [['Manufacturer', 'MYK Laticrete India Pvt. Ltd.'], ['Product', 'LATICRETE® 303 Floor and Wall Tile Adhesive'], ['Type', 'Single-Component Polymer-Based Economy Thin-Set Mortar'], ['Pack Size', '20 kg bag'], ['Colour', 'Grey'], ['Water Mixing Ratio', '4.2 to 4.8 litres of water per 20 kg bag'], ['Application', 'Interior wall and floor tile installations in dry areas']],
  },
  GMRBU: {
    q: 'What is Ultratech PPC Cement used for?',
    a: 'Ultratech PPC Cement is a premium Portland Pozzolana Cement with superior workability and smooth finish, designed for masonry and plastering operations with eco-friendly pozzolanic materials that reduce heat generation and minimize cracking in humid climates.',
    rows: [['Grade', 'Portland Pozzolana Cement (PPC)'], ['Packaging Size', '50 Kg Bag'], ['Composition', 'Pozzolanic materials including fly ash'], ['Heat of Hydration', 'Low (reduces cracking risk)'], ['Best Before', '3 months from manufacturing date']],
  },
};
export const SKU_DESC: Record<string, { p: string[]; specs: [string, string][]; apps: [string, string][]; steps: [string, string][] }> = {
  GMRBU: {
    p: [
      'Ultratech PPC Cement is trusted by builders and homeowners across Hyderabad for its superior workability and smooth finish in masonry and plastering operations. Enhanced with pozzolanic materials like fly ash, it offers an eco-friendly alternative to traditional OPC cement with reduced CO₂ emissions.',
      "This PPC cement develops strength steadily over time, often matching or surpassing the long-term strength of OPC, while generating less heat during curing—a key benefit in Hyderabad's humid climate that minimizes thermal cracking and ensures durable, long-lasting construction.",
    ],
    specs: [['Cement Type', 'Grey Portland Pozzolana Cement (PPC)'], ['Packaging', '50 Kg per bag'], ['Composition', 'Pozzolanic materials (fly ash) blended with Portland cement'], ['Storage', 'Dry, ventilated area away from moisture; use within 3 months']],
    apps: [['Masonry and Brickwork', 'Superior adhesion for brick and block work in residential and commercial construction'], ['Plastering Works', 'Smooth finish for interior and exterior wall surfaces with excellent workability'], ['Grouting Applications', 'Effective for filling gaps, voids, and joints in construction projects'], ['Repair and Restoration', 'Ideal for maintenance, patching, and restoration work on existing structures'], ['Foundation Work', 'Suitable for non-load bearing concrete structures and general construction']],
    steps: [['Storage Check', 'Ensure cement bags are stored in dry, ventilated area and are within 3 months of manufacturing date'], ['Mix Preparation', 'Mix cement with clean water and sand in recommended proportions for your specific application (masonry or plastering)'], ['Application', 'Apply mixed mortar evenly using appropriate tools; work in manageable sections for best results'], ['Curing', 'Keep applied surfaces moist for 7-14 days to ensure proper strength development and minimize cracking']],
  },
};
export const SKU_RETURNS: Record<string, { lead: string; intro: string; items: string[]; foot: string }> = {
  GMRBU: { lead: 'This product is non-returnable.', intro: 'Replacement available within 24 hours of delivery for:', items: ['Damaged or defective product', 'Wrong or missing item', 'Product cannot be returned once installed or used'], foot: 'Refer to Refund Policy for complete details' },
};

export type DescBlock = { h?: string; sub?: string; p?: string[]; list?: string[][]; ol?: string[][]; table?: string[][] };
export const SKU_DOC: Record<string, DescBlock[]> = {
  K5X6X: [
 {
  "p": [
   "MYK Laticrete LATICRETE® 303 is a factory-blended, single-component, polymer-modified economy thin-set mortar for interior tile installations on stable masonry substrates. Add clean water, mix to a smooth paste, and apply - no on-site blending of multiple components required. Provides excellent tack, non-sag performance, and spreadability for fixing standard ceramic tiles and small-format natural stones on cement mortar beds, cement plaster, brick masonry, and cement terrazzo. Practically nil VOC. Suitable for interior dry area residential and commercial projects where reliable, code-compliant performance is required at an economical cost."
  ]
 },
 {
  "h": "Key Features",
  "list": [
   [
    "Single-Component - Just Add Water",
    "No on-site blending of multiple materials - reduces handling errors and labour time"
   ],
   [
    "Economical Formulation",
    "Budget-friendly polymer-modified mortar optimised for standard interior ceramic tile projects"
   ],
   [
    "Good Substrate Adhesion",
    "Bonds securely to cement plaster, brick walls, terrazzo, and concrete floor beds"
   ],
   [
    "Non-Sag and Spreadable",
    "Smooth, workable consistency for easy application and tile alignment"
   ],
   [
    "Practically Nil VOC",
    "Safer indoor air quality for enclosed residential and commercial spaces"
   ]
  ]
 },
 {
  "h": "Technical Specifications",
  "sub": "Technical Specifications (Quick Reference)",
  "table": [
   [
    "Specification",
    "Details"
   ],
   [
    "Manufacturer",
    "MYK Laticrete India Pvt. Ltd."
   ],
   [
    "Product",
    "LATICRETE® 303 Floor and Wall Tile Adhesive"
   ],
   [
    "Chemical Form",
    "Polymer-Modified Cementitious Powder"
   ],
   [
    "Colour",
    "Grey"
   ],
   [
    "Pack Size",
    "20 kg bag"
   ],
   [
    "Standards",
    "IS 15477:2019 Type 1T, EN 12004 / ISO 13007 C1T, Meets ANSI A118.1 T"
   ],
   [
    "VOC Content",
    "Practically Nil"
   ]
  ]
 },
 {
  "h": "Application Guidelines",
  "sub": "Step-by-Step Application",
  "ol": [
   [
    "Surface preparation",
    "Substrate must be structurally sound, fully cured, dry, and free from laitance, sealers, oils, and dust"
   ],
   [
    "Mix",
    "Add 4.2 to 4.8 litres of clean water to a clean bucket, slowly add the powder, and mix with a slow-speed paddle until smooth and lump-free. Slake for 5 minutes, then remix briefly before use"
   ],
   [
    "Spread",
    "Press the mortar firmly into the substrate with the flat trowel edge, then comb horizontally with a square-notched trowel to form uniform ridges"
   ],
   [
    "Set tiles",
    "Bed tiles into the wet ridges within 10 minutes. Tap firmly with a rubber mallet for full, hollow-free coverage"
   ]
  ]
 },
 {
  "h": "Recommended Applications",
  "sub": "Where LATICRETE® 303 fits best",
  "list": [
   [
    "Interior floor tiles",
    "Standard-format ceramic tiles in living rooms and bedrooms on concrete floor beds"
   ],
   [
    "Interior wall tiles",
    "Kitchen backsplashes and bathroom walls over dry cement plaster, terrazzo, or brick masonry"
   ],
   [
    "Small-format natural stone",
    "Small natural stone elements and interior mosaic border strips on stable masonry bases"
   ]
  ]
 }
],
};
