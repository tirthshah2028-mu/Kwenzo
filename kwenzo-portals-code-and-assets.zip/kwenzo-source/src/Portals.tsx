import { tr, useLanguage } from './i18n';
import React, { useState } from 'react';
import { VendorPortal, AdminVendors } from './Vendor';
import { ProofShot } from './Proof';
import { PRODUCTS, SUPPLIERS, CATS, VEHICLES, supplierFor, priceAt, inr, type Order, type Status, type Settings, type App_ } from './data';
import { Icon } from './Icon';
import skuData from './skus.json';
import { Onboarding } from './Onboarding';

export type Role = 'customer' | 'supplier' | 'logistics' | 'admin';
export const STATUS_LABEL: Record<Status, string> = { placed: 'New', accepted: 'Accepted', packed: 'Packed, awaiting pickup', dispatched: 'Out for delivery', delivered: 'Delivered', cancelled: 'Cancelled' };
const pname = (id: string): any => id.startsWith('sku:') ? { name: (skuData as any[]).find(s => s.c === id.slice(4))?.n || id } : PRODUCTS.find(p => p.id === id)!;
const VENDORS = SUPPLIERS.filter(s => s.id !== 'kz');
const sname = (id: string) => SUPPLIERS.find(s => s.id === id)!;
const ago = (t: number) => { const m = Math.max(1, Math.round((Date.now() - t) / 60000)); return m < 60 ? m + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : Math.round(m / 1440) + ' d ago'; };
const Chip = ({ s }: { s: Status }) => <span className={'pt-chip s-' + s}>{tr(STATUS_LABEL[s])}</span>;
const Kpi = ({ l, v, sub }: { l: string; v: string; sub?: string }) => <div className="pt-kpi"><span>{tr(l)}</span><b>{tr(v)}</b>{tr(sub && <em>{tr(sub)}</em>)}</div>;
const Tabs = ({ tabs, v, set }: { tabs: [string, string][]; v: string; set: (t: string) => void }) => <div className="pt-tabs">{tr(tabs.map(([k, l]) => <button key={k} className={v === k ? 'on' : ''} onClick={() => set(k)}>{tr(l)}</button>))}</div>;
const itemsText = (o: Order) => o.lines.map(l => pname(l.pid).name + ' x ' + l.qty).join(', ');

type PP = { orders: Order[]; setOrders: (o: Order[]) => void; settings: Settings; setSettings: (s: Settings) => void; apps: App_[]; setApps: (a: App_[]) => void };
const setStatus = (orders: Order[], setOrders: (o: Order[]) => void, id: string, patch: Partial<Order>) => setOrders(orders.map(o => o.id === id ? { ...o, ...patch } : o));

export function Portal({ role, phone, ...p }: PP & { role: Role; phone?: string }) {
  if (role === 'supplier') return <Supplier {...p} phone={phone} />;
  if (role === 'logistics') return <Logistics {...p} />;
  return <Admin {...p} />;
}

function Head({ title, sub, children }: { title: string; sub: string; children?: React.ReactNode }) {
  return <div className="pt-head"><div><span className="nv-pill dark">{tr(sub)}</span><h1>{tr(title)}</h1></div>{tr(children)}</div>;
}

function Supplier({ orders, setOrders, settings, phone, apps }: PP & { phone?: string }) {
  const [sid, setSid] = useState('kz'); const [tab, setTab] = useState('orders');
  const [inv, setInv] = useState<Record<string, { p?: number; off?: boolean }>>({});
  const mine = orders.filter(o => o.sid === sid);
  const open = mine.filter(o => o.status === 'placed' || o.status === 'accepted' || o.status === 'packed');
  const del = mine.filter(o => o.status === 'delivered');
  const gross = del.reduce((a, o) => a + o.total, 0);
  const fee = Math.round(gross * settings.commission / 100);
  const list = tab === 'orders' ? mine : [];
  const act = (o: Order) => o.status === 'placed' ? <><button className="nv-btn" onClick={() => setStatus(orders, setOrders, o.id, { status: 'accepted' })}>{tr("Accept order")}</button><button className="nv-btn ghost" onClick={() => setStatus(orders, setOrders, o.id, { status: 'cancelled' })}>{tr("Decline")}</button></>
    : o.status === 'accepted' ? <button className="nv-btn" onClick={() => setStatus(orders, setOrders, o.id, { status: 'packed' })}>{tr("Mark packed")}</button>
    : o.status === 'packed' ? <span className="pt-note">{tr("Waiting for a logistics partner to pick up")}</span>
    : o.status === 'dispatched' ? <span className="pt-note">{tr("With driver ")}{tr(o.vehicle)}</span> : null;
  const prods = PRODUCTS.filter(p => supplierFor(p.id).some(s => s.id === sid));
  return <main className="pt">
    <Head title={tr(apps.find(a => a.phone === phone)?.shop || "Dealer dashboard")} sub={tr("Supplier dashboard")}></Head>
    <div className="pt-kpis"><Kpi l={tr("Open orders")} v={String(open.length)} sub={tr("need action")} /><Kpi l={tr("Delivered")} v={String(del.length)} /><Kpi l={tr("Sales delivered")} v={inr(gross)} /><Kpi l={tr('Payout after ' + settings.commission + '% fee')} v={inr(gross - fee)} /></div>
    <Tabs tabs={[['orders', 'Orders'], ['inv', 'Inventory and prices'], ['pay', 'Earnings']]} v={tab} set={setTab} />
    {tr(tab === 'orders' && (list.length === 0 ? <div className="nv-empty"><h3>{tr("No orders yet")}</h3><p>{tr("Orders placed on Kwenzo for your store show up here.")}</p></div> : <div className="pt-list">{tr([...list].sort((a, b) => b.at - a.at).map(o => <div className="pt-card" key={o.id}>
      <div className="pt-row"><b>{tr(o.id)}</b><Chip s={o.status} /></div>
      <p>{tr(itemsText(o))}</p><p className="pt-note">{tr(o.name)} · {tr(o.addr)}, {tr(o.pin)} · {tr(o.pay)}</p>
      <div className="pt-row"><b>{tr(inr(o.total))}</b><div className="pt-acts">{tr(act(o))}</div></div></div>))}</div>))}
    {tr(tab === 'inv' && <div className="pt-table"><div className="pt-tr h"><span>{tr("Product")}</span><span>{tr("Price per unit")}</span><span>{tr("In stock")}</span></div>{tr(prods.map(pr => { const s = sname(sid); const cur = inv[pr.id]; const price = cur?.p ?? priceAt(pr, s); return <div className="pt-tr" key={pr.id}><span><b>{tr(pr.name)}</b><em>{tr(pr.brand)}{tr(" · per ")}{tr(pr.unit)}</em></span>
      <span><input className="pt-in" inputMode="numeric" value={price} onChange={e => setInv({ ...inv, [pr.id]: { ...cur, p: Number(e.target.value.replace(/[^\d.]/g, '')) || 0 } })} aria-label={tr('Price ' + pr.name)} /></span>
      <span><label className="pt-sw"><input type="checkbox" checked={!cur?.off} onChange={e => setInv({ ...inv, [pr.id]: { ...cur, off: !e.target.checked } })} /><i />{tr(cur?.off ? 'Out of stock' : 'Available')}</label></span></div>; }))}</div>)}
    {tr(tab === 'pay' && <div className="pt-card"><h3>{tr("Earnings summary")}</h3><div className="pt-sum"><div><span>{tr("Delivered sales")}</span><b>{tr(inr(gross))}</b></div><div><span>{tr("Kwenzo fee (")}{tr(settings.commission)}%)</span><b>- {tr(inr(fee))}</b></div><div className="tot"><span>{tr("Payout")}</span><b>{tr(inr(gross - fee))}</b></div></div><p className="pt-note">{tr("Payouts are settled to your bank account once orders are marked delivered.")}</p></div>)}
  </main>;
}

function Logistics({ orders, setOrders }: PP) {
  const [tab, setTab] = useState('queue'); const [pick, setPick] = useState<Record<string, string>>({});
  const busy = new Set(orders.filter(o => o.status === 'dispatched' && o.vehicle).map(o => o.vehicle!));
  const free = VEHICLES.filter(v => !busy.has(v.id));
  const queue = orders.filter(o => o.status === 'packed'); const transit = orders.filter(o => o.status === 'dispatched');
  const done = orders.filter(o => o.status === 'delivered');
  return <main className="pt">
    <Head title={tr("Dispatch and fleet")} sub={tr("Logistics dashboard")} />
    <div className="pt-kpis"><Kpi l={tr("Awaiting pickup")} v={String(queue.length)} /><Kpi l={tr("On the road")} v={String(transit.length)} /><Kpi l={tr("Vehicles free")} v={free.length + ' of ' + VEHICLES.length} /><Kpi l={tr("Delivered")} v={String(done.length)} /></div>
    <Tabs tabs={[['queue', 'Dispatch queue'], ['transit', 'In transit'], ['fleet', 'Fleet']]} v={tab} set={setTab} />
    {tr(tab === 'queue' && (queue.length === 0 ? <div className="nv-empty"><h3>{tr("Nothing waiting")}</h3><p>{tr("Orders appear here once a dealer marks them packed.")}</p></div> : <div className="pt-list">{tr(queue.map(o => { const v = pick[o.id] || free[0]?.id; return <div className="pt-card" key={o.id}>
      <div className="pt-row"><b>{tr(o.id)}</b><Chip s={o.status} /></div>
      <div className="pt-route"><div><span>{tr("Pickup")}</span><b>{tr(sname(o.sid).name)}</b><em>{tr(sname(o.sid).area)}</em></div><Icon n="truck" size={22} /><div><span>{tr("Drop")}</span><b>{tr(o.addr)}</b><em>{tr(o.pin)}</em></div></div>
      <p className="pt-note">{tr(itemsText(o))}</p>
      <ProofShot label={tr("Pickup proof (photo of the material at pickup)")} value={o.pPick} onChange={v => setStatus(orders, setOrders, o.id, { pPick: v })} />
      <div className="pt-row">{tr(free.length === 0 ? <span className="pt-note">{tr("All vehicles are on the road")}</span> : <><select className="pt-in wide" value={v} onChange={e => setPick({ ...pick, [o.id]: e.target.value })} aria-label={tr("Vehicle")}>{tr(free.map(f => <option key={f.id} value={f.id}>{tr(f.type)} · {tr(f.id)} · {tr(f.driver)}</option>))}</select><button className="nv-btn" disabled={!o.pPick} title={tr(o.pPick ? '' : 'Add the pickup photo first')} onClick={() => { if (o.pPick) setStatus(orders, setOrders, o.id, { status: 'dispatched', vehicle: v }); }}>{tr("Assign and dispatch")}</button>{tr(!o.pPick && <span className="pt-note">{tr("Add the pickup photo to dispatch")}</span>)}</>)}</div></div>; }))}</div>))}
    {tr(tab === 'transit' && (transit.length === 0 ? <div className="nv-empty"><h3>{tr("No deliveries on the road")}</h3></div> : <div className="pt-list">{tr(transit.map(o => { const v = VEHICLES.find(x => x.id === o.vehicle); return <div className="pt-card" key={o.id}>
      <div className="pt-row"><b>{tr(o.id)}</b><Chip s={o.status} /></div><p>{tr(v?.type)} · {tr(o.vehicle)} · {tr(v?.driver)}</p><p className="pt-note">{tr("Deliver to ")}{tr(o.addr)}, {tr(o.pin)}{tr(" · customer ")}{tr(o.name)}, {tr(o.phone)}</p>
      <ProofShot label={tr("Proof of delivery (photo at drop)")} value={o.pDel} onChange={v => setStatus(orders, setOrders, o.id, { pDel: v })} />
      <div className="pt-row"><button className="nv-btn" disabled={!o.pDel} onClick={() => { if (o.pDel) setStatus(orders, setOrders, o.id, { status: 'delivered' }); }}>{tr("Mark delivered")}</button>{tr(!o.pDel && <span className="pt-note">{tr("Add the delivery photo to complete")}</span>)}</div></div>; }))}</div>))}
    {tr(tab === 'fleet' && <div className="pt-table"><div className="pt-tr h"><span>{tr("Vehicle")}</span><span>{tr("Capacity")}</span><span>{tr("Status")}</span></div>{tr(VEHICLES.map(v => { const o = transit.find(x => x.vehicle === v.id); return <div className="pt-tr" key={v.id}><span><b>{tr(v.type)}</b><em>{tr(v.id)} · {tr(v.driver)}</em></span><span>{tr(v.cap)}</span><span><span className={'pt-dot ' + (o ? 'busy' : 'free')} />{tr(o ? 'On trip, ' + o.id : 'Available')}</span></div>; }))}</div>)}
  </main>;
}

function Admin({ orders, setOrders, settings, setSettings, apps, setApps }: PP) {
  const [tab, setTab] = useState('overview'); const [f, setF] = useState('all');
  const pendN = apps.filter(a => a.status === 'pending').length; const prevN = React.useRef(pendN);
  React.useEffect(() => { if (pendN > prevN.current) setTab('dealers'); prevN.current = pendN; }, [pendN]);
  const live = orders.filter(o => o.status !== 'cancelled');
  const gmv = live.reduce((a, o) => a + o.total, 0);
  const delivered = orders.filter(o => o.status === 'delivered');
  const rev = Math.round(delivered.reduce((a, o) => a + o.total, 0) * settings.commission / 100);
  const approved = apps.filter(a => a.v?.live).length;
  const statuses: Status[] = ['placed', 'accepted', 'packed', 'dispatched', 'delivered', 'cancelled'];
  const shown = orders.filter(o => f === 'all' || o.status === f);
  const pending = apps.filter(a => a.status === 'pending').length;
  const num = (k: keyof Settings, v: string) => setSettings({ ...settings, [k]: Number(v.replace(/\D/g, '')) || 0 });
  return <main className="pt">
    <Head title={tr("Marketplace control")} sub={tr("Admin console")} />
    <Tabs tabs={[['overview', 'Overview'], ['orders', 'All orders'], ['proofs', 'Proof photos'], ['dealers', 'Dealers' + (pending ? ' (' + pending + ')' : '')], ['catalog', 'Catalogue'], ['settings', 'Settings']]} v={tab} set={setTab} />
    {tr(pendN > 0 && tab !== 'dealers' && <div className="ac-nudge">{tr(pendN)}{tr(" vendor application")}{tr(pendN > 1 ? 's' : '')}{tr(" waiting for your approval. ")}<button onClick={() => setTab('dealers')}>{tr("Review now")}</button></div>)}
    {tr(tab === 'overview' && <><div className="pt-kpis"><Kpi l={tr("Gross order value")} v={inr(gmv)} /><Kpi l={tr("Orders")} v={String(orders.length)} sub={tr(delivered.length + ' delivered')} /><Kpi l={tr("Active dealers")} v={String(approved)} /><Kpi l={tr("Kwenzo fee earned")} v={inr(rev)} sub={tr(settings.commission + '% on delivered')} /></div>
      <div className="pt-card"><h3>{tr("Orders by stage")}</h3>{tr(statuses.map(s => { const n = orders.filter(o => o.status === s).length; return <div className="pt-bar" key={s}><span>{tr(STATUS_LABEL[s])}</span><div><i style={{ width: (orders.length ? n / orders.length * 100 : 0) + '%' }} /></div><b>{tr(n)}</b></div>; }))}</div>
      <div className="pt-card"><h3>{tr("Dealers by sales")}</h3>{tr(VENDORS.map(s => { const t = live.filter(o => o.sid === s.id).reduce((a, o) => a + o.total, 0); return <div className="pt-bar" key={s.id}><span>{tr(s.name)}</span><div><i style={{ width: (gmv ? t / gmv * 100 : 0) + '%' }} /></div><b>{tr(inr(t))}</b></div>; }))}</div></>)}
    {tr(tab === 'orders' && <><div className="nv-chips"><button className={f === 'all' ? 'on' : ''} onClick={() => setF('all')}>{tr("All")}</button>{tr(statuses.map(s => <button key={s} className={f === s ? 'on' : ''} onClick={() => setF(s)}>{tr(STATUS_LABEL[s].split(',')[0])}</button>))}</div>
      <div className="pt-table"><div className="pt-tr h c4"><span>{tr("Order")}</span><span>{tr("Dealer")}</span><span>{tr("Total")}</span><span>{tr("Status")}</span></div>{tr([...shown].sort((a, b) => b.at - a.at).map(o => <div className="pt-tr c4" key={o.id}><span><b>{tr(o.id)}</b><em>{tr(o.name)}</em></span><span>{tr(sname(o.sid).name)}</span><span>{tr(inr(o.total))}</span><span><select className="pt-in" value={o.status} onChange={e => setStatus(orders, setOrders, o.id, { status: e.target.value as Status })} aria-label={tr("Status")}>{tr(statuses.map(s => <option key={s} value={s}>{tr(STATUS_LABEL[s])}</option>))}</select></span></div>))}</div></>)}
    {tr(tab === 'proofs' && (() => { const pr = [...orders].filter(o => o.pDisp || o.pPick || o.pDel).sort((a, b) => b.at - a.at); return pr.length === 0 ? <div className="nv-empty"><h3>{tr("No proof photos yet")}</h3><p>{tr("Dispatch, pickup and delivery photos appear here with the order ID.")}</p></div> : <div className="pt-list">{tr(pr.map(o => <div className="pt-card" key={o.id}><div className="pt-row"><b>{tr(o.id)}</b><Chip s={o.status} /></div><div className="pf-thumbs">{tr(([['Dispatch proof (dealer)', o.pDisp], ['Pickup proof (logistics)', o.pPick], ['Delivery proof (logistics)', o.pDel]] as [string, string | undefined][]).map(([l, s]) => <div className="pf-box" key={l}><span className="pf-l">{tr(l)}</span>{tr(s ? <img className="pf-img" src={s} alt={tr(l)} /> : <div className="pf-empty">{tr("Not added yet")}</div>)}</div>))}</div></div>))}</div>; })())}
    {tr(tab === 'dealers' && <><h3 className="pt-h3">{tr("Vendor applications")}</h3><AdminVendors apps={apps} setApps={setApps} /></>)}
    {tr(tab === 'catalog' && <div className="pt-table"><div className="pt-tr h"><span>{tr("Category")}</span><span>{tr("Products")}</span><span>{tr("Brands")}</span></div>{tr(CATS.map(c => { const ps = PRODUCTS.filter(p => p.cat === c.id); return <div className="pt-tr" key={c.id}><span><b>{tr(c.name)}</b></span><span>{tr(ps.length)}</span><span>{tr(Array.from(new Set(ps.map(p => p.brand))).join(', '))}</span></div>; }))}</div>)}
    {tr(tab === 'settings' && <div className="pt-card"><h3>{tr("Marketplace settings")}</h3>
      <label className="nv-f"><span>{tr("Kwenzo fee on delivered orders (%)")}</span><input value={settings.commission} inputMode="numeric" onChange={e => num('commission', e.target.value)} /></label>
      <label className="nv-f"><span>{tr("Free delivery above (₹)")}</span><input value={settings.freeAbove} inputMode="numeric" onChange={e => num('freeAbove', e.target.value)} /></label>
      <label className="nv-f"><span>{tr("Delivery fee below that (₹)")}</span><input value={settings.fee} inputMode="numeric" onChange={e => num('fee', e.target.value)} /></label>
      <p className="pt-note">{tr("Delivery rules apply to new customer carts straight away.")}</p></div>)}
  </main>;
}

const COPY: Record<string, { title: string; line: string; pts: string[] }> = {
  supplier: { title: 'Kwenzo for dealers', line: 'Receive orders from builders near you, manage prices and stock, and get paid on delivery.', pts: ['Accept and pack orders in one tap', 'Set your own prices and bulk rates', 'Payouts after the Kwenzo fee'] },
  logistics: { title: 'Kwenzo logistics', line: 'Dispatch packed orders, assign vehicles and drivers, and close deliveries.', pts: ['Pickup and drop on one card', 'Fleet availability at a glance', 'Mark deliveries complete from the road'] },
  admin: { title: 'Kwenzo admin', line: 'Run the marketplace: orders, dealers, catalogue and fees.', pts: ['Live orders by stage', 'Approve new dealer applications', 'Set fees and delivery rules'] },
};
export function PortalPage({ role, ...p }: PP & { role: 'supplier' | 'logistics' | 'admin' }) {
  useLanguage();
  if (role === 'supplier') return <VendorPortal apps={p.apps} setApps={p.setApps} orders={p.orders} setOrders={p.setOrders} itemsText={itemsText} />;
  const [dash, setDash] = useState(false); const [ok, setOk] = useState(false); const [phone, setPhone] = useState(''); const [code, setCode] = useState(''); const [err, setErr] = useState('');
  const c = COPY[role]; const myApp = role === 'supplier' ? p.apps.find(a => a.phone === phone) : undefined;
  const submit = () => { if (!/^[6-9]\d{9}$/.test(phone)) { setErr('Enter a valid 10-digit mobile number.'); return; } if (code !== '1234') { setErr('Enter the demo code 1234.'); return; } setErr(''); if (role === 'supplier' && !p.apps.find(a => a.phone === phone)) p.setApps([...p.apps, { id: 'a' + Date.now(), shop: 'Your store', owner: '', city: 'Hyderabad', phone, status: 'approved' }]); setOk(true); };
  if (!ok) return <div className="nv"><main className="pt-login"><div className="pt-login-l"><div className="nv-logo static"><span className="nv-mark">{tr("K")}</span><span>{tr("Kwenzo")}</span></div><span className="nv-pill">{tr(role === 'supplier' ? 'Supplier sign in' : role === 'logistics' ? 'Logistics sign in' : 'Admin sign in')}</span><h1>{tr(c.title)}</h1><p>{tr(c.line)}</p><ul>{tr(c.pts.map(x => <li key={x}><Icon n="check" size={16} />{tr(x)}</li>))}</ul></div>
    <div className="pt-login-r"><div className="nv-form card" onKeyDown={e => { if (e.key === 'Enter') submit(); }}><h2>{tr("Sign in")}</h2>
      <label className="nv-f"><span>{tr("Mobile number")}</span><input value={phone} inputMode="numeric" maxLength={10} onChange={e => setPhone(e.target.value.replace(/\D/g, ''))} /></label>
      <label className="nv-f"><span>{tr("Code")}</span><input value={code} inputMode="numeric" maxLength={4} onChange={e => setCode(e.target.value.replace(/\D/g, ''))} /></label>
      <p className="pt-note">{tr("Preview only: use any valid mobile number and the demo code 1234.")}{tr(role === 'supplier' && <>{tr(" New dealer? Sign in with your mobile number to start onboarding.")}</>)}</p>{tr(err && <div className="nv-err">{tr(err)}</div>)}<button className="nv-btn big wide" onClick={submit}>{tr("Sign in")}</button></div></div></main></div>;
  return <div className="nv"><header className="nv-head"><div className="nv-logo static-dark"><span className="nv-mark">{tr("K")}</span><span>{tr("Kwenzo")}</span></div><span className="nv-tag2">{tr(c.title.replace('Kwenzo ', '').replace('for ', ''))}</span><button className="nv-btn ghost" onClick={() => { setOk(false); setDash(false); }}>{tr("Sign out")}</button></header>{tr(role === 'supplier' && myApp && !dash ? <Onboarding app={myApp} commission={p.settings.commission} open={() => setDash(true)} save={a => p.setApps(p.apps.map(x => x.id === a.id ? a : x))} /> : <Portal role={role} phone={phone} {...p} />)}</div>;
}
