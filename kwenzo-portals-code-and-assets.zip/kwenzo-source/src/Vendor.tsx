import { tr, useLanguage } from './i18n';
import React, { useState } from 'react';
import { Icon } from './Icon';
import { ProofShot } from './Proof';
import { inr, isServiceable, COMING_SOON, type App_, type Order } from './data';
import { CORE_TERMS, DECLARATION, FOUR_DOCS, JOURNEY, POLICIES, SLAS, KPIS, TIERS, SCORE_WEIGHTS, VCATS, KYC, PRODDOCS } from './Policies';

type Apps = { apps: App_[]; setApps: (a: App_[]) => void; orders?: Order[]; setOrders?: (o: Order[]) => void; itemsText?: (o: Order) => string };
const today = () => new Date().toISOString().slice(0, 10);
const BT = ['Manufacturer', 'Distributor', 'Wholesaler', 'Retailer', 'Importer', 'Dealer'];
const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const POST = ['Catalogue', 'Pricing', 'Logistics', 'SLA', 'Agreement', 'Test order', 'Go live'];
const GSTRE = /^\d{2}[A-Z]{5}\d{4}[A-Z][A-Z\d]Z[A-Z\d]$/;

const F = ({ l, e, children, wide }: { l: string; e?: string; children: React.ReactNode; wide?: boolean }) => <label className={'nv-f' + (e ? ' bad' : '') + (wide ? ' vp-wide' : '')}><span>{tr(l)}</span>{tr(children)}{tr(e && <em>{tr(e)}</em>)}</label>;
const Acc = ({ t, children, open }: { t: string; children: React.ReactNode; open?: boolean }) => <details className="ms-acc vp-acc" open={open}><summary>{tr(t)}</summary><div className="ms-acc-b">{tr(children)}</div></details>;
const Check = ({ v, set, children, e }: { v: boolean; set: (b: boolean) => void; children: React.ReactNode; e?: string }) => <label className={'ob-agree' + (e ? ' bad' : '')}><input type="checkbox" checked={v} onChange={e2 => set(e2.target.checked)} /><span>{tr(children)}</span></label>;
const FileIn = ({ name, set, label, multiple }: { name?: string; set: (n: string) => void; label?: string; multiple?: boolean }) => <div className="vp-file"><label className="nv-btn ghost ob-up">{tr(name ? 'Replace' : (label || 'Upload'))}<input type="file" multiple={multiple} accept="image/*,.pdf,.xlsx,.xls,.doc,.docx" onChange={e => { const fs = Array.from(e.target.files || []); if (fs.length) set(fs.map(f => f.name).join(', ')); }} /></label>{tr(name && <em>{tr(name)}</em>)}</div>;
const PolicyList = () => <div className="vp-pol">{tr(POLICIES.map(p => <Acc key={p.t} t={tr(p.t)}><ul>{tr(p.b.map((x, i) => <li key={i}>{tr(x)}</li>))}</ul></Acc>))}</div>;
const CoreTerms = () => <ol className="vp-terms">{tr(CORE_TERMS.map((t, i) => <li key={i}>{tr(t)}</li>))}</ol>;
const Docs4 = () => <div className="vp-four">{tr(FOUR_DOCS.map(([t, d, s], i) => <div className="pt-card" key={t}><b>{tr(i + 1)}. {tr(t)}</b><p>{tr(d)}</p><em>{tr(s)}</em></div>))}</div>;
const Journey = ({ cur }: { cur: number }) => <ol className="vp-journey">{tr(JOURNEY.map((s, i) => <li key={s} className={i < cur ? 'done' : i === cur ? 'cur' : ''}><i>{tr(i < cur ? <Icon n="check" size={13} /> : i + 1)}</i><span>{tr(s)}</span></li>))}</ol>;
const Score = () => <div><h3 className="pt-h3">{tr("Kwenzo Vendor Score")}</h3><div className="pt-table"><div className="pt-tr h"><span>{tr("Component")}</span><span>{tr("Weight")}</span></div>{tr(SCORE_WEIGHTS.map(([k, v]) => <div className="pt-tr" key={k}><span>{tr(k)}</span><span>{tr(v)}</span></div>))}</div>
  <p className="pt-note">{tr("Green: 90+. Yellow: 75 to 89. Red: below 75.")}</p>
  <h3 className="pt-h3">{tr("Vendor Scorecard KPIs")}</h3><div className="pt-table"><div className="pt-tr h"><span>{tr("KPI")}</span><span>{tr("Target")}</span></div>{tr(KPIS.map(([k, v]) => <div className="pt-tr" key={k}><span>{tr(k)}</span><span>{tr(v)}</span></div>))}</div>
  <p className="pt-note">{tr("Vendor classification: ")}{tr(TIERS.join(' > '))}{tr(". It influences search ranking, order allocation and preferred-vendor status.")}</p></div>;

const newReg = (phone = '') => ({ firm: '', owner: '', regAddr: '', whAddr: '', whPin: '', sameBill: true, billAddr: '', contact: '', mobile: phone, email: '', years: '', btype: '', constitution: '', gstin: '', cats: [] as string[], open: '', close: '', holidays: [] as string[], user: '', pass: '' });
const newBank = () => ({ holder: '', bank: '', acc: '', ifsc: '', cheque: '', upi: '', gstName: '' });
const newDecl = () => ({ core: false, agr: false, dec: false, vname: '', auth: '', desig: '', date: today(), sign: '', stamp: '' });

function Apply({ initial, phone, submit, cancel }: { initial?: any; phone: string; submit: (v: any) => void; cancel: () => void }) {
  const [step, setStep] = useState(0);
  const [reg, setReg] = useState<any>(initial?.reg || newReg(phone));
  const [docs, setDocs] = useState<Record<string, string>>(initial?.docs || {});
  const [na, setNa] = useState<Record<string, boolean>>(initial?.na || {});
  const [bank, setBank] = useState<any>(initial?.bank || newBank());
  const [decl, setDecl] = useState<any>(initial?.decl || newDecl());
  const [err, setErr] = useState<Record<string, string>>({});
  const R = (k: string, v: any) => setReg({ ...reg, [k]: v });
  const B = (k: string, v: any) => setBank({ ...bank, [k]: v });
  const D = (k: string, v: any) => setDecl({ ...decl, [k]: v });
  const kycDocs = KYC[reg.constitution] || [];
  const prodDocs = Array.from(new Set(reg.cats.flatMap((c: string) => PRODDOCS[c] || [])));
  const validate = (s: number) => {
    const o: Record<string, string> = {}; const m = (k: string, ok: boolean, msg: string) => { if (!ok) o[k] = msg; };
    if (s === 0) {
      m('firm', reg.firm.trim().length > 1, 'Enter the business / firm name.'); m('owner', reg.owner.trim().length > 1, 'Enter the proprietor / partner / director name.');
      m('constitution', !!reg.constitution, 'Choose the constitution of the business.'); m('btype', !!reg.btype, 'Choose the type of business.');
      m('regAddr', reg.regAddr.trim().length > 5, 'Enter the registered business address.'); m('whAddr', reg.whAddr.trim().length > 5, 'Enter at least one warehouse address.');
      m('whPin', /^\d{6}$/.test(reg.whPin) && isServiceable(reg.whPin), /^\d{6}$/.test(reg.whPin) ? COMING_SOON : 'Enter the 6-digit warehouse pincode.');
      m('billAddr', reg.sameBill || reg.billAddr.trim().length > 5, 'Enter the billing address.'); m('contact', reg.contact.trim().length > 1, 'Enter the contact person.');
      m('mobile', /^[6-9]\d{9}$/.test(reg.mobile), 'Enter a valid 10-digit mobile number.'); m('email', /^\S+@\S+\.\S+$/.test(reg.email), 'Enter a valid email ID.');
      m('years', reg.years !== '' && Number(reg.years) >= 0, 'Enter years in business.'); m('gstin', GSTRE.test(reg.gstin), 'Enter a valid 15-character GSTIN.');
      m('cats', reg.cats.length > 0, 'Choose the product categories you supply.');
      m('hours', !!reg.open && !!reg.close, 'Enter your operating hours.');
      m('user', /^[a-z0-9._-]{4,}$/i.test(reg.user), 'Username: at least 4 letters, numbers, dot, dash or underscore.'); m('pass', reg.pass.length >= 6, 'Password: at least 6 characters.');
    }
    if (s === 1) { kycDocs.forEach(d => m('k:' + d, !!docs[d], 'Upload: ' + d)); prodDocs.forEach((d: any) => m('p:' + d, !!docs['p:' + d] || !!na[d], 'Upload it, or mark not applicable.')); }
    if (s === 2) { m('holder', bank.holder.trim().length > 2, 'Enter the account holder name.'); m('bank', bank.bank.trim().length > 2, 'Enter the bank name.'); m('acc', /^\d{9,18}$/.test(bank.acc), 'Account number should be 9 to 18 digits.'); m('ifsc', /^[A-Z]{4}0[A-Z0-9]{6}$/.test(bank.ifsc), 'Enter a valid IFSC.'); m('cheque', !!bank.cheque, 'Upload the cancelled cheque.'); m('gstName', bank.gstName.trim().length > 2, 'Enter the GST-linked business name.'); }
    if (s === 3) { m('core', decl.core, 'Accept the core vendor terms to continue.'); m('agr', decl.agr, 'Accept the agreement, SLA and policies to continue.'); m('dec', decl.dec, 'Confirm the declaration to continue.'); m('vname', decl.vname.trim().length > 1, 'Enter the vendor name.'); m('auth', decl.auth.trim().length > 1, 'Enter the authorized person.'); m('desig', decl.desig.trim().length > 1, 'Enter the designation.'); m('sign', decl.sign.trim().length > 1, 'Type the authorized person name as signature.'); m('stamp', !!decl.stamp, 'Upload the company stamp.'); }
    setErr(o); return Object.keys(o).length === 0;
  };
  const next = () => { if (validate(step)) { if (step < 3) { setStep(step + 1); window.scrollTo(0, 0); } else submit({ reg, docs, na, bank, decl, submittedAt: Date.now() }); } };
  const bold = (k: string) => err[k];
  return <main className="pt ob vp-apply"><div className="ob-top"><span className="nv-pill dark">{tr("Vendor application")}</span><h1>{tr("Apply to sell on Kwenzo")}</h1><p className="pt-note">{tr("You cannot list products until Kwenzo verifies your KYC and approves your application.")}</p></div>
    <ol className="ob-steps">{tr(['Business details', 'KYC documents', 'Bank details', 'Terms and declaration'].map((s, i) => <li key={s} className={i < step ? 'done' : i === step ? 'cur' : ''}><i>{tr(i < step ? <Icon n="check" size={14} /> : i + 1)}</i><span>{tr(s)}</span></li>))}</ol>
    <div className="ob-card">
      {tr(step === 0 && <><h2>{tr("A. Basic business details")}</h2>
        <div className="ob-grid">
          <F l={tr("Business / Firm name")} e={bold('firm')}><input value={reg.firm} onChange={e => R('firm', e.target.value)} /></F>
          <F l={tr("Proprietor / Partner / Director name")} e={bold('owner')}><input value={reg.owner} onChange={e => R('owner', e.target.value)} /></F>
          <F l={tr("Constitution of business")} e={bold('constitution')}><select value={reg.constitution} onChange={e => R('constitution', e.target.value)}><option value="">{tr("Select")}</option>{tr(Object.keys(KYC).map(k => <option key={k} value={k}>{tr(k)}</option>))}</select></F>
          <F l={tr("Type of business")} e={bold('btype')}><select value={reg.btype} onChange={e => R('btype', e.target.value)}><option value="">{tr("Select")}</option>{tr(BT.map(k => <option key={k} value={k}>{tr(k)}</option>))}</select></F>
        </div>
        <F l={tr("Registered business address")} e={bold('regAddr')}><textarea rows={2} value={reg.regAddr} onChange={e => R('regAddr', e.target.value)} /></F>
        <F l={tr("Warehouse address(es), one per line")} e={bold('whAddr')}><textarea rows={3} value={reg.whAddr} onChange={e => R('whAddr', e.target.value)} /></F>
        <div className="ob-grid"><F l={tr("Primary warehouse pincode")} e={bold('whPin')}><input value={reg.whPin} inputMode="numeric" maxLength={6} onChange={e => R('whPin', e.target.value.replace(/\D/g, ''))} /></F>
          <F l={tr("GSTIN")} e={bold('gstin')}><input value={reg.gstin} maxLength={15} onChange={e => R('gstin', e.target.value.toUpperCase())} /></F></div>
        <Check v={reg.sameBill} set={v => R('sameBill', v)}>{tr("Billing address is the same as the registered business address")}</Check>
        {tr(!reg.sameBill && <F l={tr("Billing address")} e={bold('billAddr')}><textarea rows={2} value={reg.billAddr} onChange={e => R('billAddr', e.target.value)} /></F>)}
        <div className="ob-grid">
          <F l={tr("Contact person")} e={bold('contact')}><input value={reg.contact} onChange={e => R('contact', e.target.value)} /></F>
          <F l={tr("Mobile number")} e={bold('mobile')}><input value={reg.mobile} inputMode="numeric" maxLength={10} onChange={e => R('mobile', e.target.value.replace(/\D/g, ''))} /></F>
          <F l={tr("Email ID")} e={bold('email')}><input value={reg.email} onChange={e => R('email', e.target.value)} /></F>
          <F l={tr("Years in business")} e={bold('years')}><input value={reg.years} inputMode="numeric" onChange={e => R('years', e.target.value.replace(/\D/g, ''))} /></F>
        </div>
        <div className={'nv-f' + (err.cats ? ' bad' : '')}><span>{tr("Product categories supplied")}</span><div className="nv-chips wrap">{tr(VCATS.map(c => <button type="button" key={c} className={reg.cats.includes(c) ? 'on' : ''} onClick={() => R('cats', reg.cats.includes(c) ? reg.cats.filter((x: string) => x !== c) : [...reg.cats, c])}>{tr(c)}</button>))}</div>{tr(err.cats && <em>{tr(err.cats)}</em>)}</div>
        <div className="ob-grid">
          <F l={tr("Operating hours")} e={bold('hours')}><div className="vp-time"><input type="time" value={reg.open} onChange={e => R('open', e.target.value)} /><span>{tr("to")}</span><input type="time" value={reg.close} onChange={e => R('close', e.target.value)} /></div></F></div>
        <div className="nv-f"><span>{tr("Weekly holidays")}</span><div className="nv-chips wrap">{tr(DAYS.map(d => <button type="button" key={d} className={reg.holidays.includes(d) ? 'on' : ''} onClick={() => R('holidays', reg.holidays.includes(d) ? reg.holidays.filter((x: string) => x !== d) : [...reg.holidays, d])}>{tr(d)}</button>))}</div></div>
        <h3 className="pt-h3">{tr("Create your login")}</h3><p className="pt-note">{tr("After approval you can sign in with this username and password, or with your mobile number and OTP.")}</p>
        <div className="ob-grid"><F l={tr("Username")} e={bold('user')}><input value={reg.user} onChange={e => R('user', e.target.value)} autoComplete="off" /></F><F l={tr("Password")} e={bold('pass')}><input type="password" value={reg.pass} onChange={e => R('pass', e.target.value)} autoComplete="new-password" /></F></div></>)}
      {tr(step === 1 && <><h2>{tr("B. Mandatory KYC and legal documents")}</h2><p className="pt-note">{tr("Documents required for: ")}<b>{tr(reg.constitution)}</b>.</p>
        {tr(kycDocs.map(d => <div className={'ob-doc' + (err['k:' + d] ? ' bad' : '')} key={d}><div><b>{tr(d)}</b><em>{tr(docs[d] || err['k:' + d] || 'PDF or photo')}</em></div><FileIn name={docs[d]} set={n => setDocs({ ...docs, [d]: n })} /></div>))}
        <h3 className="pt-h3">{tr("Product-specific documents")}</h3><p className="pt-note">{tr("Category dependent. Not every certificate is needed for every vendor. For each document below, upload it or mark it not applicable to your products.")}</p>
        {tr(prodDocs.length === 0 && <p className="pt-note">{tr("Choose product categories in step 1 to see the documents that apply.")}</p>)}
        {tr(prodDocs.map((d: any) => <div className={'ob-doc' + (err['p:' + d] ? ' bad' : '')} key={d}><div><b>{tr(d)}</b><em>{tr(docs['p:' + d] || (na[d] ? 'Marked not applicable' : err['p:' + d] || 'Required for: ' + reg.cats.filter((c: string) => (PRODDOCS[c] || []).includes(d)).join(', ')))}</em></div>
          <div className="vp-doc-act"><FileIn name={docs['p:' + d]} set={n => { setDocs({ ...docs, ['p:' + d]: n }); setNa({ ...na, [d]: false }); }} /><label className="vp-na"><input type="checkbox" checked={!!na[d]} onChange={e => { setNa({ ...na, [d]: e.target.checked }); if (e.target.checked) { const x = { ...docs }; delete x['p:' + d]; setDocs(x); } }} />{tr("Not applicable")}</label></div></div>))}</>)}
      {tr(step === 2 && <><h2>{tr("C. Bank and payment details")}</h2><p className="pt-note">{tr("The bank account name should match the registered business / vendor entity.")}</p>
        <div className="ob-grid"><F l={tr("Account holder name")} e={bold('holder')}><input value={bank.holder} onChange={e => B('holder', e.target.value)} /></F><F l={tr("Bank name")} e={bold('bank')}><input value={bank.bank} onChange={e => B('bank', e.target.value)} /></F>
          <F l={tr("Account number")} e={bold('acc')}><input value={bank.acc} inputMode="numeric" maxLength={18} onChange={e => B('acc', e.target.value.replace(/\D/g, ''))} /></F><F l={tr("IFSC")} e={bold('ifsc')}><input value={bank.ifsc} maxLength={11} onChange={e => B('ifsc', e.target.value.toUpperCase())} /></F>
          <F l={tr("UPI ID (if applicable)")}><input value={bank.upi} onChange={e => B('upi', e.target.value)} /></F><F l={tr("GST-linked business name")} e={bold('gstName')}><input value={bank.gstName} onChange={e => B('gstName', e.target.value)} /></F></div>
        <div className={'ob-doc' + (err.cheque ? ' bad' : '')}><div><b>{tr("Cancelled cheque")}</b><em>{tr(bank.cheque || err.cheque || 'PDF or photo')}</em></div><FileIn name={bank.cheque} set={n => B('cheque', n)} /></div>
        {tr(bank.holder && reg.firm && ![reg.firm, reg.owner].some((n: string) => n.trim().toLowerCase() === bank.holder.trim().toLowerCase()) && <div className="ob-note">{tr("The account holder name does not match the firm or proprietor name entered in step 1. Kwenzo verifies this during KYC.")}</div>)}</>)}
      {tr(step === 3 && <><h2>{tr("Terms, agreements and declaration")}</h2>
        <h3 className="pt-h3">{tr("Kwenzo core vendor terms")}</h3><p className="pt-note">{tr("By registering with Kwenzo, the Vendor agrees that:")}</p><div className="vp-scroll"><CoreTerms /></div>
        <Check v={decl.core} set={v => D('core', v)} e={err.core}>{tr("I have read and accept the 20 core vendor terms above.")}</Check>{tr(err.core && <div className="nv-err">{tr(err.core)}</div>)}
        <Acc t={tr("Full policies: pricing, price change, inventory, SLAs, logistics, quality, returns, settlement, penalties, anti-bypass, indemnity, termination and more")}><PolicyList /></Acc>
        <Acc t={tr("Vendor Scorecard and Vendor Score")}><Score /></Acc>
        <Acc t={tr("The 4 Kwenzo vendor documents")}><Docs4 /></Acc>
        <Check v={decl.agr} set={v => D('agr', v)} e={err.agr}>{tr("I agree to the Kwenzo Vendor Agreement, Service Level Agreements, SOP, pricing and price-change policy, returns and damage policy, penalties, confidentiality and non-circumvention terms listed above. I understand the agreement is signed after approval.")}</Check>{tr(err.agr && <div className="nv-err">{tr(err.agr)}</div>)}
        <h3 className="pt-h3">{tr("Vendor declaration")}</h3><blockquote className="vp-decl">{tr(DECLARATION)}</blockquote>
        <Check v={decl.dec} set={v => D('dec', v)} e={err.dec}>{tr("I confirm the declaration above.")}</Check>{tr(err.dec && <div className="nv-err">{tr(err.dec)}</div>)}
        <div className="ob-grid"><F l={tr("Vendor name")} e={bold('vname')}><input value={decl.vname} onChange={e => D('vname', e.target.value)} /></F><F l={tr("Authorized person")} e={bold('auth')}><input value={decl.auth} onChange={e => D('auth', e.target.value)} /></F>
          <F l={tr("Designation")} e={bold('desig')}><input value={decl.desig} onChange={e => D('desig', e.target.value)} /></F><F l={tr("Date")}><input type="date" value={decl.date} onChange={e => D('date', e.target.value)} /></F>
          <F l={tr("Signature (type the authorized person's name)")} e={bold('sign')}><input value={decl.sign} onChange={e => D('sign', e.target.value)} /></F>
          <div className={'ob-doc' + (err.stamp ? ' bad' : '')}><div><b>{tr("Company stamp")}</b><em>{tr(decl.stamp || err.stamp || 'Image or PDF')}</em></div><FileIn name={decl.stamp} set={n => D('stamp', n)} /></div></div></>)}
      <div className="ob-nav">{tr(step > 0 ? <button className="nv-btn ghost" onClick={() => { setErr({}); setStep(step - 1); }}>{tr("Back")}</button> : <button className="nv-btn ghost" onClick={cancel}>{tr("Cancel")}</button>)}
        <button className="nv-btn big" onClick={next}>{tr(step < 3 ? 'Save and continue' : 'Submit application')}</button></div>
    </div></main>;
}

function Post({ app, save }: { app: App_; save: (a: App_) => void }) {
  const v = app.v; const [err, setErr] = useState<Record<string, string>>({});
  const upd = (p: any) => save({ ...app, v: { ...v, ...p } });
  const step = v.step || 0; const skus: any[] = v.skus || [];
  const [sk, setSk] = useState<any>({ id: '', name: '', cat: '', brand: '', mfr: '', hsn: '', gst: '', unit: '', mrp: '', vprice: '', moq: '', qty: '', weight: '', dims: '', warranty: '', images: '', spec: '', ret: '' });
  const S = (k: string, x: string) => setSk({ ...sk, [k]: x });
  const m = (o: Record<string, string>, k: string, ok: boolean, msg: string) => { if (!ok) o[k] = msg; };
  const go = (n: number) => { setErr({}); upd({ step: n }); window.scrollTo(0, 0); };
  const addSku = () => { const o: Record<string, string> = {}; const n = (x: string) => Number(x);
    m(o, 'id', sk.id.trim().length > 1 && !skus.some(s => s.id.toLowerCase() === sk.id.trim().toLowerCase()), 'Enter a unique SKU ID.'); m(o, 'name', sk.name.trim().length > 2, 'Enter the product name.'); m(o, 'cat', !!sk.cat, 'Choose a category.'); m(o, 'brand', !!sk.brand.trim(), 'Enter the brand.'); m(o, 'mfr', !!sk.mfr.trim(), 'Enter the manufacturer.');
    m(o, 'hsn', /^\d{4,8}$/.test(sk.hsn), 'HSN code is 4 to 8 digits.'); m(o, 'gst', sk.gst !== '', 'Choose the GST rate.'); m(o, 'unit', !!sk.unit.trim(), 'Enter the unit (piece, bag, kg...).');
    m(o, 'mrp', n(sk.mrp) > 0, 'Enter the MRP.'); m(o, 'vprice', n(sk.vprice) > 0 && n(sk.vprice) <= n(sk.mrp), 'Vendor price must be above 0 and not above MRP.'); m(o, 'moq', n(sk.moq) >= 1, 'Enter the minimum order quantity.'); m(o, 'qty', n(sk.qty) >= 0 && sk.qty !== '', 'Enter the available quantity.');
    m(o, 'weight', !!sk.weight.trim(), 'Enter the weight.'); m(o, 'dims', !!sk.dims.trim(), 'Enter the dimensions.'); m(o, 'warranty', !!sk.warranty.trim(), 'Enter the warranty (or None).'); m(o, 'images', !!sk.images, 'Product images are required.'); m(o, 'spec', !!sk.spec, 'Specification sheet is required.'); m(o, 'ret', !!sk.ret, 'Choose returnable or not.');
    setErr(o); if (!Object.keys(o).length) { upd({ skus: [...skus, { ...sk, id: sk.id.trim(), sprice: '' }] }); setSk({ id: '', name: '', cat: '', brand: '', mfr: '', hsn: '', gst: '', unit: '', mrp: '', vprice: '', moq: '', qty: '', weight: '', dims: '', warranty: '', images: '', spec: '', ret: '' }); } };
  const pr = v.pricing || { gstIncl: '', transport: '', loading: '', packaging: '', extra: '', ack: false };
  const lg = v.logi || { wh: '', contact: '', phone: '', assist: '', unload: '', prep: '', loadTime: '', ack: false };
  const sl = v.slaAcc || { restock: '', lead: '', ack: false };
  const ag = v.agr || { vname: app.shop, auth: '', desig: '', date: today(), sign: '', stamp: '', read: false };
  const wh = (v.reg.whAddr || '').split('\n').map((x: string) => x.trim()).filter(Boolean);
  const comm = v.commission || {};
  const nav = (nextOk: boolean | null, label: string, f: () => void) => <div className="ob-nav">{tr(step > 0 ? <button className="nv-btn ghost" onClick={() => go(step - 1)}>{tr("Back")}</button> : <span />)}<button className="nv-btn big" onClick={f}>{tr(label)}</button></div>;
  const E = (k: string) => err[k] && <div className="nv-err">{tr(err[k])}</div>;
  const test = v.test || 0;
  const tsku = skus[0];
  const TS = ['Receive test order', 'Accept the order', 'Mark material ready', 'Hand over to Kwenzo rider', 'Delivered with proof of delivery'];
  return <main className="pt ob"><div className="ob-top"><span className="nv-pill dark">{tr("Approved vendor onboarding")}</span><h1>{tr(app.shop)}</h1><p className="pt-note">{tr("Approved by Kwenzo. Complete each step in order to go live.")}</p></div>
    <ol className="ob-steps vp-post">{tr(POST.map((s, i) => <li key={s} className={i < step ? 'done' : i === step ? 'cur' : ''}><i>{tr(i < step ? <Icon n="check" size={14} /> : i + 1)}</i><span>{tr(s)}</span></li>))}</ol>
    <div className="ob-card">
      {tr(step === 0 && <><h2>{tr("Catalogue onboarding")}</h2><p className="pt-note">{tr("Add every SKU with the full catalogue template. Nothing is visible to customers until you go live.")}</p>
        <div className="ob-grid">
          <F l={tr("SKU ID")} e={err.id}><input value={sk.id} onChange={e => S('id', e.target.value)} /></F><F l={tr("Product name")} e={err.name}><input value={sk.name} onChange={e => S('name', e.target.value)} /></F>
          <F l={tr("Category")} e={err.cat}><select value={sk.cat} onChange={e => S('cat', e.target.value)}><option value="">{tr("Select")}</option>{tr(v.reg.cats.map((c: string) => <option key={c} value={c}>{tr(c)}</option>))}</select></F>
          <F l={tr("Brand")} e={err.brand}><input value={sk.brand} onChange={e => S('brand', e.target.value)} /></F><F l={tr("Manufacturer")} e={err.mfr}><input value={sk.mfr} onChange={e => S('mfr', e.target.value)} /></F>
          <F l={tr("HSN code")} e={err.hsn}><input value={sk.hsn} inputMode="numeric" maxLength={8} onChange={e => S('hsn', e.target.value.replace(/\D/g, ''))} /></F>
          <F l={tr("GST rate")} e={err.gst}><select value={sk.gst} onChange={e => S('gst', e.target.value)}><option value="">{tr("Select")}</option>{tr(['0', '5', '12', '18', '28'].map(g => <option key={g} value={g}>{tr(g)}%</option>))}</select></F>
          <F l={tr("Unit")} e={err.unit}><input value={sk.unit} onChange={e => S('unit', e.target.value)} /></F>
          <F l={tr("MRP (₹)")} e={err.mrp}><input value={sk.mrp} inputMode="decimal" onChange={e => S('mrp', e.target.value.replace(/[^\d.]/g, ''))} /></F><F l={tr("Vendor price (₹)")} e={err.vprice}><input value={sk.vprice} inputMode="decimal" onChange={e => S('vprice', e.target.value.replace(/[^\d.]/g, ''))} /></F>
          <F l={tr("Minimum order quantity")} e={err.moq}><input value={sk.moq} inputMode="numeric" onChange={e => S('moq', e.target.value.replace(/\D/g, ''))} /></F><F l={tr("Available quantity")} e={err.qty}><input value={sk.qty} inputMode="numeric" onChange={e => S('qty', e.target.value.replace(/\D/g, ''))} /></F>
          <F l={tr("Weight")} e={err.weight}><input value={sk.weight} onChange={e => S('weight', e.target.value)} /></F><F l={tr("Dimensions")} e={err.dims}><input value={sk.dims} onChange={e => S('dims', e.target.value)} /></F>
          <F l={tr("Warranty")} e={err.warranty}><input value={sk.warranty} onChange={e => S('warranty', e.target.value)} /></F>
          <F l={tr("Returnable?")} e={err.ret}><select value={sk.ret} onChange={e => S('ret', e.target.value)}><option value="">{tr("Select")}</option><option value={"Yes"}>{tr("Yes")}</option><option value={"No"}>{tr("No")}</option></select></F></div>
        <div className="ob-grid"><div className={'ob-doc' + (err.images ? ' bad' : '')}><div><b>{tr("Product images (required)")}</b><em>{tr(sk.images || err.images || 'One or more images')}</em></div><FileIn multiple name={sk.images} set={n => S('images', n)} /></div>
          <div className={'ob-doc' + (err.spec ? ' bad' : '')}><div><b>{tr("Specification sheet (required)")}</b><em>{tr(sk.spec || err.spec || 'PDF or document')}</em></div><FileIn name={sk.spec} set={n => S('spec', n)} /></div></div>
        <button className="nv-btn" onClick={addSku}>{tr("Add SKU to catalogue")}</button>
        {tr(skus.length > 0 && <div className="pt-table vp-skus"><div className="pt-tr h"><span>{tr("SKU")}</span><span>{tr("Vendor price")}</span><span>{tr("MRP")}</span><span>{tr("MOQ / Stock")}</span></div>{tr(skus.map((s, i) => <div className="pt-tr" key={s.id}><span><b>{tr(s.name)}</b><em>{tr(s.id)} · {tr(s.brand)} · {tr(s.cat)}{tr(" · HSN ")}{tr(s.hsn)}{tr(" · GST ")}{tr(s.gst)}%</em></span><span>{tr(inr(Number(s.vprice)))} / {tr(s.unit)}</span><span>{tr(inr(Number(s.mrp)))}</span><span>{tr(s.moq)} / {tr(s.qty)}<button className="ob-link" onClick={() => upd({ skus: skus.filter((_, j) => j !== i) })}>{tr("Remove")}</button></span></div>))}</div>)}
        {tr(err.next && <div className="nv-err">{tr(err.next)}</div>)}
        {tr(nav(null, 'Save and continue', () => { if (skus.length < 1) { setErr({ next: 'Add at least one SKU to continue.' }); return; } go(1); }))}</>)}
      {tr(step === 1 && <><h2>{tr("Pricing setup")}</h2><p className="pt-note">{tr("Set the Kwenzo selling price for each SKU. Margin = Kwenzo selling price minus vendor price.")}</p>
        <div className="pt-table vp-skus"><div className="pt-tr h"><span>{tr("SKU")}</span><span>{tr("Vendor price / MRP")}</span><span>{tr("Kwenzo selling price")}</span><span>{tr("Kwenzo margin")}</span></div>{tr(skus.map((s, i) => { const sp = Number(s.sprice), vp = Number(s.vprice); return <div className="pt-tr" key={s.id}><span><b>{tr(s.name)}</b><em>{tr(s.id)}</em></span><span>{tr(inr(vp))} / {tr(inr(Number(s.mrp)))}</span><span><input className="pt-in" inputMode="decimal" value={s.sprice} onChange={e => upd({ skus: skus.map((x, j) => j === i ? { ...x, sprice: e.target.value.replace(/[^\d.]/g, '') } : x) })} />{tr(err['s' + i] && <em className="vp-bad">{tr(err['s' + i])}</em>)}</span><span>{tr(sp ? inr(+(sp - vp).toFixed(2)) + ' (' + ((sp - vp) / vp * 100).toFixed(1) + '%)' : '')}</span></div>; }))}</div>
        <h3 className="pt-h3">{tr("Commercial terms for your categories")}</h3><p className="pt-note">{tr("Set by Kwenzo at commercial approval.")}</p>
        <div className="pt-table"><div className="pt-tr h c4"><span>{tr("Category")}</span><span>{tr("Commission")}</span><span>{tr("Other charges")}</span><span>{tr("Payment model / settlement")}</span></div>{tr(v.reg.cats.map((c: string) => <div className="pt-tr c4" key={c}><span>{tr(c)}</span><span>{tr(comm[c]?.pct)}%</span><span>{tr(comm[c]?.other || 'None')}</span><span>{tr(v.payModel)}, {tr(v.settle)}</span></div>))}</div>
        <div className="ob-grid"><F l={tr("GST on selling price")} e={err.gstIncl}><select value={pr.gstIncl} onChange={e => upd({ pricing: { ...pr, gstIncl: e.target.value } })}><option value="">{tr("Select")}</option><option value={"GST included"}>{tr("GST included")}</option><option value={"GST excluded"}>{tr("GST excluded")}</option></select></F>
          {tr(([['transport', 'Transportation included in price?'], ['loading', 'Loading/unloading included in price?'], ['packaging', 'Packaging charges included in price?'], ['extra', 'Any additional charges allowed?']] as [string, string][]).map(([k, l]) => <F key={k} l={tr(l)} e={err[k]}><select value={pr[k]} onChange={e => upd({ pricing: { ...pr, [k]: e.target.value } })}><option value="">{tr("Select")}</option><option value={"Yes"}>{tr("Yes")}</option><option value={"No"}>{tr("No")}</option></select></F>))}</div>
        <Check v={pr.ack} set={b => upd({ pricing: { ...pr, ack: b } })} e={err.ack}>{tr("I accept the price change policy: no change to an approved selling price without at least 7 days prior written notice to Kwenzo (daily / weekly price update for volatile categories).")}</Check>{tr(E('ack'))}
        {tr(nav(null, 'Save and continue', () => { const o: Record<string, string> = {}; skus.forEach((s, i) => { const sp = Number(s.sprice); if (!(sp >= Number(s.vprice) && sp <= Number(s.mrp))) o['s' + i] = 'Between vendor price and MRP.'; }); (['gstIncl', 'transport', 'loading', 'packaging', 'extra'] as string[]).forEach(k => m(o, k, !!pr[k], 'Choose an option.')); m(o, 'ack', pr.ack, 'Accept the price change policy to continue.'); setErr(o); if (!Object.keys(o).length) go(2); }))}</>)}
      {tr(step === 2 && <><h2>{tr("Logistics setup")}</h2>
        <div className="vp-split"><div className="pt-card"><b>{tr("Vendor responsibility")}</b><ul>{tr(['Correct product', 'Correct quantity', 'Proper packaging', 'Product readiness', 'Loading assistance, where agreed', 'Invoice', 'Product documentation'].map(x => <li key={x}>{tr(x)}</li>))}</ul></div><div className="pt-card"><b>{tr("Kwenzo responsibility")}</b><ul>{tr(['Pickup coordination', 'Transportation', 'Customer communication', 'Delivery tracking', 'Proof of delivery'].map(x => <li key={x}>{tr(x)}</li>))}</ul></div></div>
        <p className="pt-note">{tr("Kwenzo delivery does not mean automatic site unloading. Unless agreed otherwise, you pack safely and make the material available for pickup; responsibility for transportation passes to Kwenzo at handover.")}</p>
        <div className="ob-grid"><F l={tr("Pickup warehouse")} e={err.wh}><select value={lg.wh} onChange={e => upd({ logi: { ...lg, wh: e.target.value } })}><option value="">{tr("Select")}</option>{tr(wh.map((w: string) => <option key={w} value={w}>{tr(w)}</option>))}</select></F>
          <F l={tr("Pickup contact person")} e={err.contact}><input value={lg.contact} onChange={e => upd({ logi: { ...lg, contact: e.target.value } })} /></F>
          <F l={tr("Pickup contact mobile")} e={err.phone}><input value={lg.phone} inputMode="numeric" maxLength={10} onChange={e => upd({ logi: { ...lg, phone: e.target.value.replace(/\D/g, '') } })} /></F>
          <F l={tr("Preparation time after acceptance")} e={err.prep}><input value={lg.prep} onChange={e => upd({ logi: { ...lg, prep: e.target.value } })} /></F>
          <F l={tr("Loading time at warehouse")} e={err.loadTime}><input value={lg.loadTime} onChange={e => upd({ logi: { ...lg, loadTime: e.target.value } })} /></F>
          <F l={tr("Loading assistance provided?")} e={err.assist}><select value={lg.assist} onChange={e => upd({ logi: { ...lg, assist: e.target.value } })}><option value="">{tr("Select")}</option><option value={"Yes"}>{tr("Yes")}</option><option value={"No"}>{tr("No")}</option></select></F>
          <F l={tr("Who unloads at the delivery site?")} e={err.unload}><select value={lg.unload} onChange={e => upd({ logi: { ...lg, unload: e.target.value } })}><option value="">{tr("Select")}</option><option value={"Vendor"}>{tr("Vendor")}</option><option value={"Kwenzo logistics"}>{tr("Kwenzo logistics")}</option><option value={"Customer"}>{tr("Customer")}</option><option value={"As agreed per order"}>{tr("As agreed per order")}</option></select></F></div>
        <Check v={lg.ack} set={b => upd({ logi: { ...lg, ack: b } })} e={err.ack}>{tr("I accept the logistics terms: pickup SLA, loading time, waiting time, damaged goods responsibility and failed delivery responsibility as set in the Vendor Agreement.")}</Check>{tr(E('ack'))}
        {tr(nav(null, 'Save and continue', () => { const o: Record<string, string> = {}; m(o, 'wh', !!lg.wh, 'Select the pickup warehouse.'); m(o, 'contact', lg.contact.trim().length > 1, 'Enter the contact person.'); m(o, 'phone', /^[6-9]\d{9}$/.test(lg.phone), 'Enter a valid mobile number.'); m(o, 'prep', !!lg.prep.trim(), 'Enter the preparation time.'); m(o, 'loadTime', !!lg.loadTime.trim(), 'Enter the loading time.'); m(o, 'assist', !!lg.assist, 'Choose an option.'); m(o, 'unload', !!lg.unload, 'Choose an option.'); m(o, 'ack', lg.ack, 'Accept the logistics terms to continue.'); setErr(o); if (!Object.keys(o).length) go(3); }))}</>)}
      {tr(step === 3 && <><h2>{tr("SLA acceptance")}</h2><ol className="vp-terms">{tr(SLAS.map((s, i) => <li key={i}>{tr(s)}</li>))}</ol>
        <h3 className="pt-h3">{tr("Inventory management")}</h3><div className="ob-grid"><F l={tr("Restocking frequency")} e={err.restock}><select value={sl.restock} onChange={e => upd({ slaAcc: { ...sl, restock: e.target.value } })}><option value="">{tr("Select")}</option>{tr(['Daily', 'Twice a week', 'Weekly', 'Fortnightly', 'Monthly'].map(x => <option key={x} value={x}>{tr(x)}</option>))}</select></F><F l={tr("Lead time for out-of-stock SKUs")} e={err.lead}><input value={sl.lead} onChange={e => upd({ slaAcc: { ...sl, lead: e.target.value } })} /></F></div>
        <Check v={sl.ack} set={b => upd({ slaAcc: { ...sl, ack: b } })} e={err.ack}>{tr("I accept all Service Level Agreements listed above, the penalties for breach and the Vendor Scorecard.")}</Check>{tr(E('ack'))}
        <Acc t={tr("Vendor Scorecard")}><Score /></Acc>
        {tr(nav(null, 'Accept SLAs and continue', () => { const o: Record<string, string> = {}; m(o, 'restock', !!sl.restock, 'Choose the restocking frequency.'); m(o, 'lead', !!sl.lead.trim(), 'Enter the lead time.'); m(o, 'ack', sl.ack, 'Accept the SLAs to continue.'); setErr(o); if (!Object.keys(o).length) go(4); }))}</>)}
      {tr(step === 4 && <><h2>{tr("Kwenzo Vendor Agreement")}</h2><Docs4 /><Acc t={tr("Core vendor terms")}><CoreTerms /></Acc><PolicyList />
        <h3 className="pt-h3">{tr("Sign the agreement")}</h3><blockquote className="vp-decl">{tr(DECLARATION)}</blockquote>
        <div className="ob-grid"><F l={tr("Vendor name")} e={err.vname}><input value={ag.vname} onChange={e => upd({ agr: { ...ag, vname: e.target.value } })} /></F><F l={tr("Authorized person")} e={err.auth}><input value={ag.auth} onChange={e => upd({ agr: { ...ag, auth: e.target.value } })} /></F><F l={tr("Designation")} e={err.desig}><input value={ag.desig} onChange={e => upd({ agr: { ...ag, desig: e.target.value } })} /></F><F l={tr("Date")}><input type="date" value={ag.date} onChange={e => upd({ agr: { ...ag, date: e.target.value } })} /></F>
          <F l={tr("Signature (type the authorized person's name)")} e={err.sign}><input value={ag.sign} onChange={e => upd({ agr: { ...ag, sign: e.target.value } })} /></F>
          <div className={'ob-doc' + (err.stamp ? ' bad' : '')}><div><b>{tr("Company stamp")}</b><em>{tr(ag.stamp || err.stamp || 'Image or PDF')}</em></div><FileIn name={ag.stamp} set={n => upd({ agr: { ...ag, stamp: n } })} /></div></div>
        <Check v={ag.read} set={b => upd({ agr: { ...ag, read: b } })} e={err.read}>{tr("I have read the Vendor Agreement, SLAs and SOP, and I sign on behalf of the vendor.")}</Check>{tr(E('read'))}
        {tr(nav(null, 'Sign agreement', () => { const o: Record<string, string> = {}; m(o, 'vname', ag.vname.trim().length > 1, 'Enter the vendor name.'); m(o, 'auth', ag.auth.trim().length > 1, 'Enter the authorized person.'); m(o, 'desig', ag.desig.trim().length > 1, 'Enter the designation.'); m(o, 'sign', ag.sign.trim().length > 1, 'Type the signature.'); m(o, 'stamp', !!ag.stamp, 'Upload the company stamp.'); m(o, 'read', ag.read, 'Confirm to sign.'); setErr(o); if (!Object.keys(o).length) { upd({ agr: { ...ag, signedAt: Date.now() }, step: 5 }); window.scrollTo(0, 0); } }))}</>)}
      {tr(step === 5 && <><h2>{tr("Test order")}</h2><p className="pt-note">{tr("Run one order end to end: Order received, Vendor confirmation, Material ready, Kwenzo rider pickup, Customer delivery.")}</p>
        {tr(tsku && <div className="pt-card"><b>{tr("Test order")}</b><p>{tr(tsku.moq)}{tr(" x ")}{tr(tsku.name)} ({tr(tsku.id)}{tr(") at vendor price ")}{tr(inr(Number(tsku.vprice)))}{tr(" per ")}{tr(tsku.unit)}{tr(". Total ")}{tr(inr(Number(tsku.vprice) * Number(tsku.moq)))}.</p></div>)}
        <ol className="vp-journey vert">{tr(TS.map((s, i) => <li key={s} className={i < test ? 'done' : i === test ? 'cur' : ''}><i>{tr(i < test ? <Icon n="check" size={13} /> : i + 1)}</i><span>{tr(s)}</span></li>))}</ol>
        {tr(test === 3 && <div className="pt-card"><b>{tr("Proof of Pickup")}</b><p>{tr("Photo + quantity + condition.")}</p><FileIn name={v.pop} set={n => upd({ pop: n })} label={tr("Upload pickup photo")} /><Check v={!!v.popOk} set={b => upd({ popOk: b })}>{tr("Quantity (")}{tr(tsku?.moq)}{tr(") and condition verified at handover.")}</Check>{tr(E('pop'))}</div>)}
        {tr(test < 5 ? <button className="nv-btn big" onClick={() => { if (test === 3 && (!v.pop || !v.popOk)) { setErr({ pop: 'Upload the pickup photo and confirm quantity and condition.' }); return; } setErr({}); upd({ test: test + 1 }); }}>{tr(TS[test])}</button> : <div className="ob-note ok">{tr("Test order completed with proof of delivery.")}</div>)}
        <div className="ob-nav"><button className="nv-btn ghost" onClick={() => go(4)}>{tr("Back")}</button><button className="nv-btn big" disabled={test < 5} onClick={() => go(6)}>{tr("Continue")}</button></div></>)}
      {tr(step === 6 && <><h2>{tr("Go live")}</h2><ul className="ob-check">{tr(['KYC verified and application approved', skus.length + ' SKUs in catalogue', 'Pricing set', 'Logistics set up', 'SLAs accepted', 'Agreement signed', 'Test order completed'].map(x => <li className="ok" key={x}><Icon n="check" size={16} />{tr(x)}</li>))}</ul>
        <div className="ob-nav"><button className="nv-btn ghost" onClick={() => go(5)}>{tr("Back")}</button><button className="nv-btn big" onClick={() => upd({ live: true, liveAt: Date.now() })}>{tr("Go LIVE")}</button></div></>)}
    </div></main>;
}

function LiveView({ app, save, orders = [], setOrders, itemsText }: { app: App_; save: (a: App_) => void; orders?: Order[]; setOrders?: (o: Order[]) => void; itemsText?: (o: Order) => string }) {
  const mine = orders.filter(o => o.sid === 'kz'); const patch = (id: string, p: Partial<Order>) => setOrders && setOrders(orders.map(o => o.id === id ? { ...o, ...p } : o));
  const [tab, setTab] = useState('listing'); const v = app.v; const skus: any[] = v.skus || []; const comm = v.commission || {};
  return <main className="pt"><div className="pt-head"><div><span className="nv-pill dark">{tr("Live vendor")}</span><h1>{tr(app.shop)}</h1></div></div>
    <div className="pt-tabs">{tr([['listing', 'Listing'], ['orders', 'Orders'], ['score', 'Scorecard'], ['terms', 'Commercial terms'], ['pol', 'Policies']].map(([k, l]) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{tr(l)}</button>))}</div>
    {tr(tab === 'listing' && <><div className="pt-kpis"><div className="pt-kpi"><span>{tr("Status")}</span><b>{tr("Live")}</b></div><div className="pt-kpi"><span>{tr("Listed SKUs")}</span><b>{tr(skus.length)}</b></div><div className="pt-kpi"><span>{tr("Categories")}</span><b>{tr(v.reg.cats.length)}</b></div></div>
      <div className="pt-table vp-skus"><div className="pt-tr h"><span>{tr("Product")}</span><span>{tr("Kwenzo selling price")}</span><span>{tr("Margin")}</span><span>{tr("MOQ / Stock")}</span></div>{tr(skus.map(s => <div className="pt-tr" key={s.id}><span><b>{tr(s.name)}</b><em>{tr(s.id)} · {tr(s.brand)} · {tr(s.cat)}{tr(" · HSN ")}{tr(s.hsn)}{tr(" · GST ")}{tr(s.gst)}% · {tr(s.ret === 'Yes' ? 'Returnable' : 'Non-returnable')}</em></span><span>{tr(inr(Number(s.sprice)))} / {tr(s.unit)}<em>{tr("MRP ")}{tr(inr(Number(s.mrp)))}</em></span><span>{tr(inr(+(Number(s.sprice) - Number(s.vprice)).toFixed(2)))}</span><span>{tr(s.moq)} / {tr(s.qty)}</span></div>))}</div>
      <p className="pt-note">{tr("Price changes need at least 7 days prior written notice to Kwenzo.")}</p></>)}
    {tr(tab === 'orders' && (mine.length === 0 ? <div className="nv-empty"><h3>{tr("No orders yet")}</h3><p>{tr("Orders placed on Kwenzo for your listed products show up here. Accept or reject each order within 10 minutes.")}</p></div> : <div className="pt-list">{tr([...mine].sort((a, b) => b.at - a.at).map(o => <div className="pt-card" key={o.id}>
      <div className="pt-row"><b>{tr(o.id)}</b><span className={'pt-chip s-' + o.status}>{tr(({ placed: 'New', accepted: 'Accepted', packed: 'Packed, awaiting pickup', dispatched: 'Out for delivery', delivered: 'Delivered', cancelled: 'Cancelled' } as any)[o.status])}</span></div>
      <p className="pt-note">{tr(itemsText ? itemsText(o) : '')} · {tr(inr(o.total))}</p>
      {tr(o.status === 'placed' && <div className="pt-row"><button className="nv-btn" onClick={() => patch(o.id, { status: 'accepted' })}>{tr("Accept order")}</button><button className="nv-btn ghost" onClick={() => patch(o.id, { status: 'cancelled' })}>{tr("Decline")}</button></div>)}
      {tr(o.status === 'accepted' && <><ProofShot label={tr("Proof of dispatch (photo of the material ready to dispatch)")} value={o.pDisp} onChange={x => patch(o.id, { pDisp: x })} /><div className="pt-row"><button className="nv-btn" disabled={!o.pDisp} onClick={() => { if (o.pDisp) patch(o.id, { status: 'packed' }); }}>{tr("Confirm packed")}</button>{tr(!o.pDisp && <span className="pt-note">{tr("Add the dispatch photo to confirm packed")}</span>)}</div></>)}
      {tr(o.status === 'packed' && <span className="pt-note">{tr("Waiting for a logistics partner to pick up")}</span>)}
    </div>))}</div>))}
    {tr(tab === 'score' && <><Score /><p className="pt-note">{tr("Your scores appear here after your first orders are completed.")}</p></>)}
    {tr(tab === 'terms' && <div className="pt-table"><div className="pt-tr h c4"><span>{tr("Category")}</span><span>{tr("Commission")}</span><span>{tr("Other charges")}</span><span>{tr("Payment model / settlement")}</span></div>{tr(v.reg.cats.map((c: string) => <div className="pt-tr c4" key={c}><span>{tr(c)}</span><span>{tr(comm[c]?.pct)}%</span><span>{tr(comm[c]?.other || 'None')}</span><span>{tr(v.payModel)}, {tr(v.settle)}</span></div>))}</div>)}
    {tr(tab === 'pol' && <><Acc t={tr("Core vendor terms")}><CoreTerms /></Acc><PolicyList /><Acc t={tr("The 4 Kwenzo vendor documents")}><Docs4 /></Acc></>)}
  </main>;
}

export function VendorPortal({ apps, setApps, orders, setOrders, itemsText }: Apps) {
  useLanguage();
  const [view, setView] = useState<'home' | 'login' | 'apply' | 'policies'>('login');
  const [auth, setAuth] = useState<string>(''); const [guest, setGuest] = useState(''); const [newPhone, setNewPhone] = useState(''); const [editing, setEditing] = useState(false);
  const [mode, setMode] = useState<'otp' | 'pw'>('otp'); const [f, setF] = useState({ phone: '', code: '', user: '', pass: '' }); const [err, setErr] = useState('');
  const app = apps.find(a => a.id === auth);
  const save = (a: App_) => setApps(apps.map(x => x.id === a.id ? a : x));
  const out = () => { setAuth(''); setGuest(''); setView('login'); setEditing(false); setNewPhone(''); };
  const login = () => {
    setErr('');
    if (mode === 'otp') { if (!/^[6-9]\d{9}$/.test(f.phone)) { setErr('Enter a valid 10-digit mobile number.'); return; } if (f.code !== '1234') { setErr('Enter the demo code 1234.'); return; }
      const a = apps.find(x => x.phone === f.phone); if (a) { setAuth(a.id); } else { setNewPhone(f.phone); setGuest(f.phone); setView('home'); } }
    else { const a = apps.find(x => x.user && x.user.toLowerCase() === f.user.trim().toLowerCase() && x.pass === f.pass); if (!a) { setErr('Username or password is incorrect. New vendor? Sign in with your mobile number and OTP to start your application.'); return; } setAuth(a.id); }
  };
  const header = <header className="nv-head"><div className="nv-logo static-dark"><span className="nv-mark">{tr("K")}</span><span>{tr("Kwenzo")}</span></div><span className="nv-tag2">{tr("Vendor portal")}</span>
    <div className="vp-hnav">{tr((auth || guest) && <button className="nv-btn ghost" onClick={out}>{tr("Sign out")}</button>)}</div></header>;
  let body: React.ReactNode;
  if (auth && app) {
    const v = app.v;
    if (editing || app.status === 'changes' && editing) body = <Apply initial={v} phone={app.phone || ''} cancel={() => setEditing(false)} submit={nv => { save({ ...app, status: 'pending', shop: nv.reg.firm, owner: nv.reg.owner, v: { ...v, ...nv, adminNote: undefined } }); setEditing(false); }} />;
    else if (app.status === 'pending') body = <main className="pt ob"><div className="ob-top"><span className="nv-pill dark">{tr("Application submitted")}</span><h1>{tr(app.shop)}</h1></div><Journey cur={1} />
      <div className="ob-card center"><span className="nv-done-i"><Icon n="clock" size={30} /></span><h2>{tr("Waiting for Kwenzo approval")}</h2><p>{tr("Your application and KYC documents are with the Kwenzo team. You cannot list products or continue onboarding until an admin approves your application.")}</p>
        <ul className="ob-sum"><li><b>{tr(Object.keys(v.docs).length)}</b>{tr(" documents uploaded")}</li><li><b>{tr(v.reg.cats.length)}</b>{tr(" categories")}</li><li><b>{tr(new Date(v.submittedAt).toLocaleDateString('en-IN'))}</b>{tr(" submitted")}</li></ul></div></main>;
    else if (app.status === 'rejected') body = <main className="pt ob"><div className="ob-top"><span className="nv-pill dark">{tr("Application")}</span><h1>{tr(app.shop)}</h1></div><div className="ob-card center"><h2>{tr("Application not approved")}</h2><p>{tr(v.adminNote || 'Kwenzo could not approve this application.')}</p></div></main>;
    else if (app.status === 'changes') body = <main className="pt ob"><div className="ob-top"><span className="nv-pill dark">{tr("Application")}</span><h1>{tr(app.shop)}</h1></div><div className="ob-card center"><h2>{tr("Changes requested by Kwenzo")}</h2><p>{tr(v.adminNote)}</p><button className="nv-btn big" onClick={() => setEditing(true)}>{tr("Edit application")}</button></div></main>;
    else if (v.live) body = <LiveView app={app} save={save} orders={orders} setOrders={setOrders} itemsText={itemsText} />;
    else body = <Post app={app} save={save} />;
  } else if (view === 'apply') body = <Apply phone={newPhone} cancel={() => setView('login')} submit={nv => { const id = 'v' + Date.now(); setApps([...apps, { id, shop: nv.reg.firm, owner: nv.reg.owner, city: 'Hyderabad', phone: nv.reg.mobile, status: 'pending', user: nv.reg.user, pass: nv.reg.pass, v: nv }]); setAuth(id); setGuest(''); }} />;
  else if (guest && view === 'policies') body = <main className="pt"><div className="pt-head"><div><span className="nv-pill dark">{tr("Vendor terms")}</span><h1>{tr("Kwenzo vendor terms and policies")}</h1></div><button className="nv-btn ghost" onClick={() => setView('home')}>{tr("Back")}</button></div><h3 className="pt-h3">{tr("Core vendor terms")}</h3><CoreTerms /><h3 className="pt-h3">{tr("The 4 Kwenzo vendor documents")}</h3><Docs4 /><h3 className="pt-h3">{tr("Policies")}</h3><PolicyList /><Score /></main>;
  else if (guest) body = <main className="vp-home">
    <section className="vp-hero"><span className="nv-pill">{tr("Kwenzo for vendors")}</span><h1>{tr("Sell building materials on Kwenzo.")}</h1><p>{tr("List your catalogue, receive orders from builders and homeowners across Hyderabad, and get settled after successful delivery. Kwenzo handles pickup, transport and delivery tracking.")}</p><div className="vp-cta"><button className="nv-btn big" onClick={() => setView('apply')}>{tr("Apply as a vendor")}</button></div></section>
    <section className="vp-sec"><h2>{tr("Vendor journey")}</h2><Journey cur={-1} /><p className="pt-note">{tr("Applications are reviewed by Kwenzo. You can list products only after KYC verification and commercial approval.")}</p></section>
    <section className="vp-sec vp-cards"><div className="pt-card"><Icon n="truck" size={24} /><b>{tr("Kwenzo logistics")}</b><p>{tr("Kwenzo coordinates pickup, transportation, customer communication, delivery tracking and proof of delivery.")}</p></div><div className="pt-card"><Icon n="shield" size={24} /><b>{tr("Settlement after delivery")}</b><p>{tr("Customer pays Kwenzo. Kwenzo settles you after successful delivery and POD, on the agreed cycle.")}</p></div><div className="pt-card"><Icon n="check" size={24} /><b>{tr("Vendor Score")}</b><p>{tr("Availability, acceptance, readiness, quality, cancellations, complaints and documentation decide your ranking.")}</p></div><div className="pt-card"><Icon n="bag" size={24} /><b>{tr("Your catalogue, your SKUs")}</b><p>{tr("Brand, HSN, GST, MRP, vendor price, stock, dimensions, weight, images and spec sheets for every SKU.")}</p></div></section>
    <section className="vp-sec"><h2>{tr("What you need to apply")}</h2><div className="vp-four">{tr(['Business details and contact person', 'KYC and legal documents for your constitution (proprietorship, partnership or LLP / Pvt Ltd)', 'Category-specific certificates where applicable', 'Bank details and a cancelled cheque'].map(x => <div className="pt-card" key={x}><p>{tr(x)}</p></div>))}</div></section>
    <section className="vp-sec"><h2>{tr("The 4 Kwenzo vendor documents")}</h2><Docs4 /><button className="ob-link" onClick={() => setView('policies')}>{tr("Read all vendor terms and policies")}</button></section></main>;
  else body = <main className="pt-login"><div className="pt-login-l"><span className="nv-pill">{tr("Vendor sign in")}</span><h1>{tr("Welcome back")}</h1><p>{tr("First time here? Sign in with your mobile number and OTP to start your application. Returning vendors can use mobile + OTP or username + password.")}</p></div>
    <div className="pt-login-r"><div className="nv-form card" onKeyDown={e => { if (e.key === 'Enter') login(); }}><h2>{tr("Sign in")}</h2><div className="nv-chips"><button className={mode === 'otp' ? 'on' : ''} onClick={() => { setMode('otp'); setErr(''); }}>{tr("Mobile + OTP")}</button><button className={mode === 'pw' ? 'on' : ''} onClick={() => { setMode('pw'); setErr(''); }}>{tr("Username + password")}</button></div>
      {tr(mode === 'otp' ? <><label className="nv-f"><span>{tr("Mobile number")}</span><input value={f.phone} inputMode="numeric" maxLength={10} onChange={e => setF({ ...f, phone: e.target.value.replace(/\D/g, '') })} /></label><label className="nv-f"><span>{tr("OTP")}</span><input value={f.code} inputMode="numeric" maxLength={4} onChange={e => setF({ ...f, code: e.target.value.replace(/\D/g, '') })} /></label><p className="pt-note">{tr("Preview only: use any valid mobile number and the demo code 1234.")}</p></>
        : <><label className="nv-f"><span>{tr("Username")}</span><input value={f.user} onChange={e => setF({ ...f, user: e.target.value })} /></label><label className="nv-f"><span>{tr("Password")}</span><input type="password" value={f.pass} onChange={e => setF({ ...f, pass: e.target.value })} /></label></>)}
      {tr(err && <div className="nv-err">{tr(err)}</div>)}<button className="nv-btn big wide" onClick={login}>{tr("Sign in")}</button></div></div></main>;
  return <div className="nv">{tr(header)}{tr(body)}</div>;
}

export function AdminVendors({ apps, setApps }: Apps) {
  const list = apps.filter(a => a.v);
  const [form, setForm] = useState<Record<string, any>>({}); const [err, setErr] = useState<Record<string, string>>({}); const [note, setNote] = useState<Record<string, string>>({});
  const upd = (a: App_, p: any, status?: any) => setApps(apps.map(x => x.id === a.id ? { ...x, status: status || x.status, v: { ...x.v, ...p } } : x));
  if (list.length === 0) return <div className="nv-empty"><h3>{tr("No vendor applications yet")}</h3><p>{tr("Applications submitted from the vendor portal appear here for KYC verification and commercial approval.")}</p></div>;
  return <div className="pt-list">{tr(list.map(a => { const v = a.v; const r = v.reg; const fm = form[a.id] || { comm: {}, other: {}, pay: '', settle: '' };
    const approve = () => { const o: Record<string, string> = {}; r.cats.forEach((c: string) => { const p = Number(fm.comm[c]); if (!(p > 0 && p < 100)) o['c' + c] = 'Enter the commission %.'; }); if (!fm.pay) o.pay = 'Choose the payment model.'; if (!fm.settle) o.settle = 'Choose the settlement cycle.'; setErr(o); if (Object.keys(o).length) return;
      upd(a, { commission: Object.fromEntries(r.cats.map((c: string) => [c, { pct: Number(fm.comm[c]), other: fm.other[c] || '' }])), payModel: fm.pay, settle: fm.settle, approvedAt: Date.now(), step: 0 }, 'approved'); };
    return <div className="pt-card" key={a.id}><div className="pt-row"><b>{tr(a.shop)}</b><span className={'pt-chip a-' + (a.status === 'approved' ? 'approved' : a.status === 'rejected' ? 'rejected' : 'pending')}>{tr(a.status === 'changes' ? 'changes requested' : v.live ? 'live' : a.status)}</span></div>
      <p className="pt-note">{tr(r.owner)} · {tr(r.btype)} · {tr(r.constitution)} · {tr(a.phone)} · {tr(r.email)}</p>
      <Acc t={tr("Application details")}><div className="vp-kv">{tr(([['Registered address', r.regAddr], ['Warehouse address(es)', r.whAddr], ['Billing address', r.sameBill ? 'Same as registered' : r.billAddr], ['GSTIN', r.gstin], ['Contact person', r.contact], ['Years in business', r.years], ['Categories', r.cats.join(', ')], ['Operating hours', r.open + ' to ' + r.close], ['Weekly holidays', r.holidays.join(', ') || 'None'], ['Bank', v.bank.holder + ', ' + v.bank.bank + ', a/c ending ' + v.bank.acc.slice(-4) + ', ' + v.bank.ifsc + (v.bank.upi ? ', UPI ' + v.bank.upi : '')], ['GST-linked business name', v.bank.gstName], ['Cancelled cheque', v.bank.cheque], ['Declaration', v.decl.auth + ', ' + v.decl.desig + ', ' + v.decl.date + ', signed ' + v.decl.sign], ['Terms accepted', 'Core terms, agreement/SLA/policies, declaration']] as [string, string][]).map(([k, x]) => <p key={k}><b>{tr(k)}:</b> {tr(x)}</p>))}</div>
        <h3 className="pt-h3">{tr("KYC and product documents")}</h3><div className="vp-kv">{tr(Object.entries(v.docs).map(([k, x]) => <p key={k}><b>{tr(k.replace(/^p:/, ''))}:</b> {tr(String(x))}</p>))}{tr(Object.entries(v.na || {}).filter(([, x]) => x).map(([k]) => <p key={k}><b>{tr(k)}:</b>{tr(" marked not applicable")}</p>))}</div></Acc>
      {tr(a.status === 'pending' && <><h3 className="pt-h3">{tr("KYC verified. Commercial approval")}</h3><div className="ob-grid">{tr(r.cats.map((c: string) => <F key={c} l={tr('Commission % for ' + c)} e={err['c' + c]}><input value={fm.comm[c] || ''} inputMode="decimal" onChange={e => setForm({ ...form, [a.id]: { ...fm, comm: { ...fm.comm, [c]: e.target.value.replace(/[^\d.]/g, '') } } })} /></F>))}
        <F l={tr("Payment model")} e={err.pay}><select value={fm.pay} onChange={e => setForm({ ...form, [a.id]: { ...fm, pay: e.target.value } })}><option value="">{tr("Select")}</option><option value={"Prepaid vendor settlement"}>{tr("Prepaid vendor settlement")}</option><option value={"Credit vendor"}>{tr("Credit vendor")}</option><option value={"COD / collection"}>{tr("COD / collection")}</option></select></F>
        <F l={tr("Settlement cycle")} e={err.settle}><select value={fm.settle} onChange={e => setForm({ ...form, [a.id]: { ...fm, settle: e.target.value } })}><option value="">{tr("Select")}</option>{tr(['T+1', 'T+2', 'T+3', 'Weekly', 'Biweekly'].map(x => <option key={x} value={x}>{tr(x)}</option>))}</select></F></div>
        <F l={tr("Note to vendor (required for changes / rejection)")}><input value={note[a.id] || ''} onChange={e => setNote({ ...note, [a.id]: e.target.value })} /></F>
        <div className="pt-acts"><button className="nv-btn" onClick={approve}>{tr("Approve vendor")}</button><button className="nv-btn ghost" onClick={() => { if (!(note[a.id] || '').trim()) { setErr({ ...err, note: 'Add a note.' }); return; } upd(a, { adminNote: note[a.id] }, 'changes'); }}>{tr("Request changes")}</button><button className="nv-btn ghost" onClick={() => { if (!(note[a.id] || '').trim()) { setErr({ ...err, note: 'Add a note.' }); return; } upd(a, { adminNote: note[a.id] }, 'rejected'); }}>{tr("Reject")}</button></div>{tr(err.note && <div className="nv-err">{tr(err.note)}</div>)}</>)}
      {tr(a.status === 'approved' && <p className="pt-note">{tr("Onboarding: ")}<b>{tr(v.live ? 'Live with ' + (v.skus || []).length + ' SKUs' : POST[v.step || 0] + ' step')}</b>{tr(". Commission: ")}{tr(r.cats.map((c: string) => c + ' ' + v.commission?.[c]?.pct + '%').join(', '))}. {tr(v.payModel)}, {tr(v.settle)}.</p>)}
      {tr((a.status === 'rejected' || a.status === 'changes') && <p className="pt-note">{tr("Note sent: ")}{tr(v.adminNote)}</p>)}
    </div>; }))}</div>;
}
