import { tr } from './i18n';
import React, { useState } from 'react';
import { CATS, PRODUCTS, inr, isServiceable, COMING_SOON, type App_, type Ob, newOb } from './data';
import { Icon } from './Icon';

const STEPS = ['Business', 'Documents', 'Catalogue', 'Service area', 'Payout', 'Review'];
const DOCS: [string, string, string][] = [['gst', 'GST registration certificate', 'PDF or photo'], ['pan', 'PAN card of owner or firm', 'PDF or photo'], ['shop', 'Shop licence / Udyam certificate', 'PDF or photo'], ['cheque', 'Cancelled cheque or bank passbook page', 'PDF or photo']];
const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const F = ({ l, e, children }: { l: string; e?: string; children: React.ReactNode }) => <label className={'nv-f' + (e ? ' bad' : '')}><span>{tr(l)}</span>{tr(children)}{tr(e && <em>{tr(e)}</em>)}</label>;

export function Onboarding({ app, save, commission, open }: { app: App_; save: (a: App_) => void; commission: number; open: () => void }) {
  const ob = app.ob ?? newOb(app.gst);
  const [err, setErr] = useState<Record<string, string>>({});
  const set = (p: Partial<Ob>) => save({ ...app, ob: { ...ob, ...p } });
  const go = (n: number) => { setErr({}); set({ step: n }); };
  const steps = STEPS;
  const head = <div className="ob-top"><span className="nv-pill dark">{tr("Dealer onboarding")}</span><h1>{tr(app.shop)}</h1></div>;

  if (app.status === 'pending') return <main className="pt ob">{tr(head)}<div className="ob-card center"><span className="nv-done-i"><Icon n="clock" size={30} /></span><h2>{tr("Your application is being reviewed")}</h2><p>{tr("Our team is checking ")}{tr(app.shop)}{tr(". Once approved, onboarding opens here with the same mobile number.")}</p></div></main>;
  if (app.status === 'rejected') return <main className="pt ob">{tr(head)}<div className="ob-card center"><h2>{tr("Application not approved")}</h2><p>{tr("We could not approve this application right now. Please contact the Kwenzo dealer team.")}</p></div></main>;

  if (ob.stage === 'live') return <main className="pt ob">{tr(head)}<div className="ob-card center"><span className="nv-done-i"><Icon n="check" size={34} /></span><h2>{tr("You are live on Kwenzo")}</h2><p>{tr(app.shop)}{tr(" is verified. ")}{tr(Object.keys(ob.items).length)}{tr(" products are visible to builders within ")}{tr(ob.svc.radius)}{tr(" km. Payouts go to account ending ")}{tr(ob.bank.acc.slice(-4))}.</p><button className="nv-btn big" onClick={open}>{tr("Open dealer dashboard")}</button></div></main>;

  if (ob.stage === 'review') return <main className="pt ob">{tr(head)}<Stepper cur={6} />
    <div className="ob-card center"><span className="nv-done-i"><Icon n="clock" size={30} /></span><h2>{tr("Submitted for verification")}</h2><p>{tr("The Kwenzo team is checking your documents, catalogue and bank details. We will call ")}{tr(app.phone)}{tr(" if anything needs fixing. You go live as soon as it is verified.")}</p>
      <ul className="ob-sum"><li><b>{tr(Object.keys(ob.docs).length)}/4</b>{tr(" documents")}</li><li><b>{tr(Object.keys(ob.items).length)}</b>{tr(" products priced")}</li><li><b>{tr(ob.svc.radius)}{tr(" km")}</b>{tr(" service radius")}</li></ul></div></main>;

  const miss = (k: string, v: boolean, m: string, o: Record<string, string>) => { if (!v) o[k] = m; };
  const next = () => {
    const o: Record<string, string> = {};
    if (ob.step === 0) { miss('addr', ob.biz.addr.trim().length > 5, 'Enter your full shop address.', o); miss('pin', /^\d{6}$/.test(ob.biz.pin) && isServiceable(ob.biz.pin), /^\d{6}$/.test(ob.biz.pin) ? COMING_SOON : 'Enter a 6-digit pincode.', o); miss('gst', /^\d{2}[A-Z]{5}\d{4}[A-Z][A-Z\d]Z[A-Z\d]$/.test(ob.biz.gst), 'Enter a valid 15-character GSTIN, e.g. 29ABCDE1234F1Z5.', o); miss('years', ob.biz.years !== '', 'Select how long you have been in business.', o); }
    if (ob.step === 1) DOCS.forEach(([k, l]) => miss(k, !!ob.docs[k], 'Upload: ' + l, o));
    if (ob.step === 2) { miss('cats', ob.cats.length > 0, 'Choose at least one category.', o); miss('items', Object.keys(ob.items).length >= 3, 'Price at least 3 products to continue.', o); }
    if (ob.step === 3) { miss('minOrder', Number(ob.svc.minOrder) >= 0 && ob.svc.minOrder !== '', 'Enter a minimum order value.', o); }
    if (ob.step === 4) { miss('holder', ob.bank.holder.trim().length > 2, 'Enter the account holder name.', o); miss('acc', /^\d{9,18}$/.test(ob.bank.acc), 'Account number should be 9 to 18 digits.', o); miss('ifsc', /^[A-Z]{4}0[A-Z0-9]{6}$/.test(ob.bank.ifsc), 'Enter a valid IFSC, e.g. HDFC0001234.', o); }
    setErr(o); if (Object.keys(o).length === 0) go(ob.step + 1);
  };
  const submit = () => { if (!ob.agree.every(Boolean)) { setErr({ agree: 'Please accept all three to submit.' }); return; } set({ stage: 'review', submittedAt: Date.now(), note: undefined }); };
  const prods = PRODUCTS.filter(p => ob.cats.includes(p.cat));
  const setItem = (id: string, v: string) => { const n = Number(v.replace(/[^\d.]/g, '')); const items = { ...ob.items }; if (!n) delete items[id]; else items[id] = n; set({ items }); };
  const done = [ob.biz.addr && ob.biz.gst, Object.keys(ob.docs).length === 4, Object.keys(ob.items).length >= 3, true, ob.bank.acc, ob.agree.every(Boolean)];

  return <main className="pt ob">{tr(head)}<Stepper cur={ob.step} />
    {tr(ob.note && <div className="ob-note"><b>{tr("Changes requested by Kwenzo:")}</b> {tr(ob.note)}</div>)}
    <div className="ob-card">
      {tr(ob.step === 0 && <><h2>{tr("Business details")}</h2><p className="pt-note">{tr("Welcome to Kwenzo. Six short steps and you are live.")}</p>
        <div className="ob-grid"><F l={tr("Business type")}><select value={ob.biz.type} onChange={e => set({ biz: { ...ob.biz, type: e.target.value } })}>{tr(['Retail dealer', 'Wholesaler', 'Manufacturer / factory outlet', 'Distributor'].map(t => <option key={t} value={t}>{tr(t)}</option>))}</select></F>
          <F l={tr("Years in business")} e={err.years}><select value={ob.biz.years} onChange={e => set({ biz: { ...ob.biz, years: e.target.value } })}><option value="">{tr("Select")}</option>{tr(['Less than 1', '1 to 3', '3 to 10', 'More than 10'].map(t => <option key={t} value={t}>{tr(t)}</option>))}</select></F></div>
        <F l={tr("Shop / godown address")} e={err.addr}><input value={ob.biz.addr} onChange={e => set({ biz: { ...ob.biz, addr: e.target.value } })} placeholder={tr("Shop no, street, area")} /></F>
        <div className="ob-grid"><F l={tr("Pincode")} e={err.pin}><input value={ob.biz.pin} inputMode="numeric" maxLength={6} onChange={e => set({ biz: { ...ob.biz, pin: e.target.value.replace(/\D/g, '') } })} /></F>
          <F l={tr("GSTIN")} e={err.gst}><input value={ob.biz.gst} maxLength={15} onChange={e => set({ biz: { ...ob.biz, gst: e.target.value.toUpperCase() } })} /></F></div></>)}
      {tr(ob.step === 1 && <><h2>{tr("Documents")}</h2><p className="pt-note">{tr("We verify these once. Clear photos or PDFs are fine. In this preview only the file name is kept.")}</p>
        {tr(DOCS.map(([k, l, h]) => <div className={'ob-doc' + (err[k] ? ' bad' : '')} key={k}><div><b>{tr(l)}</b><em>{tr(ob.docs[k] ? ob.docs[k] : err[k] ?? h)}</em></div>
          {tr(ob.docs[k] ? <button className="nv-btn ghost" onClick={() => { const d = { ...ob.docs }; delete d[k]; set({ docs: d }); }}>{tr("Remove")}</button> : <label className="nv-btn ghost ob-up">{tr("Upload")}<input type="file" accept="image/*,.pdf" onChange={e => { const f = e.target.files?.[0]; if (f) set({ docs: { ...ob.docs, [k]: f.name } }); }} /></label>)}
          {tr(!ob.docs[k] && <button className="ob-link" onClick={() => set({ docs: { ...ob.docs, [k]: k + '-sample.pdf' } })}>{tr("Use sample file")}</button>)}</div>))}</>)}
      {tr(ob.step === 2 && <><h2>{tr("Catalogue and prices")}</h2><p className="pt-note">{tr("Pick what you stock, then set your price per unit. Buyers see your price next to other dealers.")}</p>
        <div className="nv-chips wrap">{tr(CATS.map(c => <button key={c.id} className={ob.cats.includes(c.id) ? 'on' : ''} onClick={() => set({ cats: ob.cats.includes(c.id) ? ob.cats.filter(x => x !== c.id) : [...ob.cats, c.id] })}>{tr(c.name)}</button>))}</div>
        {tr(err.cats && <div className="nv-err">{tr(err.cats)}</div>)}
        {tr(prods.length > 0 && <div className="pt-table"><div className="pt-tr h"><span>{tr("Product")}</span><span>{tr("Your price")}</span><span>{tr("Market")}</span></div>{tr(prods.map(p => <div className="pt-tr" key={p.id}><span><b>{tr(p.name)}</b><em>{tr(p.brand)}{tr(" · per ")}{tr(p.unit)}</em></span><span><input className="pt-in" inputMode="numeric" value={ob.items[p.id] ?? ''} placeholder={tr("₹")} aria-label={tr('Price ' + p.name)} onChange={e => setItem(p.id, e.target.value)} /></span><span className="pt-note">{tr(inr(p.price))}</span></div>))}</div>)}
        <p className="pt-note"><b>{tr(Object.keys(ob.items).length)}</b>{tr(" priced so far. You can add more from the dashboard later.")}</p>{tr(err.items && <div className="nv-err">{tr(err.items)}</div>)}</>)}
      {tr(ob.step === 3 && <><h2>{tr("Service area")}</h2>
        <div className="ob-grid"><F l={tr("Delivery radius")}><select value={ob.svc.radius} onChange={e => set({ svc: { ...ob.svc, radius: e.target.value } })}>{tr(['5', '10', '15', '25', '40'].map(r => <option key={r} value={r}>{tr(r)}{tr(" km from your shop")}</option>))}</select></F>
          <F l={tr("Minimum order (₹)")} e={err.minOrder}><input value={ob.svc.minOrder} inputMode="numeric" onChange={e => set({ svc: { ...ob.svc, minOrder: e.target.value.replace(/\D/g, '') } })} /></F></div></>)}
      {tr(ob.step === 4 && <><h2>{tr("Payout details")}</h2><p className="pt-note">{tr("We pay sales after the ")}{tr(commission)}{tr("% Kwenzo fee, straight to this account.")}</p>
        <F l={tr("Account holder name")} e={err.holder}><input value={ob.bank.holder} onChange={e => set({ bank: { ...ob.bank, holder: e.target.value } })} /></F>
        <div className="ob-grid"><F l={tr("Account number")} e={err.acc}><input value={ob.bank.acc} inputMode="numeric" maxLength={18} onChange={e => set({ bank: { ...ob.bank, acc: e.target.value.replace(/\D/g, '') } })} /></F>
          <F l={tr("IFSC")} e={err.ifsc}><input value={ob.bank.ifsc} maxLength={11} onChange={e => set({ bank: { ...ob.bank, ifsc: e.target.value.toUpperCase() } })} /></F>
          <F l={tr("UPI ID (optional)")}><input value={ob.bank.upi} onChange={e => set({ bank: { ...ob.bank, upi: e.target.value } })} /></F></div></>)}
      {tr(ob.step === 5 && <><h2>{tr("Review and go live")}</h2>
        <ul className="ob-check">{tr(['Business details', 'Documents (4 of 4)', 'Catalogue (' + Object.keys(ob.items).length + ' products)', 'Service area', 'Payout account', 'Agreements'].map((l, i) => <li key={l} className={done[i] ? 'ok' : ''}><Icon n="check" size={16} />{tr(l)}{tr(i < 5 && <button className="ob-link" onClick={() => go(i)}>{tr("Edit")}</button>)}</li>))}</ul>
        <h3 className="pt-h3">{tr("Dealer terms")}</h3>
        {tr(['I confirm the business and bank details are correct.', 'I accept the Kwenzo fee of ' + commission + '% on delivered orders and the settlement terms.', 'I will keep stock and prices updated and fulfil accepted orders.'].map((t, i) => <label className="ob-agree" key={i}><input type="checkbox" checked={ob.agree[i]} onChange={e => set({ agree: ob.agree.map((v, j) => j === i ? e.target.checked : v) })} />{tr(t)}</label>))}
        {tr(err.agree && <div className="nv-err">{tr(err.agree)}</div>)}</>)}
      <div className="ob-nav">{tr(ob.step > 0 ? <button className="nv-btn ghost" onClick={() => go(ob.step - 1)}>{tr("Back")}</button> : <span />)}
        {tr(ob.step < 5 ? <button className="nv-btn big" onClick={next}>{tr("Save and continue")}</button> : <button className="nv-btn big" onClick={submit}>{tr("Submit for verification")}</button>)}</div>
    </div></main>;
  function Stepper({ cur }: { cur: number }) { return <ol className="ob-steps">{tr(steps.map((s, i) => <li key={s} className={i < cur ? 'done' : i === cur ? 'cur' : ''}><i>{tr(i < cur ? <Icon n="check" size={14} /> : i + 1)}</i><span>{tr(s)}</span></li>))}</ol>; }
}
