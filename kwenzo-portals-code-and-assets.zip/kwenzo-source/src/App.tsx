import { tr, useLanguage, LanguageSelector } from './i18n';
import React, { useMemo, useState, useEffect, useRef } from 'react';
import { useLocalState as _uls, Routes, Route, useLocation, useNavigate } from '@instinct/files';
import { CATS, PRODUCTS, SUPPLIERS, supplierFor, priceAt, inr, seedOrders, seedApps, DEFAULT_SETTINGS, isServiceable, COMING_SOON, type Product, type Supplier, type Order, type Status, type Settings, type App_ } from './data';
import { PortalPage } from './Portals';
import { Icon } from './Icon';
import { AccountPage, SiteFields, BillFields, siteErrors, billErrors, emptySite, type Cust } from './Account';
import skuPrice from './skuprice.json';
import hero from './photos/hero.jpg';
import heroTruck from './photos/hero-truck.jpg';
import skuData from './skus.json';
import { HR_IMG } from './hrimg';
import HRD from './hrdata.json';
import famData from './variants.json';
import { SKU_IMG, SKU_GALLERY, SKU_HIGHLIGHTS, SKU_DESC, SKU_DOC, SKU_RETURNS } from './skuimg';
import heroBanner from './photos/hero-banner.jpg';
import mc_cement from './photos/cat/cement.jpg';
import mc_tiling from './photos/cat/tiling.jpg';
import mc_paints from './photos/cat/paints.jpg';
import mc_plywood from './photos/cat/plywood.jpg';
import mc_adhesives from './photos/cat/adhesives.jpg';
import mc_electricals from './photos/cat/electricals.jpg';
import mc_bath from './photos/cat/bath.jpg';
import mc_furniture from './photos/cat/furniture.jpg';
import mc_locks from './photos/cat/locks.jpg';
import mc_hardware from './photos/cat/hardware.jpg';
import mc_plumbing from './photos/cat/plumbing.jpg';
import mc_waterproof from './photos/cat/waterproof.jpg';
import mc_safety from './photos/cat/safety.jpg';
import truck from './photos/truck.jpg';
import './style.css';

type Line = { pid: string; sid: string; qty: number };
type View = 'home' | 'shop' | 'track' | 'partner' | 'cart' | 'account';
const MCATS: { name: string; id: string; img: string }[] = [
  { name: 'Cement & Plaster', id: 'cement', img: mc_cement }, { name: 'Tiling & Grouts', id: 'tiling', img: mc_tiling }, { name: 'Paints & Putty', id: 'paints', img: mc_paints }, { name: 'Plywood & MDF', id: 'plywood', img: mc_plywood },
  { name: 'Fevicol & Adhesives', id: 'adhesives', img: mc_adhesives }, { name: 'Electricals & Lights', id: 'electricals', img: mc_electricals }, { name: 'Bath Fittings & Sanitary', id: 'bath', img: mc_bath }, { name: 'Furniture Fittings', id: 'furniture', img: mc_furniture },
  { name: 'Locks & Handles', id: 'locks', img: mc_locks }, { name: 'Hardware & Tools', id: 'hardware', img: mc_hardware }, { name: 'Plumbing Pipes & Fittings', id: 'plumbing', img: mc_plumbing }, { name: 'Waterproofing & Repairs', id: 'waterproof', img: mc_waterproof },
  { name: 'Safety & Protection', id: 'safety', img: mc_safety },
];
type Sku = { c: string; n: string; b: string; s: string; col: string; d: string; w: string; i: boolean; t: string; g: string };
const SKUS: Sku[] = skuData as Sku[];
const skuImg = (c: string): string => { const k = HR_IMG[c] || SKU_IMG[c] ? c : ALIAS[c] || c; return (HR_IMG[k] && HR_IMG[k][0]) || SKU_IMG[k]; };
const HRDATA = HRD as Record<string, { hl: any[]; ds: any[]; rt: any[] }>;
function Blocks({ b }: { b: any[] }) {
  const li = (it: any, k: number) => <li key={k}>{tr(it[0] && <b>{tr(it[0])}{tr(it[1] ? ': ' : '')}</b>)}{tr(it[1])}{tr(it[2] && it[2].length > 0 && <ul>{tr(it[2].map((s: string, j: number) => <li key={j}>{tr(s)}</li>))}</ul>)}</li>;
  return <>{tr(b.map((x, n) => x[0] === 'h' ? <h3 key={n}>{tr(x[1])}</h3> : x[0] === 'p' ? <p key={n}>{tr(x[1])}</p> : x[0] === 'ul' ? <ul key={n}>{tr(x[1].map(li))}</ul> : x[0] === 'ol' ? <ol key={n}>{tr(x[1].map(li))}</ol> : <div key={n} className="ms-tw"><table><thead><tr>{tr(x[1][0].map((c: string, k: number) => <th key={k}>{tr(c)}</th>))}</tr></thead><tbody>{tr(x[1].slice(1).map((r: string[], k: number) => <tr key={k}>{tr(r.map((c, j) => <td key={j}>{tr(c)}</td>))}</tr>))}</tbody></table></div>))}</>;
}
const SKUP: Record<string, number[]> = skuPrice as any;
const SKUN: Record<string, Sku> = Object.fromEntries(SKUS.map(s => [s.c, s]));
type Fam = { o: string[]; v: [string, string, number, string[]][]; m: number; h: string[] };
const FAM = famData as Record<string, Fam>;
const ALIAS: Record<string, string> = {};
const VP: Record<string, number> = {};
const HIDDEN = new Set<string>();
Object.entries(FAM).forEach(([p, f]) => { f.v.forEach(([c, l, pr]) => { if (c !== p) ALIAS[c] = p; if (!SKUN[c]) { SKUN[c] = { ...SKUN[p], c, n: SKUN[p].n + ' - ' + l }; } VP[c] = pr; }); f.h.forEach(c => HIDDEN.add(c)); });

const isSku = (id: string) => id.startsWith('sku:');
function useMobile() { const [m, setM] = useState(() => typeof window !== 'undefined' && window.matchMedia('(max-width:700px)').matches); useEffect(() => { const q = window.matchMedia('(max-width:700px)'); const f = () => setM(q.matches); q.addEventListener('change', f); return () => q.removeEventListener('change', f); }, []); return m; }
const CITIES = ['Hyderabad'];
const prod = (id: string): any => isSku(id) ? { id, name: SKUN[id.slice(4)].n, cat: 'sku', unit: 'pc', step: 1, sku: id.slice(4), skuPrice: VP[id.slice(4)] ?? SKUP[id.slice(4)][0] } : PRODUCTS.find(p => p.id === id)!;
const supp = (id: string) => SUPPLIERS.find(s => s.id === id)!;
const unitPrice = (p: any, s: Supplier, qty: number) => p.sku ? p.skuPrice : priceAt(p, s) - (p.bulkAt && p.bulkOff && qty >= p.bulkAt ? p.bulkOff : 0);
const rid = (pre: string) => pre + '-' + Math.random().toString(36).slice(2, 7).toUpperCase();

const SHOW_PRICES = true; // set false to hide SKU prices on cards (cart still totals)
function useLocalState<T>(key: string, init: T): [T, (v: T) => void] {
  const [v, setV] = useState<T>(() => { try { const s = window.localStorage.getItem(key); if (s) return JSON.parse(s) as T; } catch (e) { /* storage blocked */ } return init; });
  const set = (n: T) => { setV(n); try { window.localStorage.setItem(key, JSON.stringify(n)); } catch (e) { /* storage blocked */ } };
  useEffect(() => { const sync = () => { try { const s = window.localStorage.getItem(key); if (s && s !== JSON.stringify(vRef.current)) setV(JSON.parse(s) as T); } catch (e) { /* storage blocked */ } }; const t = setInterval(sync, 2000); window.addEventListener('storage', sync); return () => { clearInterval(t); window.removeEventListener('storage', sync); }; }, [key]);
  const vRef = useRef(v); vRef.current = v;
  return [v, set];
}
const SKU_SID = SUPPLIERS[0].id;
export function App() {
  useLanguage();
  const nav = useNavigate(); const loc = useLocation();
  const pcode = ((loc as any)?.pathname || '').match(/^\/product\/([A-Za-z0-9]+)/)?.[1] || '';
  const [view, setView] = useState<View>(pcode ? 'shop' : 'home');
  useEffect(() => { if (pcode) setView('shop'); try { const h = '#' + encodeURIComponent(pcode ? '/product/' + pcode : '/'); if (location.hash !== h && !/supplier|logistics|admin/.test(decodeURIComponent(location.hash))) history.replaceState(null, '', h); } catch (e) {} }, [pcode]);
  const [city, setCity] = useState('Hyderabad');
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('all');
  const [sort, setSort] = useState('pop');
  const [cart, setCart] = useLocalState<Line[]>('neev-cart.v1', []);
  const [orders, setOrders] = useLocalState<Order[]>('kwenzo-orders.v3', seedOrders());
  const [custs, setCusts] = useLocalState<Cust[]>('kwenzo-cust.v1', []);
  const [sess, setSess] = useLocalState<string>('kwenzo-sess.v1', '');
  const [authWhy, setAuthWhy] = useState(''); const [wantCheckout, setWantCheckout] = useState(false);
  const me = custs.find(c => c.mobile === sess);
  const myOrders = orders.filter(o => o.cust === sess && !!sess);
  const [settings, setSettings] = useLocalState<Settings>('neev-set.v1', DEFAULT_SETTINGS);
  const [apps, setApps] = useLocalState<App_[]>('kwenzo-apps.v3', seedApps());
    const [step, setStep] = useState<'cart' | 'checkout' | 'done'>('cart');
  const [detail, setDetail] = useState<string | null>(null);
  const isM = useMobile();
  const [help, setHelp] = useState(false);
  const [done, setDone] = useState<{ id: string; slot: string; pay: string; total: number } | null>(null);
  
  const top = () => setTimeout(() => document.querySelector('.nv-top')?.scrollIntoView(), 30);
  const go = (v: View, c?: string) => { nav('/'); setView(v); if (c) setCat(c); setDetail(null); top(); };
  const [added, setAdded] = useState('');
  
  const count = cart.length;
  const add = (pid: string, sid: string, qty: number) => {
    const next = [...cart];
    const i = next.findIndex(l => l.pid === pid && l.sid === sid);
    if (i >= 0) next[i] = { ...next[i], qty: next[i].qty + qty }; else next.push({ pid, sid, qty });
    setCart(next); setAdded(pid); setTimeout(() => setAdded(''), 1600);
  };
  const setQty = (i: number, qty: number) => { const n = [...cart]; if (qty <= 0) n.splice(i, 1); else n[i] = { ...n[i], qty }; setCart(n); };
  const sub = cart.reduce((a, l) => a + unitPrice(prod(l.pid), supp(l.sid), l.qty) * l.qty, 0);
  const fee = sub === 0 ? 0 : sub >= settings.freeAbove ? 0 : settings.fee;
  const total = sub + fee;

  
  const tbTxt = <><span>{tr("Free delivery on orders above ")}{tr(inr(settings.freeAbove))}</span><span className="nv-dot" /><span>{tr("Pick your material, add to cart, done")}</span><span className="nv-dot" /></>;
  const topbar = <div className="nv-top nv-mq"><div className="nv-mq-t">{tr(tbTxt)}{tr(tbTxt)}{tr(tbTxt)}{tr(tbTxt)}</div></div>;

  const store = <div className="nv">
    {tr(topbar)}
    <header className="nv-head">
      <button className="nv-logo" onClick={() => go('home')} aria-label={tr("Kwenzo home")}><span className="nv-mark">{tr("K")}</span><span>{tr("Kwenzo")}</span></button>
      <label className="nv-city"><Icon n="pin" size={18} /><b>{tr(city)}</b></label>
      <Form className="nv-search" onSubmit={e => { e.preventDefault(); go('shop'); }}><Icon n="search" size={18} /><input value={q} onChange={e => { setQ(e.target.value); if (view !== 'shop') setView('shop'); }} placeholder={tr(isM ? 'What do you need today?' : 'Search cement, bricks, tiles, Havells...')} aria-label={tr("Search materials")} /></Form>
      <nav className="nv-nav">
        <button className={view === 'shop' ? 'on' : ''} onClick={() => go('shop', 'all')}>{tr("Shop")}</button>
        <button className={view === 'track' ? 'on' : ''} onClick={() => go('track')}>{tr("Track")}</button>
        <button className={view === 'account' ? 'on' : ''} onClick={() => { setAuthWhy(''); setWantCheckout(false); go('account'); }}>{tr(me ? 'Hi, ' + me.name.trim().split(' ')[0] : 'Sign in')}</button>
      </nav>
      <button className="nv-cartbtn" onClick={() => { setStep('cart'); go('cart'); }} aria-label={tr("Open cart")}><Icon n="cart" size={22} />{tr(count > 0 && <b>{tr(count)}</b>)}</button>
    </header>
    <nav className="nv-mnav">
      <button className={view === 'shop' ? 'on' : ''} onClick={() => go('shop', 'all')}>{tr("Shop")}</button>
      <button className={view === 'track' ? 'on' : ''} onClick={() => go('track')}>{tr("Track")}</button>
      <button className={view === 'account' ? 'on' : ''} onClick={() => { setAuthWhy(''); setWantCheckout(false); go('account'); }}>{tr(me ? 'Hi, ' + me.name.trim().split(' ')[0] : 'Sign in')}</button>
    </nav>

    {tr(!detail && view !== 'cart' && <div className="mb-float">
      <div className={'mb-strip' + (sub >= settings.freeAbove ? ' ok' : '')}><span className="mb-ring" style={{ ['--p' as any]: Math.min(1, sub / settings.freeAbove) }}><Icon n="truck" size={20} /></span><div>{tr(count === 0 ? <><b>{tr("Free delivery")}</b><span>{tr("On orders above ")}{tr(inr(settings.freeAbove))}</span></> : sub >= settings.freeAbove ? <><b>{tr("Free delivery unlocked")}</b><span>{tr("Delivery is on us for this order")}</span></> : <><b>{tr("Unlock free delivery")}</b><span>{tr("Shop for ")}{tr(inr(settings.freeAbove - sub))}{tr(" more")}</span></>)}</div></div>
      <button className="mb-cart" onClick={() => { setStep('cart'); go('cart'); }} aria-label={tr("Open cart")}><span className="mb-cart-i"><Icon n="cart" size={22} />{tr(count > 0 && <b>{tr(count)}</b>)}</span><span><b>{tr("Cart")}</b><i>{tr(count === 0 ? 'Empty' : count + (count === 1 ? ' item' : ' items'))}</i></span></button>
    </div>)}
    <nav className="mb-nav" aria-label={tr("Main")}>
      <button className={view === 'home' ? 'on' : ''} onClick={() => go('home')}><Icon n="home" size={24} /><span>{tr("Home")}</span></button>
      <button className={view === 'track' ? 'on' : ''} onClick={() => go('track')}><Icon n="reorder" size={24} /><span>{tr("Orders")}</span></button>
      <button className={view === 'shop' ? 'on' : ''} onClick={() => go('shop', 'all')}><Icon n="grid" size={24} /><span>{tr("Categories")}</span></button>
      <button className={view === 'account' ? 'on' : ''} onClick={() => { setAuthWhy(''); setWantCheckout(false); go('account'); }}><Icon n="user" size={24} /><span>{tr(me ? 'Account' : 'Sign in')}</span></button>
      <button className={'help' + (help ? ' on' : '')} onClick={() => setHelp(!help)}><Icon n="help" size={24} /><span>{tr("Need help?")}</span></button>
    </nav>
    {tr(help && <div className="mb-help" role="dialog" aria-label={tr("Need help")}><b>{tr("Need help?")}</b><p>{tr("Check where your order is, or tell us what material you are looking for.")}</p><button className="nv-btn" onClick={() => { setHelp(false); go('track'); }}>{tr("Track my order")}</button><button className="nv-btn ghost" onClick={() => { setHelp(false); go('shop', 'all'); }}>{tr("Browse all materials")}</button></div>)}

    {tr(detail && <Detail p={prod(detail)} close={() => setDetail(null)} add={(sid, qty) => { add(detail, sid, qty); setStep('cart'); go('cart'); }} />)}
    {tr(!detail && view === 'home' && <Home city={city} go={go} setDetail={(id: string) => { setDetail(id); top(); }} />)}
    {tr(!detail && view === 'shop' && <MobileShop code={pcode} openSku={(c: string) => nav('/product/' + c)} closeSku={() => nav('/')} goHome={() => go('home')} q={q} cat={cat} setCat={setCat} cart={cart} addSku={(c: string, d: number) => { const id = 'sku:' + c; const i = cart.findIndex(l => l.pid === id); const n = [...cart]; if (i < 0) { if (d > 0) n.push({ pid: id, sid: SKU_SID, qty: 1 }); } else { const q2 = n[i].qty + d; if (q2 <= 0) n.splice(i, 1); else n[i] = { ...n[i], qty: q2 }; } try { setCart(n); } catch (e) { /* ignore */ } }} />)}
    {tr(!detail && view === 'track' && (me ? <Track orders={myOrders} go={go} /> : <main className="nv-page"><div className="nv-empty"><h3>{tr("Sign in to track your orders")}</h3><p>{tr("Your orders and their status are in your account.")}</p><button className="nv-btn" onClick={() => { setAuthWhy('Sign in to track your orders'); setWantCheckout(false); go('account'); }}>{tr("Sign in")}</button></div></main>))}
    {tr(!detail && view === 'account' && <AccountPage custs={custs} setCusts={setCusts} sess={sess} setSess={setSess} orders={myOrders} nameOf={(pid) => prod(pid).name} shop={(c?: string) => { const m = c && c !== 'all' ? CATS.find(x => x.name.toLowerCase().startsWith(c.toLowerCase())) : undefined; go('shop', m ? m.id : 'all'); }} track={() => go('track')} reason={authWhy} afterAuth={() => { if (wantCheckout) { setWantCheckout(false); setStep('checkout'); setView('cart'); top(); } }} />)}

    {tr(!detail && view === 'cart' && <main className="nv-cartpage">
      <h1>{tr(step === 'checkout' ? 'Checkout' : step === 'done' ? 'Order placed' : 'Your cart')}</h1>
      <div className="nv-cartbox">
        {tr(step === 'cart' && <CartView cart={cart} setQty={setQty} sub={tr(sub)} fee={fee} total={total} free={settings.freeAbove} next={() => { if (!me) { setAuthWhy('Sign in to place your order'); setWantCheckout(true); setView('account'); top(); return; } setStep('checkout'); top(); }} browse={() => go('shop', 'all')} />)}
        {tr(step === 'checkout' && <Checkout me={me} upd={(p: Partial<Cust>) => setCusts(custs.map(c => c.mobile === sess ? { ...c, ...p } : c))} total={total} sub={tr(sub)} fee={fee} city={city} back={() => setStep('cart')} place={(o) => {
          const groups = new Map<string, Line[]>(); cart.forEach(l => groups.set(l.sid, [...(groups.get(l.sid) || []), l]));
          const made: Order[] = Array.from(groups.entries()).map(([sid, ls], i) => ({ id: rid('KZ'), at: Date.now(), name: o.name, phone: o.phone, addr: o.addr, pin: o.pin, city, slot: o.slot, pay: o.pay, sid, status: 'placed' as Status, mine: true, cust: sess,
            lines: ls.map(l => ({ pid: l.pid, qty: l.qty, up: unitPrice(prod(l.pid), supp(l.sid), l.qty) })), total: ls.reduce((a, l) => a + unitPrice(prod(l.pid), supp(l.sid), l.qty) * l.qty, 0) + (i === 0 ? fee : 0) }));
          setDone({ id: made.map(m => m.id).join(', '), slot: o.slot, pay: o.pay, total }); setStep('done'); top();
          try { setOrders([...made, ...orders].slice(0, 300)); setCart([]); } catch (e) { setCart([]); }
        }} />)}
        {tr(step === 'done' && done && <Done o={done} track={() => go('track')} />)}
      </div>
    </main>)}

    <footer className="nv-foot">
      <div className="nv-foot-in">
        <div><div className="nv-logo static"><span className="nv-mark">{tr("K")}</span><span>{tr("Kwenzo")}</span></div><p className="nv-tag">{tr("Building your vision")}</p><p className="nv-small">{tr("Every material for your site, delivered to you at clear prices.")}</p></div>
        <div><h4>{tr("Shop")}</h4>{tr(CATS.slice(0, 5).map(c => <button key={c.id} onClick={() => go('shop', c.id)}>{tr(c.name)}</button>))}</div>
        <div><h4>{tr("More")}</h4>{tr(CATS.slice(5).map(c => <button key={c.id} onClick={() => go('shop', c.id)}>{tr(c.name)}</button>))}</div>
        <div><h4>{tr("Kwenzo")}</h4><button onClick={() => go('track')}>{tr("Track order")}</button><button onClick={() => { setAuthWhy(''); go('account'); }}>{tr(me ? 'My account' : 'Sign in')}</button></div>
      </div>
      <div className="nv-foot-note">{tr("Prices and dealers shown are indicative samples for this preview. Orders are saved on this device only.")}</div>
    </footer>

  </div>;
  const pp = { orders, setOrders, settings, setSettings, apps, setApps };
  return <><LanguageSelector /><Routes><Route path="/" element={store} /><Route path="/product/:code" element={store} /><Route path="/supplier" element={<PortalPage role="supplier" {...pp} />} /><Route path="/logistics" element={<PortalPage role="logistics" {...pp} />} /><Route path="/admin" element={<PortalPage role="admin" {...pp} />} /></Routes></>;
}

function Card({ p, onOpen, onAdd, added }: { p: Product; onOpen: () => void; onAdd?: () => void; added?: boolean }) {
  const sup = supplierFor(p.id);
  const best = Math.min(...sup.map(s => priceAt(p, s)));
  const off = Math.round((1 - best / p.mrp) * 100);
  const cat = CATS.find(c => c.id === p.cat)!;
  return <article className="nv-card">
    <button className="nv-card-img" onClick={onOpen} data-cat={p.cat} aria-label={tr('View ' + p.name)}><Icon n={cat.icon} size={54} />{tr(p.tag && <span className="nv-badge">{tr(p.tag)}</span>)}</button>
    <div className="nv-card-b">
      <div className="nv-brand">{tr(p.brand)}</div>
      <h3 onClick={onOpen}>{tr(p.name)}</h3>
      <p className="nv-spec">{tr(p.spec)}</p>
      <div className="nv-price"><b>{tr(inr(best))}</b><span>/{tr(p.unit)}</span><s>{tr(inr(p.mrp))}</s><em>{tr(off)}{tr("% off")}</em></div>
      <div className="nv-dealers"><Icon n="truck" size={14} />{tr("Delivered by Kwenzo")}</div>
      <div className="nv-card-act"><button className="nv-btn ghost" onClick={onOpen}>{tr("View")}</button>{tr(onAdd && <button className={'nv-btn' + (added ? ' ok' : '')} onClick={onAdd}>{tr(added ? 'Added' : 'Add')}</button>)}</div>
    </div>
  </article>;
}

function Home({ city, go, setDetail }: { city: string; go: (v: View, c?: string) => void; setDetail: (id: string) => void }) {
  const [pin, setPin] = useState('');
  const [pinMsg, setPinMsg] = useState('');
  const check = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\d{6}$/.test(pin)) { setPinMsg('Enter a valid 6-digit pincode.'); return; }
    setPinMsg(isServiceable(pin) ? 'We deliver to ' + pin + ' in ' + city + '.' : COMING_SOON);
  };
  const heroRef = useRef<HTMLElement>(null);
  const onMove = (e: React.PointerEvent) => { const el = heroRef.current; if (!el) return; const r = el.getBoundingClientRect(); el.style.setProperty('--px', String(((e.clientX - r.left) / r.width - 0.5) * 2)); el.style.setProperty('--py', String(((e.clientY - r.top) / r.height - 0.5) * 2)); };
  const onLeave = () => { const el = heroRef.current; if (!el) return; el.style.setProperty('--px', '0'); el.style.setProperty('--py', '0'); };
  useEffect(() => { const el = heroRef.current; if (!el) return; let raf = 0; const upd = () => { raf = 0; const r = el.getBoundingClientRect(); const p = Math.max(-1, Math.min(1, (r.top + r.height / 2 - window.innerHeight / 2) / window.innerHeight)); el.style.setProperty('--sy', String(p)); }; const on = () => { if (!raf) raf = requestAnimationFrame(upd); }; window.addEventListener('scroll', on, { passive: true, capture: true }); window.addEventListener('resize', on); upd(); return () => { window.removeEventListener('scroll', on, true); window.removeEventListener('resize', on); }; }, []);
  const featured = ['c1', 'c2', 'b3', 'g1', 'w1', 't1', 'e1', 'l1'].map(prod);
  return <main className="nv-home">
    <section className="nv-hero-v nv-hb">
      <img className="hb-full" src={heroBanner} alt={tr("Kwenzo: Building your vision. Serving Hyderabad. Pay on delivery and free delivery on orders above ₹5,000. A Kwenzo truck loaded with cement, paint, adhesive, cables and sanitaryware at a construction site.")} />
      <div className="hb-l">
        <span className="hb-pill"><Icon n="pin" size={15} />{tr(" Serving Hyderabad")}</span>
        <h1 className="hb-h">{tr("Building your ")}<em>{tr("vision")}</em></h1>
        <p className="hb-p">{tr("Cement, bricks, tiles, plumbing and more, delivered to your site.")}</p>
        <div className="hb-cards">
          <div><b>{tr("Pay on delivery")}</b><span>{tr("Pay after you receive")}</span></div>
          <div><b>{tr("Free delivery")}</b><span>{tr("on orders above ₹5,000")}</span></div>
        </div>
      </div>
      <div className="hb-r"><img src={heroTruck} alt={tr("")} /><i className="hb-s1" /><i className="hb-s2" /></div>
    </section>

    <section className="nv-delcheck"><div><b>{tr("Delivering across Hyderabad")}</b><span>{tr("Check if we deliver to your site.")}</span></div><Form className="nv-pin" onSubmit={check}><Icon n="pin" size={20} /><input inputMode="numeric" maxLength={6} value={pin} onChange={e => { setPin(e.target.value.replace(/\D/g, '')); setPinMsg(''); }} placeholder={tr("Site pincode")} aria-label={tr("Site pincode")} /><button className="nv-btn">{tr("Check delivery")}</button></Form>{tr(pinMsg && <div className={'nv-pinmsg ' + (/^\d{6}$/.test(pin) && isServiceable(pin) ? 'ok' : 'no')} role="status">{tr(pinMsg)}</div>)}</section>

    <section className="nv-sec nv-catsec">
      <div className="nv-sec-h"><h2><span className="dk">{tr("Shop by category")}</span><span className="mo">{tr("Shop by Categories")}</span></h2><button className="nv-link" onClick={() => go('shop', 'all')}>{tr("See everything")}</button></div>
      <div className="nv-mcats">{tr(MCATS.map(c => <button key={c.name} className="mc" onClick={() => go('shop', c.id)}><span className="mc-i"><img src={c.img} alt={tr("")} loading="lazy" /></span><b>{tr(c.name)}</b></button>))}</div>
      <div className="nv-cats">{tr(CATS.map(c => <button key={c.id} className="nv-cat" data-cat={c.id} onClick={() => go('shop', c.id)}><span className="nv-cat-i"><Icon n={c.icon} size={30} /></span><b>{tr(c.name)}</b><span>{tr(c.hint)}</span></button>))}</div>
    </section>

    <section className="nv-sec">
      <div className="nv-sec-h"><h2>{tr("Popular on site")}</h2><button className="nv-link" onClick={() => go('shop', 'all')}>{tr("View all")}</button></div>
      <div className="nv-pop">{tr(['cement', 'tiling', 'paints', 'plywood', 'adhesives', 'electricals', 'bath', 'plumbing'].map(t => SKUS.find(s => s.t === t && s.i)).filter(Boolean).map((x: any) => <button key={x.c} className="nv-popc" onClick={() => go('shop', x.t)}><span className="ms-img"><img src={skuImg(x.c)} alt={tr("")} loading="lazy" /></span><small>{tr(x.b)}</small><b>{tr(x.n)}</b>{tr(SHOW_PRICES && SKUP[x.c] && <strong>{tr(SKUP[x.c][1] > SKUP[x.c][0] ? 'From ' : '')}{tr(inr(SKUP[x.c][0]))}</strong>)}</button>))}</div>
    </section>

    <section className="nv-how">
      <div className="nv-sec-h light"><h2>{tr("How Kwenzo works")}</h2></div>
      <div className="nv-steps">
        {tr([['list', 'Build your list', 'Search or browse materials and add what your site needs.'], ['tag', 'Pick your items', 'Every item shows a clear price, bulk savings and delivery details.'], ['truck', 'Get it delivered', 'Place your order. It reaches the site, unloaded where you want it.'], ['shield', 'Pay your way', 'UPI, pay on delivery, or credit for registered businesses.']].map(([i, t, d], n) => <div className="nv-step" key={t}><span className="nv-step-n">{tr(n + 1)}</span><Icon n={i} size={30} /><h3>{tr(t)}</h3><p>{tr(d)}</p></div>))}
      </div>
    </section>

    <section className="nv-split">
      <img src={truck} alt={tr("Delivery truck unloading cement, sand and bricks at a site")} />
      <div>
        <h2>{tr("Built for contractors, builders and homeowners")}</h2>
        <p>{tr("Whether you are pouring a slab or running five sites, Kwenzo keeps materials moving so your crew is never standing around.")}</p>
        <ul>
          <li><Icon n="tag" size={20} /><div><b>{tr("Price you can see")}</b><span>{tr("We pick the best nearby price for you. Bulk rates apply automatically in your cart.")}</span></div></li>
          <li><Icon n="truck" size={20} /><div><b>{tr("Delivery to your site")}</b><span>{tr("Each order is delivered where you need it, unloaded where you want it.")}</span></div></li>
          <li><Icon n="list" size={20} /><div><b>{tr("Bulk savings")}</b><span>{tr("Order more and pay less per unit. The saving shows on the product page and in your cart.")}</span></div></li>
        </ul>
        <button className="nv-btn big" onClick={() => go('shop', 'all')}>{tr("Start shopping")}</button>
      </div>
    </section>


  </main>;
}

function Shop({ q, setQ, cat, setCat, sort, setSort, setDetail, add, city, added }: any) {
  const [brand, setBrand] = useState('all');
  const list = useMemo(() => {
    let l = PRODUCTS.filter(p => (cat === 'all' || p.cat === cat) && (brand === 'all' || p.brand === brand) && (!q || (p.name + ' ' + p.brand + ' ' + p.spec).toLowerCase().includes(q.toLowerCase())));
    if (sort === 'lo') l = [...l].sort((a, b) => a.price - b.price);
    if (sort === 'hi') l = [...l].sort((a, b) => b.price - a.price);
    if (sort === 'off') l = [...l].sort((a, b) => b.mrp / b.price - a.mrp / a.price);
    return l;
  }, [q, cat, sort, brand]);
  const brands = Array.from(new Set(PRODUCTS.filter(p => cat === 'all' || p.cat === cat).map(p => p.brand))).sort();
  useEffect(() => setBrand('all'), [cat]);
  const quickAdd = (p: Product) => { const s = supplierFor(p.id).sort((a, b) => priceAt(p, a) - priceAt(p, b))[0]; add(p.id, s.id, p.step); };
  return <main className="nv-shop">
    <div className="nv-shop-h"><div><h1>{tr(cat === 'all' ? 'All materials' : CATS.find(c => c.id === cat)!.name)}</h1><p>{tr(list.length)}{tr(" products, delivering in ")}{tr(city)}</p></div>
      <label className="nv-sort">{tr("Sort")}<select value={sort} onChange={e => setSort(e.target.value)}><option value="pop">{tr("Popular")}</option><option value="lo">{tr("Price: low to high")}</option><option value="hi">{tr("Price: high to low")}</option><option value="off">{tr("Biggest discount")}</option></select></label></div>
    <div className="nv-chips" role="tablist">{tr([{ id: 'all', name: 'All' }, ...CATS].map(c => <button key={c.id} className={cat === c.id ? 'on' : ''} onClick={() => setCat(c.id)}>{tr(c.name)}</button>))}</div>
    <div className="nv-filters"><span>{tr("Brand")}</span><select value={brand} onChange={e => setBrand(e.target.value)} aria-label={tr("Brand")}><option value="all">{tr("All brands")}</option>{tr(brands.map(b => <option key={b} value={b}>{tr(b)}</option>))}</select>{tr(q && <button className="nv-clear" onClick={() => setQ('')}>{tr("Clear search: \"")}{tr(q)}"</button>)}</div>
    {tr(list.length === 0 ? <div className="nv-empty"><h3>{tr("Nothing matches that")}</h3><p>{tr("Try a different word or pick a category.")}</p><button className="nv-btn" onClick={() => { setQ(''); setCat('all'); setSort('pop'); setBrand('all'); }}>{tr("Reset filters")}</button></div>
      : <div className="nv-grid">{tr(list.map(p => <Card key={p.id} p={p} added={added === p.id} onOpen={() => setDetail(p.id)} onAdd={() => quickAdd(p)} />))}</div>)}
  </main>;
}

function Detail({ p, close, add }: { p: Product; close: () => void; add: (sid: string, qty: number) => void }) {
  const sup = supplierFor(p.id).sort((a, b) => priceAt(p, a) - priceAt(p, b));
  const sid = sup[0].id;
  const [qty, setQty] = useState(p.step === 1 ? (p.bulkAt ? Math.min(p.bulkAt, 10) : 1) : p.step);
  const s = supp(sid);
  const up = unitPrice(p, s, qty);
  const cat = CATS.find(c => c.id === p.cat)!;
  return <main className="nv-detail"><button className="nv-link nv-back" onClick={close}>{tr("← Back to shop")}</button><div className="nv-modal">
    <div className="nv-modal-l" data-cat={p.cat}><Icon n={cat.icon} size={96} /><span>{tr(p.brand)}</span></div>
    <div className="nv-modal-r">
      <div className="nv-brand">{tr(cat.name)}</div><h2>{tr(p.name)}</h2><p className="nv-spec">{tr(p.spec)}</p>
      {tr(p.bulkAt && <div className="nv-bulk"><Icon n="tag" size={16} />{tr("Order ")}{tr(p.bulkAt)}+ {tr(p.unit)}{tr(p.bulkAt > 1 && p.unit !== 'kg' ? 's' : '')}{tr(" and save ")}{tr(inr(p.bulkOff!))}{tr(" per ")}{tr(p.unit)}</div>)}
      <div className="nv-bulk"><Icon n="truck" size={16} />{tr("Delivered by Kwenzo")}{tr(s.credit ? ' · Credit available' : '')}</div>
      <div className="nv-qty-row"><div><span>{tr("Quantity (")}{tr(p.unit)})</span><div className="nv-qty"><button onClick={() => setQty(Math.max(p.step, qty - p.step))} aria-label={tr("Decrease")}>-</button><input value={qty} inputMode="numeric" onChange={e => setQty(Math.max(1, Number(e.target.value.replace(/\D/g, '')) || 1))} aria-label={tr("Quantity")} /><button onClick={() => setQty(qty + p.step)} aria-label={tr("Increase")}>+</button></div></div>
        <div className="nv-line-total"><span>{tr("Total, incl. GST")}</span><b>{tr(inr(up * qty))}</b>{tr(up < priceAt(p, s) && <em>{tr("Bulk price applied")}</em>)}</div></div>
      <button className="nv-btn big wide" onClick={() => add(sid, qty)}>{tr("Add to cart")}</button>
    </div></div></main>;
}

function CartView({ cart, setQty, sub, fee, total, free, next, browse }: any) {
  if (!cart.length) return <div className="nv-empty-cart"><Icon n="cart" size={44} /><h3>{tr("Your cart is empty")}</h3><p>{tr("Pick your materials and add them to get started.")}</p><button className="nv-btn" onClick={browse}>{tr("Browse materials")}</button></div>;
  return <><div className="nv-lines">{tr(cart.map((l: Line, i: number) => { const p = prod(l.pid), s = supp(l.sid); const up = unitPrice(p, s, l.qty); return <div className="nv-cl" key={l.pid + l.sid}>
    <span className="nv-cl-i" data-cat={p.cat}>{tr(p.sku ? (SKUN[p.sku].i ? <img src={skuImg(p.sku)} alt={tr("")} style={{ width: '100%', height: '100%', objectFit: 'contain', borderRadius: 10 }} /> : <Icon n="bag" size={26} />) : <Icon n={CATS.find(c => c.id === p.cat)!.icon} size={26} />)}</span>
    <div className="nv-cl-m"><b>{tr(p.name)}</b><span>{tr(p.sku ? SKUN[p.sku].b : 'Delivered by Kwenzo')}</span><div className="nv-qty sm"><button onClick={() => setQty(i, l.qty - p.step)} aria-label={tr("Decrease")}>-</button><span>{tr(l.qty)} {tr(p.unit)}</span><button onClick={() => setQty(i, l.qty + p.step)} aria-label={tr("Increase")}>+</button></div></div>
    <div className="nv-cl-p"><b>{tr(inr(up * l.qty))}</b><button onClick={() => setQty(i, 0)}>{tr("Remove")}</button></div></div>; }))}</div>
    <div className="nv-sum"><div><span>{tr("Subtotal")}</span><b>{tr(inr(sub))}</b></div><div><span>{tr("Delivery")}</span><b>{tr(fee === 0 ? 'Free' : inr(fee))}</b></div>{tr(fee > 0 && <p className="nv-small">{tr("Add ")}{tr(inr(free - sub))}{tr(" more for free delivery.")}</p>)}<div className="tot"><span>{tr("Total (incl. GST)")}</span><b>{tr(inr(total))}</b></div><button className="nv-btn big wide" onClick={next}>{tr("Checkout")}</button></div></>;
}

function Checkout({ me, upd, total, sub, fee, city, back, place }: any) {
  const [f, setF] = useState({ slot: '', pay: 'UPI', gst: false, terms: false });
  const [st, ss] = useState<any>(me?.site || emptySite(me)); const [bl, sb] = useState<any>(me?.bill || { name: me?.biz?.company || me?.name || '', gstin: me?.gstin || '', pan: me?.pan || '', addr: me?.biz?.billAddr || '' });
  const [err, setErr] = useState<Record<string, string>>({});
  const setS = (k: string, v: any) => ss((p: any) => ({ ...p, [k]: v })); const setB = (k: string, v: any) => sb((p: any) => ({ ...p, [k]: v }));
  const pays = ['UPI', 'Card', 'Net banking', 'Bank transfer', 'Pay on delivery'].concat(me?.credit?.status === 'approved' ? ['Kwenzo Credit'] : []);
  const submit = (e: React.FormEvent) => {
    e.preventDefault(); const er: Record<string, string> = { ...siteErrors(st), ...(f.gst ? billErrors(bl, true) : {}) };
    if (!f.terms) er.terms = 'Please accept the terms to place your order';
    setErr(er); if (Object.keys(er).length === 0) {
      upd({ site: st, ...(f.gst ? { bill: bl, gstin: bl.gstin.toUpperCase(), pan: (bl.pan || '').toUpperCase() } : {}) });
      place({ slot: f.slot, pay: f.pay, name: st.contact.trim(), phone: st.phone, addr: [st.addr.trim(), st.building, st.unit, st.landmark].filter(Boolean).join(', '), pin: st.pin });
    }
  };
  return <Form className="nv-form" onSubmit={submit}>
    <h3 className="ac-h3">{tr("Delivery site")}</h3>
    {tr(!me?.site && <p className="nv-small">{tr("First order: please add your site details so delivery goes smoothly. They are saved to your account.")}</p>)}
    <SiteFields f={st} s={setS} e={err} />
    <div className="nv-pay"><span>{tr("Payment")}</span>{tr(pays.map(m => <label key={m} className={f.pay === m ? 'on' : ''}><input type="radio" name="pay" checked={f.pay === m} onChange={() => setF({ ...f, pay: m })} />{tr(m)}</label>))}</div>
    <label className="ac-agree"><input type="checkbox" checked={f.gst} onChange={x => setF({ ...f, gst: x.target.checked })} />{tr(" I need a GST invoice")}</label>
    {tr(f.gst && <><BillFields f={bl} s={setB} e={err} /></>)}
    <label className={'ac-agree' + (err.terms ? ' bad' : '')}><input type="checkbox" checked={f.terms} onChange={x => setF({ ...f, terms: x.target.checked })} />{tr(" I agree to Kwenzo's Customer Terms, delivery requirements and return and refund policy.")}</label>{tr(err.terms && <em className="ac-em">{tr(err.terms)}</em>)}
    <div className="nv-sum"><div><span>{tr("Subtotal")}</span><b>{tr(inr(sub))}</b></div><div><span>{tr("Delivery")}</span><b>{tr(fee === 0 ? 'Free' : inr(fee))}</b></div><div className="tot"><span>{tr("Total")}</span><b>{tr(inr(total))}</b></div>
      <button className="nv-btn big wide">{tr("Place order")}</button><button type="button" className="nv-btn ghost wide" onClick={back}>{tr("Back to cart")}</button></div>
  </Form>;
}
function Field({ l, e, children }: { l: string; e?: string; children: React.ReactNode }) { return <label className={'nv-f' + (e ? ' bad' : '')}><span>{tr(l)}</span>{tr(children)}{tr(e && <em>{tr(e)}</em>)}</label>; }

function Done({ o, track }: { o: { id: string; slot: string; pay: string; total: number }; track: () => void }) {
  return <div className="nv-done"><span className="nv-done-i"><Icon n="check" size={34} /></span><h3>{tr("Order confirmed")}</h3><p>{tr("Your dealer has been notified. Order ID")}</p><div className="nv-oid">{tr(o.id)}</div><p className="nv-small">{tr(o.pay)}<br />{tr("Total ")}{tr(inr(o.total))}</p><button className="nv-btn big wide" onClick={track}>{tr("Track this order")}</button></div>;
}

const STAGES = ['Order confirmed', 'Dealer is packing', 'Out for delivery', 'Delivered'];
const STAGE_OF: Record<Status, number> = { placed: 0, accepted: 1, packed: 1, dispatched: 2, delivered: 3, cancelled: 0 };
function Track({ orders, go }: { orders: Order[]; go: (v: View) => void }) {
  const mine = orders.filter(o => o.mine);
  const [id, setId] = useState(''); const [sel, setSel] = useState<string | null | undefined>(undefined);
  useEffect(() => { if (sel === undefined && mine.length > 0) { setSel(mine[0].id); setId(mine[0].id); } }, [orders]);
  const res = sel ? orders.find(o => o.id === sel) : sel === null ? null : undefined;
  const look = (v: string) => { setId(v); const f = orders.find(o => o.id.toLowerCase() === v.trim().toLowerCase()); setSel(f ? f.id : null); };
  const stage = (o: Order) => STAGE_OF[o.status];
  return <main className="nv-page"><h1>{tr("Track your order")}</h1><p className="nv-lead">{tr("Enter your order ID, or pick a recent one on this device.")}</p>
    <Form className="nv-trackf" onSubmit={e => { e.preventDefault(); look(id); }}><input value={id} onChange={e => setId(e.target.value.toUpperCase())} placeholder={tr("KZ-XXXXX")} aria-label={tr("Order ID")} /><button className="nv-btn">{tr("Track")}</button></Form>
    {tr(mine.length > 0 && <div className="nv-recent">{tr(mine.map(o => <button key={o.id} onClick={() => look(o.id)}>{tr(o.id)}</button>))}</div>)}
    {tr(res === null && <div className="nv-err">{tr("No order with that ID on this device. Check the ID in your confirmation.")}</div>)}
    {tr(res && <div className="nv-trk"><div className="nv-trk-h"><div><b>{tr(res.id)}</b><span>{tr(res.lines.length)}{tr(" item")}{tr(res.lines.length > 1 ? 's' : '')} · {tr(inr(res.total))} · {tr(res.city)}</span></div><span className="nv-pill dark">{tr(res.status === 'cancelled' ? 'Cancelled by dealer' : STAGES[stage(res)])}</span></div>
      {tr(res.status !== 'cancelled' && <ol>{tr(STAGES.map((s, i) => <li key={s} className={i <= stage(res) ? 'on' : ''}><span>{tr(i <= stage(res) ? <Icon n="check" size={14} /> : i + 1)}</span><div><b>{tr(s)}</b><em>{tr(i <= stage(res) ? 'Done' : 'Pending')}</em></div></li>))}</ol>)}
      <p className="nv-small">{tr(res.vehicle ? 'Vehicle ' + res.vehicle + '. ' : '')}{tr("Status updates as your dealer and driver move the order.")}</p></div>)}
    {tr(mine.length === 0 && res === undefined && <div className="nv-empty"><h3>{tr("No orders yet")}</h3><p>{tr("Place an order and it will show up here.")}</p><button className="nv-btn" onClick={() => go('shop')}>{tr("Shop materials")}</button></div>)}
  </main>;
}

function Partner({ onApply }: { onApply: (a: { shop: string; owner: string; city: string; phone: string; gst: string }) => void }) {
  const [f, setF] = useState({ shop: '', name: '', phone: '', city: 'Hyderabad', gst: '' }); const [ok, setOk] = useState(false); const [err, setErr] = useState('');
  if (ok) return <main className="nv-page"><div className="nv-ok"><span className="nv-done-i"><Icon n="check" size={34} /></span><h1>{tr("Thanks, ")}{tr(f.name.split(' ')[0])}</h1><p>{tr("We have your details for ")}{tr(f.shop)}{tr(". Once our team approves it, sign in to the dealer portal with this mobile number to finish onboarding.")}</p></div></main>;
  return <main className="nv-page two"><div><span className="nv-pill dark">{tr("For dealers")}</span><h1>{tr("Sell on Kwenzo. Get orders, not calls.")}</h1><p className="nv-lead">{tr("List your stock, set your prices and receive orders from builders and homeowners near your store.")}</p>
    <ul className="nv-ticks"><li><Icon n="check" size={18} />{tr("Reach contractors in your area")}</li><li><Icon n="check" size={18} />{tr("Set your own prices and bulk rates")}</li><li><Icon n="check" size={18} />{tr("Orders and payments on one dashboard")}</li></ul></div>
    <Form className="nv-form card" onSubmit={e => { e.preventDefault(); if (f.shop.trim().length < 2 || f.name.trim().length < 2 || !/^[6-9]\d{9}$/.test(f.phone)) { setErr('Add your shop name, your name and a valid mobile number.'); return; } onApply({ shop: f.shop.trim(), owner: f.name.trim(), city: f.city, phone: f.phone, gst: f.gst }); setOk(true); }}>
      <Field l={tr("Shop name")}><input value={f.shop} onChange={e => setF({ ...f, shop: e.target.value })} /></Field>
      <Field l={tr("Your name")}><input value={f.name} onChange={e => setF({ ...f, name: e.target.value })} /></Field>
      <Field l={tr("Mobile number")}><input value={f.phone} inputMode="numeric" maxLength={10} onChange={e => setF({ ...f, phone: e.target.value.replace(/\D/g, '') })} /></Field>
      <Field l={tr("City")}><input value="Hyderabad" readOnly /></Field>
      <Field l={tr("GSTIN (optional)")}><input value={f.gst} maxLength={15} onChange={e => setF({ ...f, gst: e.target.value.toUpperCase() })} /></Field>
      {tr(err && <div className="nv-err">{tr(err)}</div>)}<button className="nv-btn big wide">{tr("Apply to sell")}</button></Form></main>;
}

function Form({ onSubmit, className, children }: { onSubmit: (e: any) => void; className?: string; children: React.ReactNode }) {
  const fire = () => onSubmit({ preventDefault() {} });
  return <div className={className} role="form" onKeyDown={e => { if (e.key === 'Enter' && (e.target as HTMLElement).tagName === 'INPUT') { e.preventDefault(); fire(); } }} onClick={e => { const b = (e.target as HTMLElement).closest('button'); if (b && (b as HTMLButtonElement).type === 'submit') { e.preventDefault(); fire(); } }}>{tr(children)}</div>;
}


function Gallery({ imgs, alt }: { imgs: string[]; alt: string }) {
  const [i, setI] = useState(0);
  const ref = React.useRef<HTMLDivElement>(null);
  const go = (n: number) => { setI(n); const el = ref.current; if (el) el.scrollTo({ left: n * el.clientWidth, behavior: 'smooth' }); };
  return <div className="ms-gal">
    <div className="ms-gal-main" ref={ref} onScroll={e => { const el = e.currentTarget; const n = Math.round(el.scrollLeft / el.clientWidth); if (n !== i) setI(n); }}>{tr(imgs.map((src, k) => <div className="ms-gal-slide" key={k}><img src={src} alt={tr(alt + ' image ' + (k + 1))} /></div>))}</div>
    <div className="ms-gal-count">{tr(i + 1)} / {tr(imgs.length)}</div>
    <div className="ms-gal-thumbs">{tr(imgs.map((src, k) => <button key={k} className={k === i ? 'on' : ''} onClick={() => go(k)} aria-label={tr('Image ' + (k + 1))}><img src={src} alt={tr("")} /></button>))}</div>
  </div>;
}

function MobileShop({ code, openSku, closeSku, goHome, q, cat, setCat, cart, addSku }: { code: string; openSku: (c: string) => void; closeSku: () => void; goHome: () => void; q: string; cat: string; setCat: (c: string) => void; cart: Line[]; addSku: (c: string, d: number) => void }) {
  const qtyOf = (c: string) => cart.find(l => l.pid === 'sku:' + c)?.qty || 0;
  const priceTxt = (c: string) => { if (!SHOW_PRICES) return ''; const p = SKUP[c]; return p ? (p[1] > p[0] ? 'From ' : '') + inr(p[0]) : ''; };
  const ctl = (c: string) => { const n = qtyOf(c); return n === 0 ? <button className="ms-add" onClick={e => { e.stopPropagation(); addSku(c, 1); }}>{tr("Add")}</button> : <span className="ms-qty" onClick={e => e.stopPropagation()}><button onClick={() => addSku(c, -1)} aria-label={tr("Decrease")}>-</button><b>{tr(n)}</b><button onClick={() => addSku(c, 1)} aria-label={tr("Increase")}>+</button></span>; };
  const open: Sku | null = code ? SKUS.find(x => x.c === (ALIAS[code] || code)) || null : null;
  const [vc, setVc] = useState(code);
  useEffect(() => setVc(code), [code]);
  const fam: Fam | undefined = open ? FAM[open.c] : undefined;
  const curV = fam ? (fam.v.find(v => v[0] === vc) || fam.v[0]) : null;
  const cur = curV ? curV[0] : open ? open.c : '';
  const pickOpt = (k: number, val: string) => { if (!fam || !curV) return; let best = fam.v[0], bs = -1; fam.v.forEach(v => { if (v[3][k] !== val) return; const sc = v[3].reduce((s, x, j) => s + (j !== k && x === curV[3][j] ? 1 : 0), 0); if (sc > bs) { bs = sc; best = v; } }); setVc(best[0]); };
  const setOpen = (x: Sku | null) => { if (x) openSku(x.c); else closeSku(); };
  const [lim, setLim] = useState(40);
  useEffect(() => setLim(40), [q, cat]);
  const needle = q.trim().toLowerCase();
  const list = SKUS.filter(x => !HIDDEN.has(x.c) && (cat === 'all' || x.t === cat) && (!needle || (x.n + ' ' + x.b + ' ' + x.g).toLowerCase().includes(needle)));
  const title = cat === 'all' ? 'All materials' : MCATS.find(m => m.id === cat)?.name || 'All materials';
  useEffect(() => { window.scrollTo(0, 0); }, [open]);
  if (open) {
    const rel = SKUS.filter(x => !HIDDEN.has(x.c) && x.t === open.t && x.c !== open.c && x.i).slice(0, 8);
    const catName = MCATS.find(m => m.id === open.t)?.name || '';
    const hc = fam && fam.m && HRDATA[cur] ? cur : open.c;
    const sized = open.s && !/^Single size/i.test(open.s);
    const colr = open.col && !/^Not specified/i.test(open.col);
    return <main className="ms ms-page">
      <nav className="ms-crumb" aria-label={tr("Breadcrumb")}><button onClick={goHome}>{tr("Home")}</button><i>{tr("›")}</i><button onClick={() => setOpen(null)}>{tr(catName || 'Products')}</button><i>{tr("›")}</i><span>{tr(fam && fam.m ? SKUN[cur].n : open.n)}</span></nav>
      <div className="ms-pg">
        {tr((SKU_GALLERY[open.c] || (HR_IMG[open.c] && HR_IMG[open.c].length > 1 && HR_IMG[open.c])) ? <Gallery key={open.c + cur} imgs={(SKU_GALLERY[open.c] || (fam && fam.m && HR_IMG[cur]) || HR_IMG[open.c]) as string[]} alt={tr(open.n)} /> : <div className="ms-pg-img">{tr(open.i ? <img src={skuImg(open.c)} alt={tr(open.n)} /> : <Icon n="bag" size={64} />)}</div>)}
        <div className="ms-pg-info">
          <div className="ms-badges"><span className="ms-badge g"><Icon n="truck" size={15} />{tr(" Free Delivery ")}<em>{tr("on orders above ")}{tr(inr(5000))}</em></span><span className="ms-badge"><Icon n="shield" size={15} />{tr(" Pay on Delivery")}</span></div>
          <small>{tr(open.b)}</small><h1>{tr(fam && fam.m ? SKUN[cur].n : open.n)}</h1>
          <span className="ms-code">{tr(catName)}{tr(" · SKU ")}{tr(cur)}</span>
          {tr(fam && curV && <div className="ms-vars">{tr(fam.o.map((on, k) => { const vals = Array.from(new Set(fam.v.map(v => v[3][k]))); return <div className="ms-var" key={on}><b>{tr(on)}: <em>{tr(curV[3][k])}</em></b><div className="ms-var-c">{tr(vals.map(val => <button key={val} className={val === curV[3][k] ? 'on' : ''} onClick={() => pickOpt(k, val)}>{tr(val)}</button>))}</div></div>; }))}</div>)}
          <div className="ms-priceblk"><strong>{tr(curV ? (SHOW_PRICES ? inr(curV[2]) : '') : priceTxt(open.c))}</strong>{tr(!fam && SKUP[open.c] && SKUP[open.c][1] > SKUP[open.c][0] && <span className="ms-from">{tr("Starting price, varies by size")}</span>)}<p>{tr("Incl GST. Delivery charges calculated at checkout.")}</p></div>
          {tr(qtyOf(cur) === 0 ? <button className="ms-bigadd" onClick={() => addSku(cur, 1)}>{tr("Add to Cart")}</button> : <div className="ms-bigqty"><button onClick={() => addSku(cur, -1)} aria-label={tr("Decrease")}>-</button><b>{tr(qtyOf(cur))}{tr(" in cart")}</b><button onClick={() => addSku(cur, 1)} aria-label={tr("Increase")}>+</button></div>)}
          {tr(SKU_HIGHLIGHTS[open.c] && <details className="ms-acc ms-hl"><summary>{tr("Product highlights")}</summary><div className="ms-acc-b">{tr(SKU_HIGHLIGHTS[open.c].q && <p className="ms-hl-q"><b>{tr("Quick Answer:")}</b> {tr(SKU_HIGHLIGHTS[open.c].q)}</p>)}{tr(SKU_HIGHLIGHTS[open.c].a && <p className="ms-hl-a">{tr(SKU_HIGHLIGHTS[open.c].a)}</p>)}<ul>{tr(SKU_HIGHLIGHTS[open.c].rows.map(([k, v]) => <li key={k}><b>{tr(k)}:</b> {tr(v)}</li>))}</ul></div></details>)}
          <details className="ms-acc ms-hl"><summary>{tr("Product details")}</summary><div className="ms-acc-b"><dl>{tr(sized && <><dt>{tr("Size")}</dt><dd>{tr(open.s)}</dd></>)}{tr(colr && <><dt>{tr("Colour")}</dt><dd>{tr(open.col)}</dd></>)}{tr(open.d && <><dt>{tr("About")}</dt><dd>{tr(open.d)}</dd></>)}{tr(open.w && <><dt>{tr("Used for")}</dt><dd>{tr(open.w)}</dd></>)}<dt>{tr("Brand")}</dt><dd>{tr(open.b)}</dd><dt>{tr("Category")}</dt><dd>{tr(catName)}</dd></dl></div></details>
      {tr(SKU_DOC[open.c] && <details className="ms-acc ms-desc"><summary>{tr("Product description")}</summary><div className="ms-acc-b">{tr(SKU_DOC[open.c].map((b, n) => <div key={n}>{tr(b.h && <h3>{tr(b.h)}</h3>)}{tr(b.sub && <h4>{tr(b.sub)}</h4>)}{tr(b.p && b.p.map((t, k) => <p key={k}>{tr(t)}</p>))}{tr(b.table && <table><thead><tr>{tr(b.table[0].map(c => <th key={c}>{tr(c)}</th>))}</tr></thead><tbody>{tr(b.table.slice(1).map(r => <tr key={r[0]}>{tr(r.map((c, k) => <td key={k}>{tr(c)}</td>))}</tr>))}</tbody></table>)}{tr(b.list && <ul>{tr(b.list.map(([k, v]) => <li key={k}><b>{tr(k)}:</b> {tr(v)}</li>))}</ul>)}{tr(b.ol && <ol>{tr(b.ol.map(([k, v]) => <li key={k}><b>{tr(k)}:</b> {tr(v)}</li>))}</ol>)}</div>))}</div></details>)}
      {tr(!SKU_DOC[open.c] && SKU_DESC[open.c] && (() => { const d = SKU_DESC[open.c]; return <details className="ms-acc ms-desc"><summary>{tr("Product description")}</summary><div className="ms-acc-b">{tr(d.p.map((t, k) => <p key={k}>{tr(t)}</p>))}
        <h3>{tr("Technical Specifications")}</h3><table><thead><tr><th>{tr("Specification")}</th><th>{tr("Details")}</th></tr></thead><tbody>{tr(d.specs.map(([k, v]) => <tr key={k}><td>{tr(k)}</td><td>{tr(v)}</td></tr>))}</tbody></table>
        <h3>{tr("Recommended Applications")}</h3><ul>{tr(d.apps.map(([k, v]) => <li key={k}><b>{tr(k)}:</b> {tr(v)}</li>))}</ul>
        <h3>{tr("Installation Guidelines")}</h3><ol>{tr(d.steps.map(([k, v]) => <li key={k}><b>{tr(k)}:</b> {tr(v)}</li>))}</ol></div></details>; })())}
      {tr(!SKU_HIGHLIGHTS[open.c] && HRDATA[hc] && HRDATA[hc].hl.length > 0 && <details className="ms-acc ms-hl"><summary>{tr("Product highlights")}</summary><div className="ms-acc-b"><Blocks b={HRDATA[hc].hl} /></div></details>)}
      {tr(!SKU_DOC[open.c] && !SKU_DESC[open.c] && HRDATA[hc] && HRDATA[hc].ds.length > 0 && <details className="ms-acc ms-desc"><summary>{tr("Product description")}</summary><div className="ms-acc-b"><Blocks b={HRDATA[hc].ds} /></div></details>)}
      {tr(SKU_RETURNS[open.c] && (() => { const r = SKU_RETURNS[open.c]; return <details className="ms-acc ms-desc ms-ret"><summary>{tr("Returns & Exchange Policy")}</summary><div className="ms-acc-b"><p><b>{tr(r.lead)}</b></p><p>{tr(r.intro)}</p><ul>{tr(r.items.map(t => <li key={t}>{tr(t)}</li>))}</ul><p className="ms-ret-f">{tr(r.foot)}</p></div></details>; })())}
      {tr(!SKU_RETURNS[open.c] && HRDATA[hc] && HRDATA[hc].rt.length > 0 && <details className="ms-acc ms-desc ms-ret"><summary>{tr("Returns & Exchange Policy")}</summary><div className="ms-acc-b"><Blocks b={HRDATA[hc].rt} /></div></details>)}
        </div>
      </div>
      {tr(rel.length > 0 && <><h2 className="ms-rel-h">{tr("More in ")}{tr(catName)}</h2><div className="ms-grid">{tr(rel.map(x => <div key={x.c} className="ms-card" role="button" tabIndex={0} onClick={() => setOpen(x)}><span className="ms-img"><img src={skuImg(x.c)} alt={tr("")} loading="lazy" /></span><small>{tr(x.b)}</small><b>{tr(x.n)}</b><div className="ms-buy"><strong>{tr(priceTxt(x.c))}</strong>{tr(ctl(x.c))}</div></div>))}</div></>)}
    </main>;
  }
  return <main className="ms">
    <div className="ms-h"><h1>{tr(title)}</h1><p>{tr(list.length)}{tr(" products")}</p></div>
    <div className="ms-chips">{tr([{ id: 'all', name: 'All' }, ...MCATS].map(c => <button key={c.id} className={cat === c.id ? 'on' : ''} onClick={() => setCat(c.id)}>{tr(c.name)}</button>))}</div>
    {tr(list.length === 0 ? <div className="nv-empty"><h3>{tr("Nothing matches that")}</h3><p>{tr("Try a different word or pick a category.")}</p></div> : <div className="ms-grid">{tr(list.slice(0, lim).map(x => <div key={x.c} className="ms-card" role="button" tabIndex={0} onClick={() => setOpen(x)}><span className="ms-img">{tr(x.i ? <img src={skuImg(x.c)} alt={tr("")} loading="lazy" /> : <Icon n="bag" size={28} />)}</span><small>{tr(x.b)}</small><b>{tr(x.n)}</b>{tr(x.s && !/^Single size/i.test(x.s) && <em>{tr(x.s)}</em>)}<div className="ms-buy"><strong>{tr(priceTxt(x.c))}</strong>{tr(ctl(x.c))}</div></div>))}</div>)}
    {tr(list.length > lim && <button className="nv-btn ms-more" onClick={() => setLim(lim + 40)}>{tr("Show more")}</button>)}
  </main>;
}
