export type Pol = { t: string; b: string[] };
export const CORE_TERMS = [
  'All information and documents submitted are accurate and genuine.',
  'All products supplied through Kwenzo shall be genuine, new, legally sourced and compliant with applicable standards.',
  'Vendor shall maintain accurate inventory and pricing information.',
  'Vendor shall accept/reject orders within the prescribed SLA.',
  'Vendor shall not cancel accepted orders except for legitimate reasons communicated to Kwenzo.',
  'Vendor shall supply exactly the product, quantity, specification and brand ordered.',
  'Product substitution requires prior approval.',
  'Vendor shall provide proper invoices and applicable tax documentation.',
  'Vendor shall comply with applicable GST, tax, consumer protection and other laws.',
  'Vendor shall be responsible for defects, shortages, counterfeit products and other issues attributable to the Vendor.',
  "Vendor shall comply with Kwenzo's quality, packaging, fulfilment and return policies.",
  'Vendor shall not misuse customer information.',
  'Vendor shall not knowingly bypass Kwenzo to transact directly with customers introduced through the platform for the purpose of avoiding applicable Kwenzo charges.',
  'Kwenzo may suspend or deactivate vendors/SKUs for repeated SLA, quality, compliance or conduct violations.',
  'Kwenzo may recover applicable penalties, refunds, replacement costs and other contractually agreed amounts arising from Vendor-caused failures.',
  "Vendor shall maintain confidentiality of Kwenzo's commercial and customer information.",
  'Either party may terminate the relationship subject to the agreed termination provisions.',
  'All disputes shall be handled according to the dispute-resolution mechanism specified in the Vendor Agreement.',
  "The Vendor agrees to Kwenzo's applicable policies, SOPs and SLAs as amended from time to time in accordance with the Agreement.",
  'Registration and acceptance of orders constitutes acceptance of the applicable operational terms.',
];
export const DECLARATION = "I/We confirm that all information and documents submitted to Kwenzo are true, accurate and complete. I/We agree to comply with Kwenzo's Vendor Terms, Service Level Agreements, quality standards, pricing policies, fulfilment requirements and applicable laws.";
export const FOUR_DOCS: [string, string, string][] = [
  ['Vendor Registration Form', 'Basic information, KYC and bank details.', 'Completed in the application.'],
  ['Vendor Catalogue Template', 'SKU, brand, HSN, GST, price, MRP, inventory, dimensions, weight and images.', 'Completed after approval.'],
  ['Kwenzo Vendor Agreement', 'Commercial terms, SLA, quality, payments, returns, liability, confidentiality, termination and dispute resolution.', 'Signed after approval.'],
  ['Kwenzo Vendor SOP', 'How to receive an order, accept, pack, keep ready, hand over, handle cancellation, handle return and resolve a complaint.', 'Accepted with the agreement.'],
];
export const JOURNEY = ['Vendor applies', 'KYC verification', 'Commercial approval', 'Catalogue onboarding', 'Pricing setup', 'Logistics setup', 'SLA acceptance', 'Agreement signed', 'Test order', 'Vendor goes LIVE'];
export const POLICIES: Pol[] = [
  { t: 'Vendor pricing structure', b: ['Vendor Price: the price at which the vendor sells the product to Kwenzo/customer through Kwenzo.', 'MRP: Maximum Retail Price, where applicable.', 'Kwenzo Margin / Commission: Kwenzo earns by percentage commission, fixed margin, price spread or category-specific commission, as defined for the vendor.', 'The agreement defines whether GST is included or excluded, whether transportation is included, whether loading/unloading is included, whether packaging charges are included and whether any additional charges are allowed.'] },
  { t: 'Price change policy', b: ['Vendors shall not change the approved selling price of any SKU without providing Kwenzo with prior written notice of at least 7 days. Kwenzo reserves the right to approve, reject or temporarily deactivate the affected SKU.', 'For volatile categories (cement, steel, plywood, hardware, electrical products and certain commodity-linked materials) a daily / weekly price update mechanism applies instead of the 7-day lock.'] },
  { t: 'Inventory management', b: ['Vendor provides SKU availability, available quantity, warehouse location, lead time, minimum order quantity and restocking frequency.', 'If the vendor accepts an order but subsequently informs Kwenzo that the product is unavailable, this counts as a stock-out/cancellation attributable to the vendor.', 'Repeated stock-outs lead to: 1. Warning, 2. Reduced visibility, 3. Temporary SKU suspension, 4. Vendor suspension, 5. Termination.'] },
  { t: 'Order acceptance SLA', b: ['Vendor must accept or reject an order within 10 minutes of receiving the order.', 'Once accepted, the vendor must keep the product ready for pickup within the agreed preparation time.', 'Order flow: Order received, Vendor confirmation, Material ready, Kwenzo rider pickup, Customer delivery.'] },
  { t: 'Delivery and logistics terms', b: ['Vendor responsibility: correct product, correct quantity, proper packaging, product readiness, loading assistance where agreed, invoice and product documentation.', 'Kwenzo responsibility: pickup coordination, transportation, customer communication, delivery tracking and proof of delivery.', 'Defined for every vendor: pickup SLA, loading time, delivery radius, waiting time, loading/unloading responsibility, damaged goods responsibility and failed delivery responsibility.'] },
  { t: 'Loading and unloading', b: ['Unless otherwise agreed for a particular category/order, the vendor is responsible for safely packing and making the material available for pickup. Responsibility for transportation passes to Kwenzo/logistics partner at handover.', 'Who unloads at site is specified separately. Kwenzo delivery does not mean automatic site unloading.'] },
  { t: 'Quality control', b: ['Vendor guarantees: genuine products, new products, no counterfeit products, no used products, no damaged products, correct specifications, correct quantity, proper packaging, valid warranty and applicable certification.', 'The Vendor shall be solely responsible for ensuring that all products supplied through Kwenzo are genuine, legally sourced, compliant with applicable laws and meet the specifications represented on the Kwenzo platform.'] },
  { t: 'Counterfeit and fraud policy', b: ['Vendor must not: sell counterfeit goods, misrepresent brands, substitute products without approval, upload fake certifications, manipulate inventory, manipulate invoices, sell stolen goods, or supply used/refurbished goods as new.', 'Serious violations lead to immediate suspension, investigation, potential termination and recovery of losses.'] },
  { t: 'Product substitution', b: ['Vendor shall not substitute an ordered product with another brand, specification, size, colour, model or quality level without obtaining prior approval from Kwenzo/customer, even if the vendor considers it equivalent.'] },
  { t: 'Returns and replacements', b: ['Category A, Vendor fault: wrong product, damaged product, defective product, missing quantity, incorrect specification, counterfeit product. Vendor bears the cost.', "Category B, Customer change of mind: return depends on product category and Kwenzo's return policy.", 'Category C, Non-returnable products: certain custom-cut materials, made-to-order products, special-order items, opened/sealed products and customised products. These are identified during catalogue onboarding.'] },
  { t: 'Damage policy, proof of pickup and proof of delivery', b: ['At pickup, responsibility moves from Vendor to Kwenzo logistics. At delivery, from Kwenzo logistics to Customer. Responsibility at each stage is defined.', 'Proof of Pickup: photo + quantity + condition.', 'Proof of Delivery: customer OTP + photo + timestamp, used for dispute resolution.'] },
  { t: 'Customer complaints', b: ['Vendor must respond to quality-related complaints within a defined SLA: Critical complaint 2 hours, Normal complaint 24 hours, Replacement requirement 24 to 48 hours depending on category.', 'Universal timelines are not promised until category economics are known.'] },
  { t: 'Payment terms', b: ['Model 1, Prepaid Vendor Settlement: customer pays Kwenzo; Kwenzo settles the vendor after successful delivery (Order, Delivery, POD, Settlement).', 'Model 2, Credit Vendor: vendor gives Kwenzo credit of 7 / 15 / 30 days.', 'Model 3, COD / Collection: defines who collects money, when settlement is made, who bears payment gateway charges and who bears COD risk.'] },
  { t: 'Vendor settlement', b: ['Settlement cycle is one of: T+1, T+3, Weekly, Biweekly. For early-stage Kwenzo: T+2/T+3 after successful delivery, subject to returns/disputes, negotiated category-wise.'] },
  { t: 'Taxes and invoicing', b: ['Vendor must: provide a valid tax invoice, mention the correct GSTIN, mention the correct HSN, charge applicable GST, provide required tax documentation, comply with GST laws and correct invoice errors within the defined time.', 'Invoice issuance: Vendor invoice + Kwenzo platform invoice, depending on the final legal/tax structure, to be finalized with a CA/tax lawyer (marketplace, principal-to-principal and commission-agent structures differ for GST/accounting).'] },
  { t: 'Vendor commission / platform fee', b: ['Kwenzo is entitled to charge the Vendor a platform/commission fee as mutually agreed between the parties.', 'Specified per vendor as: Category, Commission, GST, Other charges. Rates are set category-wise at commercial approval.'] },
  { t: 'Marketing and visibility', b: ['Kwenzo may feature vendor products, run promotions, create bundles, offer discounts, display the vendor name, use product images and descriptions, and run sponsored listings.', 'Promotional discounts are Option A Vendor-funded, Option B Kwenzo-funded or Option C Shared, as agreed.'] },
  { t: 'Vendor performance score', b: ['Availability 20%, Order acceptance 15%, On-time readiness 20%, Quality 20%, Cancellation rate 10%, Customer complaints 10%, Documentation 5%.', 'Green: 90+. Yellow: 75 to 89. Red: below 75. The score can determine vendor ranking inside Kwenzo.'] },
  { t: 'Vendor penalties', b: ['Vendor cancellation: fixed fee or percentage of order value.', 'Wrong product: replacement + logistics cost + applicable penalty.', 'Damaged product: replacement/refund + associated costs.', 'Repeated stock-out: SKU suspension.', 'Late readiness: applicable service-level penalty.', 'Fraud/counterfeit: immediate suspension/termination + recovery of losses.', 'Exact amounts are commercially negotiated and legally reviewed.'] },
  { t: 'Data and confidentiality', b: ['Vendor must not: contact Kwenzo customers directly for unrelated sales, misuse customer information, share customer phone numbers, use Kwenzo order information outside the transaction, sell customer data, or share confidential Kwenzo pricing/business information.'] },
  { t: 'Anti-bypass / non-circumvention', b: ["Vendor shall not knowingly circumvent, bypass or divert customers introduced through Kwenzo for the purpose of avoiding Kwenzo's applicable fees or commercial terms."] },
  { t: 'Vendor cannot contact customer for marketing', b: ['Vendor can communicate with a customer only when necessary for fulfilling the order. No WhatsApp marketing, promotional calls, independent sales pitches, customer database creation or unauthorised remarketing.'] },
  { t: 'Intellectual property', b: ['Vendor gives Kwenzo permission to use product images, product names, product descriptions, brand information and logos (where authorized) solely for operating and marketing the Kwenzo platform.', 'Vendor confirms it has the right to provide this material.'] },
  { t: 'Confidentiality (both parties)', b: ['Both parties keep confidential: pricing, commission structure, customer data, vendor data, sales data, business strategy, technology, analytics and commercial agreements.'] },
  { t: 'Indemnity', b: ["Vendor indemnifies Kwenzo against losses arising from: counterfeit products, product defects attributable to vendor, vendor's legal violations, IP infringement, incorrect certifications, tax non-compliance attributable to vendor, fraud, misrepresentation and third-party claims caused by vendor's product/supply."] },
  { t: 'Insurance', b: ['For higher-risk/high-value categories: product liability insurance, commercial insurance and other category-specific insurance may be required. Not imposed on every small vendor from day one.'] },
  { t: 'Suspension', b: ['Kwenzo may temporarily suspend a vendor for: high cancellation rate, repeated customer complaints, quality issues, fake products, documentation problems, payment disputes, fraud, regulatory issues and SLA violations.'] },
  { t: 'Termination', b: ['Either party may terminate the relationship with appropriate notice.', 'Immediate termination for: fraud, counterfeit products, serious misconduct, illegal activity, data theft, deliberate customer bypass, material breach and repeated serious SLA violations.', 'Treatment of pending orders and outstanding payments after termination is defined in the agreement.'] },
  { t: 'Force majeure', b: ['Events outside reasonable control: natural disasters, government restrictions, war, major strikes, certain transport disruptions and other qualifying events. Ordinary inventory shortages do not automatically qualify.'] },
  { t: 'Dispute resolution', b: ['1. Good-faith discussion. 2. Escalation to management. 3. Mediation, if desired. 4. Arbitration / courts.', 'Governing law and jurisdiction are specified after Indian legal advice.'] },
  { t: 'Changes to terms', b: ['Kwenzo may update operational policies with reasonable notice. Material commercial changes such as commission, payment terms or liability follow an appropriate contractual process rather than unilateral surprise changes.'] },
];
export const SLAS = [
  'Accept or reject every order within 10 minutes of receiving it.',
  'Keep accepted material ready for pickup within the agreed preparation time.',
  'Stock-out after acceptance counts as a vendor-attributable cancellation (warning, reduced visibility, SKU suspension, vendor suspension, termination).',
  'Respond to critical quality complaints within 2 hours and normal complaints within 24 hours; replacement within 24 to 48 hours depending on category.',
  'Provide Proof of Pickup (photo + quantity + condition) at every handover.',
  'Supply exactly the product, brand, specification, size, colour and quantity ordered. No substitution without approval.',
  'Issue a valid GST tax invoice with correct GSTIN and HSN with every order.',
  'Settlement is made after successful delivery and POD, subject to returns and disputes, on the agreed cycle.',
];
export const KPIS: [string, string][] = [['Order Acceptance', '>95%'], ['Stock Accuracy', '>95%'], ['On-Time Readiness', '>95%'], ['Cancellation', '<3%'], ['Wrong Item Rate', '<1%'], ['Damage Rate', '<1%'], ['Customer Complaints', '<2%'], ['Invoice Accuracy', '>98%']];
export const TIERS = ['A+ Vendor', 'A Vendor', 'B Vendor', 'C Vendor', 'Suspended'];
export const SCORE_WEIGHTS: [string, string][] = [['Availability', '20%'], ['Order acceptance', '15%'], ['On-time readiness', '20%'], ['Quality', '20%'], ['Cancellation rate', '10%'], ['Customer complaints', '10%'], ['Documentation', '5%']];
export const VCATS = ['Cement & Plaster', 'Tiling & Grouts', 'Paints & Putty', 'Plywood & MDF', 'Fevicol & Adhesives', 'Electricals & Lights', 'Bath Fittings & Sanitary', 'Furniture Fittings', 'Locks & Handles', 'Hardware & Tools', 'Plumbing Pipes & Fittings', 'Waterproofing & Repairs', 'Safety & Protection'];
export const KYC: Record<string, string[]> = {
  'Individual / Proprietorship': ['PAN Card', 'Aadhaar / ID proof of proprietor', 'GST Certificate', 'Shop & Establishment / Trade Licence (wherever applicable)', 'Cancelled cheque / bank proof', 'Business address proof'],
  'Partnership': ['Partnership Deed', 'PAN', 'GST Certificate', 'Partner KYC', 'Bank details', 'Business address proof'],
  'LLP / Private Limited': ['Certificate of Incorporation', 'PAN', 'GST Certificate', 'MOA/AOA (where applicable)', 'Authorised signatory proof', 'Board resolution / authorization (if required)', 'Bank details'],
};
export const PRODDOCS: Record<string, string[]> = {
  'Cement & Plaster': ['BIS certification', 'Test certificates'],
  'Plywood & MDF': ['BIS certification', 'ISI certification', 'Test certificates'],
  'Electricals & Lights': ['BIS certification', 'ISI certification', 'Product warranty documents', 'Safety certificates'],
  'Plumbing Pipes & Fittings': ['ISI certification', 'Test certificates'],
  'Safety & Protection': ['ISI certification', 'Safety certificates'],
  'Paints & Putty': ['Manufacturer authorization', 'Test certificates'],
  'Fevicol & Adhesives': ['Manufacturer authorization', 'Test certificates'],
  'Waterproofing & Repairs': ['Manufacturer authorization', 'Test certificates'],
  'Tiling & Grouts': ['Manufacturer authorization', 'Product warranty documents'],
  'Bath Fittings & Sanitary': ['Manufacturer authorization', 'Product warranty documents'],
  'Locks & Handles': ['Manufacturer authorization', 'Product warranty documents'],
  'Hardware & Tools': ['Manufacturer authorization', 'Product warranty documents'],
  'Furniture Fittings': ['Manufacturer authorization', 'Product warranty documents'],
};
