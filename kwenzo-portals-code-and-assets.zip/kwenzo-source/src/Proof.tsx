import { tr } from './i18n';
import React, { useState } from 'react';

export function shrink(file: File, max = 900): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onerror = () => rej(new Error('read'));
    r.onload = () => { const img = new Image(); img.onerror = () => rej(new Error('img')); img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height); res(c.toDataURL('image/jpeg', 0.6)); }; img.src = r.result as string; };
    r.readAsDataURL(file);
  });
}
export function ProofShot({ label, value, onChange, locked }: { label: string; value?: string; onChange: (v: string) => void; locked?: boolean }) {
  const [err, setErr] = useState('');
  const pick = async (e: React.ChangeEvent<HTMLInputElement>) => { const f = e.target.files?.[0]; if (!f) return; if (!f.type.startsWith('image/')) { setErr('Choose a photo.'); return; } try { onChange(await shrink(f)); setErr(''); } catch (x) { setErr('Could not read that photo. Try again.'); } };
  return <div className="pf-box"><span className="pf-l">{tr(label)}</span>
    {tr(value ? <img className="pf-img" src={value} alt={tr(label)} /> : <div className="pf-empty">{tr("No photo added")}</div>)}
    {tr(!locked && <label className="nv-btn ghost pf-btn">{tr(value ? 'Retake photo' : 'Take or upload photo')}<input type="file" accept="image/*" capture="environment" onChange={pick} /></label>)}
    {tr(err && <em className="pf-err">{tr(err)}</em>)}</div>;
}
