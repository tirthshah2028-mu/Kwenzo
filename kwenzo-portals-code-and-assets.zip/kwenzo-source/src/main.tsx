import React from 'react';
import { createRoot } from 'react-dom/client';
import { FileRouter } from '@instinct/files';
import { LanguageProvider } from './i18n';
import { App } from './App';

createRoot(document.getElementById('root')!).render(<FileRouter><LanguageProvider><App /></LanguageProvider></FileRouter>);
