import { tr, useLanguage } from './i18n';
import React, { useState } from 'react';
import { inr, isServiceable, COMING_SOON, type Order } from './data';
import { TermsView, DECL } from './Terms';

export type Site = { addr: string; building: string; unit: string; landmark: string; pin: string; contact: string; phone: string; hours: string; vehicles: string[]; parking: string; lift: string; floor: string; unloading: string; notes: string };
export type Cust = {
  mobile: string; name: string; email: string; user: string; pass: string; type: string; pin: string; since: number; whatsapp: string; gstin: string; pan: string;
  biz?: { company: string; contact: string; designation: string; btype: string; gstin: string; pan: string; regAddr: string; billAddr: string; email: string; phone: string };
  project?: Record<string, string>; site?: Site; bill?: { name: string; gstin: string; pan: string; addr: string };
  prefs?: { freq: string; buys: string[]; value: string }; credit?: { status: 'submitted' | 'approved' | 'declined'; at: number; data: Record<string, string> }; agreed?: boolean;
};
const MOB = /^[6-9]\d{9}$/; const PAN = /^[A-Z]{5}\d{4}[A-Z]$/; const GST = /^\d{2}[A-Z]{5}\d{4}[A-Z][A-Z\d]Z[A-Z\d]$/;
export const TYPES = ['Homeowner', 'Contractor', 'Interior designer', 'Architect', 'Builder/developer', 'Other'];
const PTYPES = ['New construction', 'Renovation', 'Interior', 'Commercial', 'Residential', 'Office', 'Retail', 'Hospitality'];
const STAGES = ['Planning', 'Civil', 'Electrical', 'Plumbing', 'Flooring', 'Painting', 'Furniture/interiors', 'Finishing'];
const FREQ = ['Daily', 'Multiple times a week', 'Weekly', 'Monthly', 'Occasionally'];
const BUYS = ['Plumbing', 'Electrical', 'Hardware', 'Paint', 'Cement', 'Steel', 'Plywood', 'Tiles', 'Sanitaryware', 'Tools', 'Other'];
const VALS = ['<₹5,000', '₹5,000–₹25,000', '₹25,000–₹1 lakh', '₹1–5 lakh', '₹5 lakh+'];
const BTYPES = ['Proprietorship', 'Partnership', 'LLP', 'Private Limited', 'Public Limited', 'Other'];
const VEH = ['Truck', 'Mini-truck', 'Tempo', 'Two-wheeler'];
const STAT: Record<string, string> = { placed: 'Order confirmed', accepted: 'Dealer is packing', packed: 'Dealer is packing', dispatched: 'Out for delivery', delivered: 'Delivered', cancelled: 'Cancelled' };
const fdate = (t: number) => new Date(t).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
export const emptySite = (c?: Partial<Cust>): Site => ({ addr: '', building: '', unit: '', landmark: '', pin: c?.pin || '', contact: c?.name || '', phone: c?.mobile || '', hours: '', vehicles: [], parking: '', lift: '', floor: '', unloading: '', notes: '' });

type Set = (k: string, v: any) => void;
function Form({ onSubmit, className, children }: { onSubmit: (e: any) => void; className?: string; children: React.ReactNode }) {
  const fire = () => onSubmit({ preventDefault() {} });
  return <div className={className} role="form" onKeyDown={e => { if (e.key === 'Enter' && (e.target as HTMLElement).tagName === 'INPUT') { e.preventDefault(); fire(); } }} onClick={e => { const b = (e.target as HTMLElement).closest('button'); if (b && ((b as HTMLButtonElement).type === 'submit' || !b.getAttribute('type'))) { if (b.closest('.ac-tabs,.ac-cats,.ac-nudge')) return; e.preventDefault(); fire(); } }}>{tr(children)}</div>;
}
export function F({ l, e, children }: { l: string; e?: string; children: React.ReactNode }) { return <label className={'nv-f' + (e ? ' bad' : '')}><span>{tr(l)}</span>{tr(children)}{tr(e && <em>{tr(e)}</em>)}</label>; }
const Tx = ({ l, k, f, s, e, ph, type = 'text', ta, mode }: { l: string; k: string; f: any; s: Set; e?: Record<string, string>; ph?: string; type?: string; ta?: boolean; mode?: any }) => <F l={tr(l)} e={e?.[k]}>{tr(ta ? <textarea rows={2} value={f[k] || ''} onChange={x => s(k, x.target.value)} placeholder={tr(ph)} /> : <input type={type} inputMode={mode} value={f[k] || ''} onChange={x => s(k, x.target.value)} placeholder={tr(ph)} />)}</F>;
const Sl = ({ l, k, f, s, o, e }: { l: string; k: string; f: any; s: Set; o: string[]; e?: Record<string, string> }) => <F l={tr(l)} e={e?.[k]}><select value={f[k] || ''} onChange={x => s(k, x.target.value)}><option value="">{tr("Select")}</option>{tr(o.map(x => <option key={x} value={x}>{tr(x)}</option>))}</select></F>;
const Ck = ({ l, k, f, s, o }: { l: string; k: string; f: any; s: Set; o: string[] }) => <div className="ac-ck"><span>{tr(l)}</span><div>{tr(o.map(x => <label key={x}><input type="checkbox" checked={(f[k] || []).includes(x)} onChange={e => s(k, e.target.checked ? [...(f[k] || []), x] : (f[k] || []).filter((y: string) => y !== x))} />{tr(x)}</label>))}</div></div>;
function useForm<T>(init: T): [any, Set, (v: any) => void] { const [f, setF] = useState<any>(init); return [f, (k, v) => setF((p: any) => ({ ...p, [k]: v })), setF]; }

export function SiteFields({ f, s, e }: { f: any; s: Set; e?: Record<string, string> }) {
  return <>
    <Tx l={tr("Site address")} k="addr" f={f} s={s} e={e} ta /><Tx l={tr("Building / project name")} k="building" f={f} s={s} e={e} />
    <Tx l={tr("Flat / floor / unit number")} k="unit" f={f} s={s} e={e} /><Tx l={tr("Landmark")} k="landmark" f={f} s={s} e={e} />
    <F l={tr("PIN code")} e={e?.pin}><input value={f.pin || ''} inputMode="numeric" maxLength={6} onChange={x => s('pin', x.target.value.replace(/\D/g, ''))} />{tr((f.pin || '').length === 6 && !e?.pin && <span className={isServiceable(f.pin) ? 'nv-pinok' : 'nv-pinno'}>{tr(isServiceable(f.pin) ? 'We deliver here' : COMING_SOON)}</span>)}</F>
    <Tx l={tr("Site contact person")} k="contact" f={f} s={s} e={e} /><Tx l={tr("Site contact number")} k="phone" f={f} s={s} e={e} mode="numeric" />
    <Tx l={tr("Site working hours")} k="hours" f={f} s={s} e={e} />
    <Ck l={tr("Vehicle access")} k="vehicles" f={f} s={s} o={VEH} />
    <Tx l={tr("Parking / loading restrictions")} k="parking" f={f} s={s} e={e} ta /><Sl l={tr("Lift available?")} k="lift" f={f} s={s} o={['Yes', 'No']} e={e} /><Tx l={tr("Floor number")} k="floor" f={f} s={s} e={e} />
    <Tx l={tr("Unloading requirements")} k="unloading" f={f} s={s} e={e} ta /><Tx l={tr("Special site instructions")} k="notes" f={f} s={s} e={e} ta />
  </>;
}
export function siteErrors(f: Site): Record<string, string> {
  const er: Record<string, string> = {};
  if (f.addr.trim().length < 8) er.addr = 'Enter the site address';
  if (!/^\d{6}$/.test(f.pin)) er.pin = 'Enter a 6-digit pincode'; else if (!isServiceable(f.pin)) er.pin = COMING_SOON;
  if (f.contact.trim().length < 2) er.contact = 'Enter the site contact person';
  if (!MOB.test(f.phone)) er.phone = 'Enter a valid 10-digit number';
  if (f.vehicles.length === 0) er.lift = er.lift; if (!f.lift) er.lift = 'Select yes or no';
  return er;
}
export function BillFields({ f, s, e }: { f: any; s: Set; e?: Record<string, string> }) {
  return <><Tx l={tr("Billing name")} k="name" f={f} s={s} e={e} /><Tx l={tr("GSTIN")} k="gstin" f={f} s={s} e={e} /><Tx l={tr("PAN")} k="pan" f={f} s={s} e={e} /><Tx l={tr("Billing address")} k="addr" f={f} s={s} e={e} ta /></>;
}
export function billErrors(f: any, need: boolean): Record<string, string> {
  const er: Record<string, string> = {};
  if (need) { if ((f.name || '').trim().length < 2) er.name = 'Enter the billing name'; if (!GST.test((f.gstin || '').toUpperCase())) er.gstin = 'Enter a valid 15-character GSTIN'; if ((f.addr || '').trim().length < 8) er.addr = 'Enter the billing address'; }
  if (f.pan && !PAN.test(f.pan.toUpperCase())) er.pan = 'Enter a valid PAN';
  return er;
}

export function AccountPage(p: { custs: Cust[]; setCusts: (c: Cust[]) => void; sess: string; setSess: (s: string) => void; orders: Order[]; nameOf: (pid: string) => string; shop: (cat?: string) => void; track: (id: string) => void; afterAuth: () => void; reason: string }) {
  useLanguage();
  const me = p.custs.find(c => c.mobile === p.sess);
  const upd = (patch: Partial<Cust>) => p.setCusts(p.custs.map(c => c.mobile === p.sess ? { ...c, ...patch } : c));
  if (!me) return <AuthFlow {...p} />;
  return <Profile me={me} upd={upd} signOut={() => p.setSess('')} orders={p.orders} nameOf={p.nameOf} shop={p.shop} track={p.track} />;
}

function AuthFlow({ custs, setCusts, setSess, afterAuth, reason, shop }: { custs: Cust[]; setCusts: (c: Cust[]) => void; setSess: (s: string) => void; afterAuth: () => void; reason: string; shop: (cat?: string) => void }) {
  const [mode, setMode] = useState<'otp' | 'pw'>('otp'); const [step, setStep] = useState<'mobile' | 'code' | 'o1' | 'o2' | 'o3' | 'o4' | 'o5' | 'o6' | 'welcome'>('mobile');
  const [mobile, setMobile] = useState(''); const [code, setCode] = useState(''); const [err, setErr] = useState(''); const [user, setUser] = useState(''); const [pw, setPw] = useState('');
  const [a, sa] = useForm<any>({ name: '', type: '', pin: '', email: '', whatsapp: '', user: '', pass: '', pass2: '', biz: false });
  const [pj, sp] = useForm<any>({}); const [st, ss] = useForm<any>(emptySite()); const [bl, sb] = useForm<any>({ name: '', gstin: '', pan: '', addr: '' }); const [pf, spf] = useForm<any>({ freq: '', buys: [], value: '' });
  const [ag, setAg] = useState(false); const [er, setEr] = useState<Record<string, string>>({});
  const login = (m: string) => { setSess(m); afterAuth(); };
  const sendCode = (e: React.FormEvent) => { e.preventDefault(); if (!MOB.test(mobile)) { setErr('Enter a valid 10-digit mobile number'); return; } setErr(''); setStep('code'); };
  const verify = (e: React.FormEvent) => { e.preventDefault(); if (code !== '1234') { setErr('That code is not right. Try again.'); return; } setErr(''); if (custs.some(c => c.mobile === mobile)) login(mobile); else { setStep('o1'); sa('whatsapp', mobile); } };
  const pwLogin = (e: React.FormEvent) => { e.preventDefault(); const c = custs.find(x => x.user.toLowerCase() === user.trim().toLowerCase() && x.pass === pw); if (!c) { setErr('Incorrect username or password. New to Kwenzo? Sign in with your mobile number and code to create your account.'); return; } setErr(''); login(c.mobile); };
  const next1 = (e: React.FormEvent) => { e.preventDefault(); const x: Record<string, string> = {};
    if (a.name.trim().length < 2) x.name = 'Enter your full name'; if (!a.type) x.type = 'Select your customer type';
    if (!/^\d{6}$/.test(a.pin)) x.pin = 'Enter your 6-digit pincode'; else if (!isServiceable(a.pin)) x.pin = COMING_SOON;
    if (a.email && !/^\S+@\S+\.\S+$/.test(a.email.trim())) x.email = 'Enter a valid email address';
    if (a.whatsapp && !MOB.test(a.whatsapp)) x.whatsapp = 'Enter a valid 10-digit number';
    if (!/^[a-z0-9_]{4,20}$/i.test(a.user.trim())) x.user = '4 to 20 letters, numbers or underscore'; else if (custs.some(c => c.user.toLowerCase() === a.user.trim().toLowerCase())) x.user = 'That username is taken';
    if (a.pass.length < 6) x.pass = 'At least 6 characters'; if (a.pass2 !== a.pass) x.pass2 = 'Passwords do not match';
    if (a.biz && (a.company || '').trim().length < 2) x.company = 'Enter the company or firm name';
    setEr(x); if (Object.keys(x).length) return; ss('pin', a.pin); ss('contact', a.name.trim()); ss('phone', mobile); setStep('o3'); };
  const skipOr = (nx: any, valid?: () => Record<string, string>) => (e: React.FormEvent) => { e.preventDefault(); const x = valid ? valid() : {}; setEr(x); if (Object.keys(x).length) return; setStep(nx); };
  const finish = (e: React.FormEvent) => { e.preventDefault(); if (!ag) { setEr({ agree: 'Please accept to continue' }); return; }
    const hasSite = st.addr.trim().length > 0; const hasPj = Object.values(pj).some(v => (v as string).trim?.()); const hasBill = bl.gstin || bl.addr || bl.name;
    const c: Cust = { mobile, name: a.name.trim(), email: a.email.trim(), user: a.user.trim(), pass: a.pass, type: a.type, pin: a.pin, since: Date.now(), whatsapp: a.whatsapp, gstin: bl.gstin.toUpperCase(), pan: bl.pan.toUpperCase(), agreed: true,
      biz: a.biz ? { company: a.company.trim(), contact: a.name.trim(), designation: a.designation || '', btype: a.btype || '', gstin: (a.bgstin || '').toUpperCase(), pan: (a.bpan || '').toUpperCase(), regAddr: a.regAddr || '', billAddr: a.billAddr || '', email: a.bemail || '', phone: a.bphone || '' } : undefined,
      project: hasPj ? pj : undefined, site: hasSite ? st : undefined, bill: hasBill ? bl : undefined, prefs: pf.freq || pf.buys.length || pf.value ? pf : undefined };
    setCusts([...custs, c]); setSess(mobile); setStep('welcome'); setEr({}); };
  const steps = ['Basics', 'Delivery site', 'GST', 'Terms'];
  const idx = ['o1', 'o3', 'o4', 'o6'].indexOf(step);
  if (step === 'welcome') return <main className="nv-page ac-wrap"><div className="ac-card ac-wel"><span className="nv-done-i">{tr("K")}</span><h1>{tr("Welcome to Kwenzo")}</h1><p className="nv-lead">{tr("What do you need today?")}</p>
    <div className="ac-cats">{tr(['Cement', 'Plumbing', 'Electrical', 'Hardware', 'Paint', 'Plywood', 'Tiles'].map(c => <button key={c} onClick={() => { afterAuth(); shop(c); }}>{tr(c)}</button>))}<button onClick={() => { afterAuth(); shop('all'); }}>{tr("More")}</button></div></div></main>;
  return <main className="nv-page ac-wrap"><div className="ac-card">
    {tr(idx >= 0 && <><div className="ac-prog">{tr(steps.map((x, i) => <span key={x} className={i === idx ? 'on' : i < idx ? 'done' : ''}>{tr(i + 1)}. {tr(x)}</span>))}</div></>)}
    {tr(step === 'o1' && <Form className="nv-form" onSubmit={next1}><h1>{tr("Create your account")}</h1><p className="nv-lead">{tr("Your number ")}{tr(mobile)}{tr(" is verified. Just the basics to start; you can add the rest later.")}</p>
      <Tx l={tr("Full name")} k="name" f={a} s={sa} e={er} /><Sl l={tr("Customer type")} k="type" f={a} s={sa} o={TYPES} e={er} />
      <F l={tr("Your location (pincode)")} e={er.pin}><input value={a.pin} inputMode="numeric" maxLength={6} onChange={x => sa('pin', x.target.value.replace(/\D/g, ''))} />{tr(a.pin.length === 6 && !er.pin && <span className={isServiceable(a.pin) ? 'nv-pinok' : 'nv-pinno'}>{tr(isServiceable(a.pin) ? 'We deliver here' : COMING_SOON)}</span>)}</F>
      <Tx l={tr("Email (optional)")} k="email" f={a} s={sa} e={er} /><Tx l={tr("WhatsApp number")} k="whatsapp" f={a} s={sa} e={er} mode="numeric" />
      <Tx l={tr("Choose a username")} k="user" f={a} s={sa} e={er} /><Tx l={tr("Password")} k="pass" f={a} s={sa} e={er} type="password" /><Tx l={tr("Confirm password")} k="pass2" f={a} s={sa} e={er} type="password" />
      <label className="ac-agree"><input type="checkbox" checked={!!a.biz} onChange={x => sa('biz', x.target.checked)} />{tr(" I am registering a company or firm (business customer)")}</label>
      {tr(a.biz && <><Tx l={tr("Company / firm name")} k="company" f={a} s={sa} e={er} /><Tx l={tr("Designation")} k="designation" f={a} s={sa} e={er} /><Sl l={tr("Business type")} k="btype" f={a} s={sa} o={BTYPES} e={er} /><Tx l={tr("Business GSTIN")} k="bgstin" f={a} s={sa} e={er} /><Tx l={tr("Business PAN")} k="bpan" f={a} s={sa} e={er} /><Tx l={tr("Registered address")} k="regAddr" f={a} s={sa} e={er} ta /><Tx l={tr("Billing address")} k="billAddr" f={a} s={sa} e={er} ta /><Tx l={tr("Business email")} k="bemail" f={a} s={sa} e={er} /><Tx l={tr("Business phone number")} k="bphone" f={a} s={sa} e={er} mode="numeric" /></>)}
      <button className="nv-btn big wide">{tr("Continue")}</button></Form>)}
    {tr(step === 'o3' && <Form className="nv-form" onSubmit={skipOr('o4', () => st.addr.trim() ? siteErrors(st) : {})}><h1>{tr("Delivery site")}</h1><p className="nv-lead">{tr("This helps avoid failed deliveries. You can skip now; we will ask before your first order.")}</p><SiteFields f={st} s={ss} e={er} /><div className="ac-row"><button type="button" className="nv-btn ghost" onClick={() => { setEr({}); setStep('o4'); }}>{tr("Skip for now")}</button><button className="nv-btn">{tr("Continue")}</button></div></Form>)}
    {tr(step === 'o4' && <Form className="nv-form" onSubmit={skipOr('o6', () => billErrors(bl, false))}><h1>{tr("GST details")}</h1><p className="nv-lead">{tr("Optional. Needed only if you want a GST invoice.")}</p><BillFields f={bl} s={sb} e={er} /><div className="ac-row"><button type="button" className="nv-btn ghost" onClick={() => { setEr({}); setStep('o6'); }}>{tr("Skip for now")}</button><button className="nv-btn">{tr("Continue")}</button></div></Form>)}
    {tr(step === 'o6' && <Form className="nv-form" onSubmit={finish}><h1>{tr("Terms and declaration")}</h1><TermsView intro={false} />
      <p className="ac-decl">{tr(DECL)}</p>
      <label className={'ac-agree' + (er.agree ? ' bad' : '')}><input type="checkbox" checked={ag} onChange={x => setAg(x.target.checked)} />{tr(" I accept the Kwenzo Customer Terms and the Customer Declaration above.")}</label>{tr(er.agree && <em className="ac-em">{tr(er.agree)}</em>)}
      <button className="nv-btn big wide">{tr("Accept and create account")}</button></Form>)}
    {tr((step === 'mobile' || step === 'code') && <>
      <h1>{tr(reason || 'Sign in to Kwenzo')}</h1><p className="nv-lead">{tr("You can browse without an account. Sign in to place orders and see your order history.")}</p>
      <div className="ac-tabs"><button className={mode === 'otp' ? 'on' : ''} onClick={() => { setMode('otp'); setErr(''); }}>{tr("Mobile + code")}</button><button className={mode === 'pw' ? 'on' : ''} onClick={() => { setMode('pw'); setErr(''); }}>{tr("Username + password")}</button></div>
      {tr(mode === 'otp' && step === 'mobile' && <Form className="nv-form" onSubmit={sendCode}><F l={tr("Mobile number")}><input value={mobile} inputMode="numeric" maxLength={10} onChange={e => setMobile(e.target.value.replace(/\D/g, ''))} autoComplete="tel" placeholder={tr("10-digit mobile number")} /></F><button className="nv-btn big wide">{tr("Send code")}</button><p className="nv-small">{tr("First time here? You will set up your account after verifying your number.")}</p></Form>)}
      {tr(mode === 'otp' && step === 'code' && <Form className="nv-form" onSubmit={verify}><F l={tr('Code sent to ' + mobile)}><input value={code} inputMode="numeric" maxLength={4} onChange={e => setCode(e.target.value.replace(/\D/g, ''))} placeholder={tr("4-digit code")} autoFocus /></F><button className="nv-btn big wide">{tr("Verify and continue")}</button><button type="button" className="nv-btn ghost wide" onClick={() => { setStep('mobile'); setCode(''); setErr(''); }}>{tr("Change number")}</button><p className="nv-small">{tr("Preview code: 1234")}</p></Form>)}
      {tr(mode === 'pw' && <Form className="nv-form" onSubmit={pwLogin}><F l={tr("Username")}><input value={user} onChange={e => setUser(e.target.value)} autoComplete="username" /></F><F l={tr("Password")}><input type="password" value={pw} onChange={e => setPw(e.target.value)} autoComplete="current-password" /></F><button className="nv-btn big wide">{tr("Sign in")}</button></Form>)}
      {tr(err && <div className="nv-err">{tr(err)}</div>)}</>)}
  </div></main>;
}
function ProjectFields({ f, s, e }: { f: any; s: Set; e?: Record<string, string> }) {
  return <><Tx l={tr("Project name")} k="name" f={f} s={s} e={e} /><Sl l={tr("Project type")} k="ptype" f={f} s={s} o={PTYPES} /><Tx l={tr("Project location")} k="loc" f={f} s={s} e={e} /><Tx l={tr("Approx. project size")} k="size" f={f} s={s} e={e} /><Sl l={tr("Current stage")} k="stage" f={f} s={s} o={STAGES} /><Tx l={tr("Expected completion date")} k="done" f={f} s={s} type="date" /><Tx l={tr("Expected material requirement")} k="req" f={f} s={s} ta /><Tx l={tr("Approximate monthly material spend")} k="spend" f={f} s={s} /><Tx l={tr("Preferred brands")} k="brands" f={f} s={s} /><Tx l={tr("Budget range")} k="budget" f={f} s={s} /></>;
}
function PrefFields({ f, s }: { f: any; s: Set }) {
  return <><Sl l={tr("How frequently do you purchase construction or interior material?")} k="freq" f={f} s={s} o={FREQ} /><Ck l={tr("What do you primarily purchase?")} k="buys" f={f} s={s} o={BUYS} /><Sl l={tr("Typical order value")} k="value" f={f} s={s} o={VALS} /></>;
}
const CREDIT_F: [string, string, boolean?][] = [['pan', 'PAN'], ['gstin', 'GSTIN'], ['reg', 'Business registration (type and number)'], ['addr', 'Business address', true], ['years', 'Years in business'], ['suppliers', 'Existing suppliers', true], ['monthly', 'Approximate monthly purchases'], ['aov', 'Average order value'], ['liab', 'Current outstanding liabilities'], ['facilities', 'Existing credit facilities', true], ['bureau', 'Credit bureau / business credit information (where legally permissible)', true], ['udyam', 'Udyam registration number, if applicable'], ['refs', 'Trade references: contact details of references', true]];

function Profile({ me, upd, signOut, orders, nameOf, shop, track }: { me: Cust; upd: (p: Partial<Cust>) => void; signOut: () => void; orders: Order[]; nameOf: (pid: string) => string; shop: (c?: string) => void; track: (id: string) => void }) {
  const [tab, setTab] = useState('orders'); const [open, setOpen] = useState(''); const [saved, setSaved] = useState(''); const [er, setEr] = useState<Record<string, string>>({});
  const [d, sd] = useForm<any>({ name: me.name, email: me.email, whatsapp: me.whatsapp, type: me.type, pin: me.pin, pass: '', ...(me.biz || {}) });
  const [pj, sp] = useForm<any>(me.project || {}); const [st, ss] = useForm<any>(me.site || emptySite(me)); const [bl, sb] = useForm<any>(me.bill || { name: me.biz?.company || me.name, gstin: me.gstin, pan: me.pan, addr: me.biz?.billAddr || '' }); const [pf, spf] = useForm<any>(me.prefs || { freq: '', buys: [], value: '' });
  const [cr, scr] = useForm<any>(me.credit?.data || {}); const [bizOn, setBizOn] = useState(!!me.biz);
  const done = (m: string) => { setSaved(m); setEr({}); setTimeout(() => setSaved(''), 2500); };
  const spent = orders.filter(o => o.status !== 'cancelled').reduce((a, o) => a + o.total, 0);
  const saveDetails = (e: React.FormEvent) => { e.preventDefault(); const x: Record<string, string> = {}; if (d.name.trim().length < 2) x.name = 'Enter your full name'; if (d.email && !/^\S+@\S+\.\S+$/.test(d.email)) x.email = 'Enter a valid email address'; if (!/^\d{6}$/.test(d.pin)) x.pin = 'Enter a 6-digit pincode'; else if (!isServiceable(d.pin)) x.pin = COMING_SOON; if (d.pass && d.pass.length < 6) x.pass = 'At least 6 characters'; if (bizOn && (d.company || '').trim().length < 2) x.company = 'Enter the company or firm name'; setEr(x); if (Object.keys(x).length) return;
    upd({ name: d.name.trim(), email: d.email.trim(), whatsapp: d.whatsapp, type: d.type, pin: d.pin, pass: d.pass || me.pass, biz: bizOn ? { company: d.company, contact: d.name.trim(), designation: d.designation || '', btype: d.btype || '', gstin: (d.gstin || '').toUpperCase(), pan: (d.pan || '').toUpperCase(), regAddr: d.regAddr || '', billAddr: d.billAddr || '', email: d.email2 || d.bemail || '', phone: d.phone || '' } : undefined }); sd('pass', ''); done('Saved.'); };
  const T = ({ id, c }: { id: string; c: string }) => <button className={tab === id ? 'on' : ''} onClick={() => { setTab(id); setEr({}); }}>{tr(c)}</button>;
  const creditNote = me.credit ? (me.credit.status === 'submitted' ? 'Application submitted on ' + fdate(me.credit.at) + '. Kwenzo will review it and assign your Customer Risk Grade. Credit is not available until it is approved.' : me.credit.status === 'approved' ? 'Credit approved.' : 'Your application was not approved.') : '';
  return <main className="nv-page ac-prof">
    <div className="ac-head"><div className="ac-av">{tr(me.name.trim()[0]?.toUpperCase())}</div><div><h1>{tr(me.name)}</h1><p className="nv-small">+91 {tr(me.mobile)}{tr(me.email ? ' · ' + me.email : '')} · @{tr(me.user)} · {tr(me.type)}</p></div><button className="nv-btn ghost" onClick={signOut}>{tr("Sign out")}</button></div>
    {tr(!me.site && <div className="ac-nudge">{tr("Add your delivery site details before your first order. ")}<button onClick={() => setTab('site')}>{tr("Add site")}</button></div>)}
    <div className="ac-stats"><div><b>{tr(orders.length)}</b><span>{tr("Orders placed")}</span></div><div><b>{tr(inr(spent))}</b><span>{tr("Total ordered")}</span></div><div><b>{tr(orders.filter(o => o.status === 'delivered').length)}</b><span>{tr("Delivered")}</span></div></div>
    <div className="ac-tabs"><T id="orders" c="Order history" /><T id="details" c="My details" /><T id="site" c="Delivery site" /><T id="bill" c="GST and billing" /><T id="credit" c="Kwenzo Credit" /><T id="terms" c="Terms and support" /></div>
    {tr(saved && <p className="nv-pinok">{tr(saved)}</p>)}
    {tr(tab === 'orders' && (orders.length === 0 ? <div className="nv-empty"><h3>{tr("No orders yet")}</h3><p>{tr("Your orders will show up here once you place one.")}</p><button className="nv-btn" onClick={() => shop('all')}>{tr("Shop materials")}</button></div> :
      <div className="ac-orders">{tr(orders.map(o => <div className="ac-ord" key={o.id}>
        <button className="ac-ord-h" onClick={() => setOpen(open === o.id ? '' : o.id)}><div><b>{tr(o.id)}</b><span>{tr(fdate(o.at))} · {tr(o.lines.length)}{tr(" item")}{tr(o.lines.length > 1 ? 's' : '')} · {tr(o.pay)}</span></div><div className="ac-ord-r"><b>{tr(inr(o.total))}</b><span className="nv-pill dark">{tr(STAT[o.status])}</span></div></button>
        {tr(open === o.id && <div className="ac-ord-b">{tr(o.lines.map((l, i) => <div key={i}><span>{tr(nameOf(l.pid))}{tr(" x ")}{tr(l.qty)}</span><b>{tr(inr(l.up * l.qty))}</b></div>))}<p className="nv-small">{tr("Delivered to: ")}{tr(o.addr)}, {tr(o.city)} {tr(o.pin)}</p><button className="nv-btn" onClick={() => track(o.id)}>{tr("Track this order")}</button></div>)}
      </div>))}</div>))}
    {tr(tab === 'details' && <Form className="nv-form ac-det" onSubmit={saveDetails}>
      <Tx l={tr("Full name")} k="name" f={d} s={sd} e={er} /><F l={tr("Mobile number")}><input value={me.mobile} disabled /></F><Tx l={tr("Email")} k="email" f={d} s={sd} e={er} /><Tx l={tr("WhatsApp number")} k="whatsapp" f={d} s={sd} e={er} mode="numeric" /><Sl l={tr("Customer type")} k="type" f={d} s={sd} o={TYPES} /><F l={tr("Username")}><input value={me.user} disabled /></F>
      <F l={tr("Pincode")} e={er.pin}><input value={d.pin} inputMode="numeric" maxLength={6} onChange={x => sd('pin', x.target.value.replace(/\D/g, ''))} /></F><Tx l={tr("New password (leave blank to keep)")} k="pass" f={d} s={sd} e={er} type="password" />
      <label className="ac-agree"><input type="checkbox" checked={bizOn} onChange={x => setBizOn(x.target.checked)} />{tr(" Business customer")}</label>
      {tr(bizOn && <><Tx l={tr("Company / firm name")} k="company" f={d} s={sd} e={er} /><Tx l={tr("Designation")} k="designation" f={d} s={sd} /><Sl l={tr("Business type")} k="btype" f={d} s={sd} o={BTYPES} /><Tx l={tr("Business GSTIN")} k="gstin" f={d} s={sd} /><Tx l={tr("Business PAN")} k="pan" f={d} s={sd} /><Tx l={tr("Registered address")} k="regAddr" f={d} s={sd} ta /><Tx l={tr("Billing address")} k="billAddr" f={d} s={sd} ta /><Tx l={tr("Business email")} k="bemail" f={d} s={sd} /><Tx l={tr("Business phone number")} k="phone" f={d} s={sd} mode="numeric" /></>)}
      <button className="nv-btn big">{tr("Save changes")}</button></Form>)}
    {tr(tab === 'site' && <Form className="nv-form ac-det" onSubmit={e => { e.preventDefault(); const x = siteErrors(st); setEr(x); if (Object.keys(x).length) return; upd({ site: st }); done('Delivery site saved.'); }}><SiteFields f={st} s={ss} e={er} /><button className="nv-btn big">{tr("Save delivery site")}</button></Form>)}
    {tr(tab === 'bill' && <Form className="nv-form ac-det" onSubmit={e => { e.preventDefault(); const x = billErrors(bl, !!(bl.gstin || bl.addr)); setEr(x); if (Object.keys(x).length) return; upd({ bill: bl, gstin: (bl.gstin || '').toUpperCase(), pan: (bl.pan || '').toUpperCase() }); done('Billing details saved.'); }}><p className="nv-small">{tr("Needed for a GST invoice on B2B orders.")}</p><BillFields f={bl} s={sb} e={er} /><button className="nv-btn big">{tr("Save billing details")}</button></Form>)}
    {tr(tab === 'credit' && <div className="ac-det"><h3>{tr("Kwenzo Credit Application")}</h3><p className="nv-small">{tr("Credit is not given automatically. Contractors and repeat B2B customers apply here. After review, Kwenzo assigns a Customer Risk Grade: A (low risk, higher limit), B (moderate risk, moderate limit), C (higher risk, low or secured limit) or D (high risk, prepaid only).")}</p>
      {tr(me.credit && <div className="ac-nudge">{tr(creditNote)}</div>)}
      <Form className="nv-form" onSubmit={e => { e.preventDefault(); const x: Record<string, string> = {}; if (!PAN.test((cr.pan || '').toUpperCase())) x.pan = 'Enter a valid PAN'; if (!GST.test((cr.gstin || '').toUpperCase())) x.gstin = 'Enter a valid 15-character GSTIN'; for (const [k, l] of CREDIT_F) if (!['udyam', 'bureau'].includes(k) && !(cr[k] || '').trim()) x[k] = x[k] || 'Required'; setEr(x); if (Object.keys(x).length) return; upd({ credit: { status: 'submitted', at: Date.now(), data: cr } }); done('Credit application submitted.'); }}>
        {tr(CREDIT_F.map(([k, l, ta]) => <Tx key={k} l={tr(l)} k={k} f={cr} s={scr} e={er} ta={ta} />))}
        <p className="nv-small">{tr("Bank statement and trade references are reviewed by Kwenzo during the application.")}</p>
        <button className="nv-btn big">{tr(me.credit ? 'Update and resubmit' : 'Submit credit application')}</button></Form></div>)}
    {tr(tab === 'terms' && <div className="ac-det"><TermsView /></div>)}
  </main>;
}
