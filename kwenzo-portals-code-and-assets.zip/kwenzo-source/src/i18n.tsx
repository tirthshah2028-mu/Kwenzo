import React, { createContext, useContext } from 'react';
import { useLocalState } from '@instinct/files';
import translations from './translations.json';
export type Lang = 'en' | 'hi' | 'te';
let active: Lang = 'en';
const words = translations as Record<string, {hi:string;te:string}>;
export function tr<T>(value: T): T {
  if (active === 'en' || typeof value !== 'string') return value;
  const text = value.trim().replace(/\s+/g, ' ');
  const row = words[text];
  if (row) return (value.slice(0, value.indexOf(value.trim())) + row[active] + value.slice(value.indexOf(value.trim()) + value.trim().length)) as T;
  // Match parameterized labels without translating customer data or product names.
  const patterns: [RegExp, string, string][] = [
    [/^(\d+) delivered$/, '$1 डिलीवर किए गए', '$1 డెలివరీ అయ్యాయి'],
    [/^([\d.]+)% on delivered$/, 'डिलीवर किए गए ऑर्डर पर $1%', 'డెలివరీ అయిన ఆర్డర్లపై $1%'],
    [/^Payout after (.+)% fee$/, '$1% फ़ीस के बाद भुगतान', '$1% రుసుము తర్వాత చెల్లింపు'],
    [/^Commission % for (.+)$/, '$1 का कमीशन %', '$1కు కమీషన్ %'],
    [/^(\d+) of (\d+)$/, '$2 में से $1', '$2లో $1'],
    [/^From (.+)$/, 'शुरुआती कीमत $1', 'ప్రారంభ ధర $1'],
    [/^Hi, (.+)$/, 'नमस्ते, $1', 'నమస్కారం, $1'],
    [/^Code sent to (.+)$/, '$1 पर भेजा गया कोड', '$1కు పంపిన కోడ్'],
    [/^(\d+) products$/, '$1 उत्पाद', '$1 ఉత్పత్తులు'],
    [/^(\d+) items?$/, '$1 वस्तु', '$1 వస్తువులు'],
    [/^Dealers( \(\d+\))?$/, 'डीलर$1', 'డీలర్లు$1'],
    [/^More in (.+)$/, '$1 में और देखें', '$1లో మరిన్ని'],
    [/^Free delivery on orders above (.+)$/, '$1 से अधिक के ऑर्डर पर मुफ़्त डिलीवरी', '$1 కంటే ఎక్కువ ఆర్డర్లపై ఉచిత డెలివరీ'],
    [/^On orders above (.+)$/, '$1 से अधिक के ऑर्डर पर', '$1 కంటే ఎక్కువ ఆర్డర్లపై'],
    [/^Shop for (.+) more$/, 'और $1 की खरीदारी करें', 'ఇంకా $1 కొనండి'],
  ];
  for (const [re, hi, te] of patterns) if (re.test(text)) return text.replace(re, active === 'hi' ? hi : te) as T;
  return value;
}
const Context = createContext<{lang:Lang;setLang:(l:Lang)=>void;ready:boolean;message:string}>({lang:'en',setLang:()=>{},ready:false,message:''});
export function LanguageProvider({children}:{children:React.ReactNode}) {
  const [lang,setLang,saved] = useLocalState<Lang>('kwenzo-language.v1','en'); active = lang;
  return <Context.Provider value={{lang,setLang,ready:saved.ready,message:saved.message}}><div className="kw-localized" lang={lang}>{children}</div></Context.Provider>;
}
export function useLanguage(){ return useContext(Context); }
export function LanguageSelector(){
  const {lang,setLang,ready,message}=useLanguage();
  return <div className="kw-langbar"><label><span>{tr('Language')}</span><select aria-label={tr('Language')} disabled={!ready} value={lang} onChange={e=>setLang(e.target.value as Lang)}><option value="en" lang="en">English</option><option value="hi" lang="hi">हिन्दी</option><option value="te" lang="te">తెలుగు</option></select></label>{lang !== 'en' && <small className="kw-lang-note">{tr('Product names and detailed descriptions remain in English. Legal policy wording is shown in English.')}</small>}{message && <small className="kw-lang-note" role="status">{tr(message)}</small>}</div>;
}
