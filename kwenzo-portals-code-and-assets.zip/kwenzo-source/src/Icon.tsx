import React from 'react';
export function Icon({ n, size = 28 }: { n: string; size?: number }) {
  const s = { width: size, height: size, viewBox: '0 0 32 32', fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, 'aria-hidden': true };
  switch (n) {
    case 'user': return <svg {...s}><circle cx="16" cy="11" r="5"/><path d="M5 27c1-6 5-9 11-9s10 3 11 9"/></svg>;
    case 'bag': return <svg {...s}><path d="M8 8h16l2 6-1 14H7L6 14z"/><path d="M11 8l1-3h8l1 3"/><path d="M11 17h10M11 21h10"/></svg>;
    case 'bars': return <svg {...s}><path d="M4 10h24M4 16h24M4 22h24"/><path d="M8 8v16M16 8v16M24 8v16" opacity=".5"/></svg>;
    case 'brick': return <svg {...s}><rect x="3" y="7" width="26" height="18" rx="2"/><path d="M3 13h26M3 19h26M11 7v6M21 13v6M11 19v6"/></svg>;
    case 'pile': return <svg {...s}><path d="M3 26L14 8l5 8 3-4 7 14z"/><path d="M10 20h.01M17 22h.01M23 22h.01"/></svg>;
    case 'pipe': return <svg {...s}><path d="M4 11h14a4 4 0 014 4v11"/><path d="M4 7v8M18 22h8"/></svg>;
    case 'bolt': return <svg {...s}><path d="M18 3L6 18h9l-1 11 12-15h-9z"/></svg>;
    case 'drop': return <svg {...s}><path d="M16 4C11 11 7 15 7 20a9 9 0 0 0 18 0c0-5-4-9-9-16z"/><path d="M12 21a4 4 0 0 0 4 4"/></svg>;
    case 'bucket': return <svg {...s}><path d="M6 10l2 17h16l2-17"/><ellipse cx="16" cy="10" rx="10" ry="3"/><path d="M6 10c0-6 20-6 20 0"/></svg>;
    case 'tile': return <svg {...s}><rect x="4" y="4" width="10" height="10"/><rect x="18" y="4" width="10" height="10"/><rect x="4" y="18" width="10" height="10"/><rect x="18" y="18" width="10" height="10"/></svg>;
    case 'board': return <svg {...s}><path d="M3 12l13-6 13 6-13 6z"/><path d="M3 17l13 6 13-6M3 22l13 6 13-6"/></svg>;
    case 'tool': return <svg {...s}><path d="M20 4a6 6 0 00-5 8L4 23l5 5 11-11a6 6 0 008-5l-4 3-4-1-1-4z"/></svg>;
    case 'cart': return <svg {...s}><path d="M3 5h4l3 15h15l3-11H8"/><circle cx="12" cy="26" r="1.6"/><circle cx="23" cy="26" r="1.6"/></svg>;
    case 'search': return <svg {...s}><circle cx="14" cy="14" r="9"/><path d="M21 21l7 7"/></svg>;
    case 'pin': return <svg {...s}><path d="M16 29s9-8 9-15a9 9 0 10-18 0c0 7 9 15 9 15z"/><circle cx="16" cy="14" r="3"/></svg>;
    case 'bolt2': return <svg {...s}><path d="M17 3L7 17h8l-1 12 11-15h-8z"/></svg>;
    case 'truck': return <svg {...s}><path d="M2 8h18v15H2zM20 13h6l4 5v5h-10z"/><circle cx="8" cy="24" r="2.5"/><circle cx="24" cy="24" r="2.5"/></svg>;
    case 'shield': return <svg {...s}><path d="M16 3l11 4v8c0 7-5 12-11 14C10 27 5 22 5 15V7z"/><path d="M11 16l4 4 7-8"/></svg>;
    case 'tag': return <svg {...s}><path d="M3 15V4h11l15 15-11 11z"/><circle cx="9" cy="10" r="1.6"/></svg>;
    case 'list': return <svg {...s}><path d="M6 6h20v20H6zM11 12h10M11 17h10M11 22h6"/></svg>;
    case 'star': return <svg {...s} fill="currentColor"><path d="M16 3l4 9 10 1-7.5 6.5L25 29l-9-5-9 5 2.5-9.5L2 13l10-1z" strokeWidth="1"/></svg>;
    case 'x': return <svg {...s}><path d="M6 6l20 20M26 6L6 26"/></svg>;
    case 'check': return <svg {...s}><path d="M5 17l7 7 15-16"/></svg>;
    case 'clock': return <svg {...s}><circle cx="16" cy="16" r="12"/><path d="M16 8v8l5 3"/></svg>;
    case 'home': return <svg {...s}><path d="M4 15L16 4l12 11"/><path d="M7 13v14h18V13"/><path d="M13 27v-8h6v8"/></svg>;
    case 'reorder': return <svg {...s}><path d="M7 11h18l-1.5 16h-15z"/><path d="M11 11a5 5 0 0110 0"/></svg>;
    case 'grid': return <svg {...s}><rect x="4" y="4" width="10" height="10" rx="2"/><rect x="18" y="4" width="10" height="10" rx="2"/><rect x="4" y="18" width="10" height="10" rx="2"/><rect x="18" y="18" width="10" height="10" rx="2"/></svg>;
    case 'help': return <svg {...s}><circle cx="16" cy="16" r="12"/><path d="M12 13a4 4 0 118 1c0 3-4 3-4 6M16 24h.01"/></svg>;
    default: return null;
  }
}
