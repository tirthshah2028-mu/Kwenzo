# Kwenzo Portals

React + TypeScript + Vite app (store, supplier and other portals).

## Run locally
```
npm install
npm run dev
```

## Build
```
npm run build   # outputs to dist/
```

## Deploy on Vercel
Import the repo in Vercel. The Vite preset is detected automatically
(build: `npm run build`, output: `dist`). `vercel.json` rewrites all routes to `index.html`
so deep links such as `/product/:code` and `/supplier` work.

Note: `src/instinct-files.tsx` is a local replacement for the original `@instinct/files` module.
