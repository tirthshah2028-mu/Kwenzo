import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      // The original code was written for a platform module; this local shim replaces it.
      '@instinct/files': fileURLToPath(new URL('./src/instinct-files.tsx', import.meta.url)),
    },
  },
});
