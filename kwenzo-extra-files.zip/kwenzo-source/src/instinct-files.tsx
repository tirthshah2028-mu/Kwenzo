// Local replacement for the platform-only "@instinct/files" module.
import React, { useEffect, useRef, useState } from 'react';
import { BrowserRouter } from 'react-router-dom';

export { Routes, Route, useLocation, useNavigate } from 'react-router-dom';

export function FileRouter({ children }: { children: React.ReactNode }) {
  return <BrowserRouter>{children}</BrowserRouter>;
}

export function useLocalState<T>(
  key: string,
  init: T,
): [T, (v: T) => void, { ready: boolean; message: string }] {
  const [v, setV] = useState<T>(() => {
    try {
      const s = window.localStorage.getItem(key);
      if (s) return JSON.parse(s) as T;
    } catch (e) { /* storage blocked */ }
    return init;
  });
  const vRef = useRef(v);
  vRef.current = v;
  const set = (n: T) => {
    setV(n);
    try { window.localStorage.setItem(key, JSON.stringify(n)); } catch (e) { /* storage blocked */ }
  };
  return [v, set, { ready: true, message: '' }];
}
